# -*- coding: utf-8 -*-
import time
import threading

from .auth import session_client, sync_panel_for_open
from .constants import AUTO_REFRESH_EVERY, HEARTBEAT_SECONDS, PLUGIN_URL
from .log import log
from .media_relay import release_playback
from .panel import PanelClient
from .state import clear_exit_return, clear_playback, clear_session, load_activity, load_panel, load_session, playback_fingerprint, save_panel, save_session
from .watch_history import record_progress

try:
    import xbmc
    import xbmcgui
except Exception:
    xbmc = None
    xbmcgui = None


def _set_sync_text(text):
    if xbmcgui is None:
        return
    try:
        window = xbmcgui.Window(10000)
        if text:
            window.setProperty('IBO.V2.SyncText', str(text))
        else:
            window.clearProperty('IBO.V2.SyncText')
    except Exception:
        pass


def _set_banner_url(url):
    if xbmcgui is None:
        return
    try:
        window = xbmcgui.Window(10000)
        if url:
            window.setProperty('IBO.V2.Banner', str(url))
        else:
            window.clearProperty('IBO.V2.Banner')
    except Exception:
        pass


def _set_background_video_active(active):
    """Mantém o skin autorizado somente para o VideoPlayer do ONEPLAY."""
    if xbmcgui is None:
        return
    try:
        window = xbmcgui.Window(10000)
        if active:
            window.setProperty('IBO.V2.BackgroundVideo', '1')
        else:
            window.clearProperty('IBO.V2.BackgroundVideo')
    except Exception:
        pass


_HISTORY_REVISION_PROPERTY = 'IBO.V2.HistoryRevision'


def _publish_history_revision(meta=None, position=0.0, total=0.0, final=False):
    """Avisa as janelas ONEPLAY que o histórico local mudou.

    O arquivo watch_history_v2.json continua sendo a fonte de verdade. Estas
    propriedades globais são apenas um sinal cross-interpreter para que uma
    tela já aberta faça repaint local sem consultar Xtream/TMDB nem reconstruir
    catálogos de servidor.
    """
    if xbmcgui is None:
        return
    info = meta if isinstance(meta, dict) else {}
    try:
        home = xbmcgui.Window(10000)
        home.setProperty(_HISTORY_REVISION_PROPERTY, '%.6f' % time.time())
        home.setProperty('IBO.V2.HistoryKind', str(info.get('kind') or ''))
        home.setProperty('IBO.V2.HistoryStreamId', str(info.get('stream_id') or ''))
        home.setProperty('IBO.V2.HistoryPosition', '%.3f' % max(0.0, float(position or 0.0)))
        home.setProperty('IBO.V2.HistoryTotal', '%.3f' % max(0.0, float(total or 0.0)))
        home.setProperty('IBO.V2.HistoryFinal', '1' if final else '0')
    except Exception:
        pass


def _set_home_showcase(slide=None):
    """Espelha o slide nativo dos Temas 2..5 em propriedades globais Kodi."""
    if xbmcgui is None:
        return
    slide = slide if isinstance(slide, dict) else {}
    values = {
        'IBO.V2.HeroBackdrop': str(slide.get('image') or ''),
        'IBO.V2.HeroPoster': str(slide.get('poster') or ''),
        'IBO.V2.HeroTitle': str(slide.get('title') or ''),
        'IBO.V2.HeroPlot': str(slide.get('plot') or ''),
    }
    try:
        window = xbmcgui.Window(10000)
        for key, value in values.items():
            if value:
                window.setProperty(key, value)
            else:
                window.clearProperty(key)
    except Exception:
        pass


def _ui_active():
    # V2 stores activity in activity_v2.json so the plugin UI and the service
    # can share state across independent Python interpreters.  V2.0.1 checked
    # a GUI Window property that was never written, therefore navigation was
    # always considered inactive and no Heartbeat was emitted.
    try:
        return bool(load_activity().get('ui_active'))
    except Exception:
        return False


_PLAYBACK_START_GRACE_SECONDS = 15.0


def _playback_marker_is_starting(activity, now=None):
    """Preserva a identidade enquanto o VideoPlayer ainda está subindo.

    ``mark_playback()`` precisa ocorrer antes de ``Player.play()`` para que a
    tentativa já tenha identidade. O serviço roda em outro interpretador e
    pode observar alguns frames em que o marcador novo existe, mas
    ``isPlayingVideo()`` ainda é False. Esse estado é *startup*, não Stop.

    O owner da reprodução continua responsável por limpar o marcador quando
    o start falha/é abortado; a janela abaixo existe apenas como defesa
    cross-interpreter e expira sozinha em caso de crash do owner.
    """
    activity = activity if isinstance(activity, dict) else {}
    marker = str(activity.get('playback_hash') or '')
    if not marker:
        return False
    try:
        started_at = float(activity.get('playback_at') or 0.0)
    except Exception:
        started_at = 0.0
    if started_at <= 0.0:
        return False
    current = time.time() if now is None else float(now)
    age = max(0.0, current - started_at)
    return age <= _PLAYBACK_START_GRACE_SECONDS


def _playback_active():
    if xbmc is None:
        return False
    activity = load_activity()
    marker = str(activity.get('playback_hash') or '')
    if not marker:
        return False
    try:
        player = xbmc.Player()
        if not player.isPlayingVideo():
            # Não apague um marcador recém-gravado entre mark_playback() e o
            # callback real do Kodi. A 2.0.88 fazia exatamente isso e perdia
            # a primeira reprodução após iniciar/Stop. Marcadores antigos
            # continuam sendo limpos para não autorizar player externo.
            if _playback_marker_is_starting(activity):
                return False
            # Se a reprodução foi deixada em background, o service.py é o dono
            # do lifecycle restante. Ao detectar Stop, saneie imediatamente a URL
            # Xtream mantida no relay antes de remover o marcador compartilhado.
            release_playback(activity.get('playback_relay_session_id') or '')
            clear_playback()
            return False
        current = ''
        try:
            current = player.getPlayingFile() or ''
        except Exception:
            pass
        if not current:
            return True
        return playback_fingerprint(current) == marker
    except Exception:
        return False


def _usage_active(activity=None):
    activity = activity if isinstance(activity, dict) else load_activity()
    if 'usage_active' in activity:
        return bool(activity.get('usage_active'))
    # Upgrade compatibility for an activity_v2.json written by <= 2.0.8.
    return bool(activity.get('ui_active')) or _playback_active()


def should_heartbeat():
    activity = load_activity()
    if not _usage_active(activity):
        return False
    return bool(activity.get('ui_active')) or _playback_active()


def _clear_exit_guard_property():
    if xbmcgui is None:
        return
    try:
        xbmcgui.Window(10000).clearProperty('IBO.V2.ExitPending')
    except Exception:
        pass


def _busy_dialog_active():
    if xbmc is None:
        return False
    try:
        return bool(
            xbmc.getCondVisibility('Window.IsActive(busydialog)') or
            xbmc.getCondVisibility('Window.IsActive(busydialognocancel)') or
            xbmc.getCondVisibility('Window.IsActive(progressdialog)')
        )
    except Exception:
        return False


def _restore_previous_context(activity):
    """Consume an intentional SAIR using Kodi's own navigation history.

    The plugin root lives in MyVideoNav (10025).  Closing the IBO XML dialogs
    exposes that container and Kodi can briefly reload the same plugin:// URL.
    After the reload/busy dialog is gone, one Action(Back) returns to exactly
    the context that launched the add-on: Home, Video Add-ons, favourites, or
    another caller.  No destination window/path is invented here.
    """
    if xbmc is None or xbmcgui is None or not isinstance(activity, dict):
        return False
    token = str(activity.get('exit_return_token') or '')
    if not token:
        return False
    try:
        requested = float(activity.get('exit_return_requested_at') or 0.0)
    except Exception:
        requested = 0.0
    age = max(0.0, time.time() - requested) if requested else 999.0

    # Stale token must never affect a later deliberate launch.
    if age > 10.0:
        clear_exit_return(token)
        _clear_exit_guard_property()
        log('SAIR: pedido de retorno expirou sem alterar o contexto atual.', 'warning')
        return True
    if age < 0.30 or _busy_dialog_active():
        return False

    try:
        current = int(xbmcgui.getCurrentWindowId())
    except Exception:
        current = 0
    try:
        folder = str(xbmc.getInfoLabel('Container.FolderPath') or '').strip()
    except Exception:
        folder = ''

    if current == 10025:
        # If Kodi already changed the MyVideoNav container away from this add-on,
        # the previous context is already restored: do not go one level too far.
        if folder and not folder.startswith(PLUGIN_URL):
            clear_exit_return(token)
            _clear_exit_guard_property()
            log('SAIR: contexto anterior já restaurado pelo Kodi (%s).' % folder, 'debug')
            return True
        # Normal path observed on Kodi 21: the underlying container is still the
        # IBO plugin root. One Back pops the real Kodi history entry.
        if folder.startswith(PLUGIN_URL) or age >= 1.0:
            try:
                xbmc.executebuiltin('Action(Back)')
                clear_exit_return(token)
                _clear_exit_guard_property()
                log('SAIR: contexto anterior restaurado pelo histórico do Kodi.', 'debug')
                return True
            except Exception as exc:
                log('SAIR: falha ao restaurar contexto anterior: %s' % exc, 'warning')
                return False
        return False

    # If Shell closed straight back to Home/AddonBrowser/another caller, that is
    # already the exact desired result.  Clear the token without another Back.
    if current not in (13000, 13001):
        clear_exit_return(token)
        _clear_exit_guard_property()
        log('SAIR: Kodi já retornou ao contexto anterior (janela %s).' % current, 'debug')
        return True
    return False


def enforce(reason):
    reason = str(reason or '')
    if reason == 'device_blocked':
        message = 'Acesso bloqueado. Uso não autorizado.'
    elif reason in ('access_removed', 'access_not_located'):
        message = 'Este acesso foi removido do painel.'
    else:
        message = 'Limite de conexões ativas atingido.'
    log('Enforcement Health: %s' % reason, 'warning')
    if xbmc is not None:
        try:
            player = xbmc.Player()
            if player.isPlaying():
                player.stop()
        except Exception:
            pass
    clear_playback()
    clear_session()
    if xbmcgui is not None:
        try:
            xbmcgui.Window(10000).setProperty('IBO.V2.Enforced', message)
        except Exception:
            pass


def send_health(panel=None):
    activity = load_activity()
    if not _usage_active(activity) or not should_heartbeat():
        return None
    usage_id = str(activity.get('usage_session_id') or '')
    session = load_session()
    if not session:
        return None
    panel = panel or PanelClient()
    health = panel.health_kodi(session.get('portal_id'), session.get('max_connections'), timeout=6)

    # SAIR may happen while an HTTP request already in flight is returning. The
    # server may have seen that final packet, but from this point on the response
    # belongs to an ended usage session: do not refresh local health timestamps,
    # enforce stale results or schedule follow-up work.
    latest_activity = load_activity()
    if (not _usage_active(latest_activity) or
            (usage_id and str(latest_activity.get('usage_session_id') or '') != usage_id)):
        log('Heartbeat finalizado após SAIR; resposta descartada da sessão encerrada.', 'debug')
        return dict(health or {}, _ended_usage=True)

    latest = load_session()
    if not latest or latest.get('session_id') != session.get('session_id'):
        return health
    latest['last_health_at'] = int(time.time())
    latest['health_mode'] = str(health.get('mode') or latest.get('health_mode') or 'auto')
    latest['health_used'] = int(health.get('used') or 0)
    latest['health_limit'] = int(health.get('limit') or 0)
    if latest['health_mode'] == 'auto':
        latest['auto_refresh_tick'] = int(latest.get('auto_refresh_tick') or 0) + 1
    else:
        latest['auto_refresh_tick'] = 0
    save_session(latest)

    reason = str(health.get('reason') or '')
    if reason == 'access_not_located':
        try:
            state = panel.index_state(timeout=4)
            removed = int(state.get('accounts') or 0) <= 0
            if not removed and str(latest.get('portal_id') or ''):
                portal_id = str(latest.get('portal_id') or '')
                try:
                    check = panel.kodi_access(portal_id, timeout=2.5) or {}
                    denied = str(check.get('access_denied') or '').strip()
                    if check.get('device_blocked') or denied or str(check.get('reason') or '') == 'access_denied':
                        enforce('device_blocked')
                        return dict(health, allowed=False, enforce=True, reason='device_blocked')
                    removed = (not check.get('ok')) and str(check.get('reason') or '') == 'access_not_found'
                except Exception as fast_exc:
                    # Compatibilidade com painéis anteriores ao V2.19. No painel
                    # atual, a confirmação específica nunca deve voltar ao auth.php.
                    log('Heartbeat: kodi_access.php indisponível; confirmação legada será usada: %s' % fast_exc, 'warning')
                    check = panel.auth(timeout=5)
                    ids = {str((row or {}).get('id') or '') for row in (check.get('urls') or []) if isinstance(row, dict)}
                    removed = portal_id not in ids
            if removed:
                enforce('access_removed')
                return dict(health, allowed=False, enforce=True, reason='access_removed')
        except Exception as exc:
            log('Confirmação de acesso removido falhou: %s' % exc, 'warning')

    if not health.get('allowed', True) and health.get('enforce'):
        enforce(reason)
        return health

    latest = load_session()
    if latest and latest.get('health_mode') == 'auto' and int(latest.get('auto_refresh_tick') or 0) >= AUTO_REFRESH_EVERY:
        _refresh_auto(latest, panel)
    return health


def _refresh_auto(session, panel):
    session_id = session.get('session_id')
    try:
        client = session_client(session)
        auth = client.authenticate(timeout=6)
        info = auth.get('user_info') or {}
        latest = load_session()
        if not latest or latest.get('session_id') != session_id:
            return
        if str(latest.get('health_mode') or 'auto') != 'auto':
            latest['auto_refresh_tick'] = 0
            save_session(latest)
            return
        old_max = str(latest.get('max_connections') or '')
        new_max = str(info.get('max_connections') if info.get('max_connections') is not None else '')
        latest['auto_refresh_tick'] = 0
        latest['max_connections'] = new_max
        latest['exp_date'] = str(info.get('exp_date') or latest.get('exp_date') or '')
        save_session(latest)
        if old_max != new_max:
            follow = panel.health_kodi(latest.get('portal_id'), new_max, timeout=6)
            if not follow.get('allowed', True) and follow.get('enforce'):
                enforce(follow.get('reason'))
    except Exception as exc:
        latest = load_session()
        if latest and latest.get('session_id') == session_id:
            latest['auto_refresh_tick'] = 0
            save_session(latest)
        log('Refresh Auto 3min falhou: %s' % exc, 'warning')



def _refresh_banner_only():
    """Atualiza o visual da Home sem reautenticar nem tocar Health.

    O nome histórico é preservado para não mexer no fluxo homologado do
    serviço. Nos Temas 2..5, TMDB ativo usa o feed ``movies.php`` do painel;
    TMDB desativado usa as imagens de Ads. O Tema 2 mantém seu slot de banner
    manual e recebe o carrossel nativo somente quando o modo é TMDB.
    """
    try:
        cache = load_panel()
        theme = str(cache.get('theme') or '1')
        client = PanelClient()

        if theme == '2':
            home_url = str(cache.get('home_url1') or cache.get('home_url2') or '')
            mode = client.backdrop_mode(home_url=home_url, timeout=2)

            if mode == 'tmdb':
                showcase = client.home_showcase(cache, timeout=4, limit=12, mode='tmdb') or {}
                slides = showcase.get('slides') if isinstance(showcase, dict) else []
                slides = slides if isinstance(slides, list) else []
                if slides:
                    cache['_home_showcase_mode'] = 'tmdb'
                    cache['_home_showcase_slides'] = slides
                    cache['_home_showcase_at'] = int(time.time())
                    cache.pop('_banner_url', None)
                    save_panel(cache)
                    _set_banner_url('')
                    _set_home_showcase(slides[0])
                    log('Destaque TMDB do Tema 2 atualizado: %d slide(s).' % len(slides), 'debug')
                    return str((slides[0] or {}).get('image') or '')

                old_mode = str(cache.get('_home_showcase_mode') or '')
                old_slides = cache.get('_home_showcase_slides') or []
                if old_mode == 'tmdb' and isinstance(old_slides, list) and old_slides:
                    _set_banner_url('')
                    _set_home_showcase(old_slides[0])
                    return str((old_slides[0] or {}).get('image') or '')

                cache.pop('_home_showcase_slides', None)
                cache['_home_showcase_mode'] = 'tmdb'
                cache.pop('_banner_url', None)
                save_panel(cache)
                _set_home_showcase(None)
                _set_banner_url('')
                return ''

            # TMDB desligado: limpa qualquer destaque TMDB antigo e volta ao
            # mesmo banner de anúncio já homologado no Tema 2.
            cache.pop('_home_showcase_slides', None)
            cache.pop('_home_showcase_at', None)
            cache['_home_showcase_mode'] = 'manual'
            _set_home_showcase(None)
            url = client.manual_banner_url(timeout=2)
            if url:
                cache['_banner_url'] = url
                save_panel(cache)
                _set_banner_url(url)
                log('Banner de anúncio do Tema 2 atualizado em segundo plano.', 'debug')
                return url
            if cache.pop('_banner_url', None) is not None:
                save_panel(cache)
            else:
                save_panel(cache)
            _set_banner_url('')
            return ''

        _set_banner_url('')
        if theme not in ('3', '4', '5'):
            _set_home_showcase(None)
            return ''

        showcase = client.home_showcase(cache, timeout=4, limit=12) or {}
        slides = showcase.get('slides') if isinstance(showcase, dict) else []
        slides = slides if isinstance(slides, list) else []
        mode = str(showcase.get('mode') or '') if isinstance(showcase, dict) else ''
        if slides:
            cache['_home_showcase_mode'] = mode
            cache['_home_showcase_slides'] = slides
            cache['_home_showcase_at'] = int(time.time())
            save_panel(cache)
            _set_home_showcase(slides[0])
            log('Destaque do Tema %s atualizado: %d slide(s), modo=%s.' % (theme, len(slides), mode or 'desconhecido'), 'debug')
            return str((slides[0] or {}).get('image') or '')

        # Se o painel respondeu em outro modo sem mídia válida, não preserve um
        # destaque antigo de modo diferente. Em falha transitória do mesmo modo,
        # o cache anterior pode continuar sendo usado pela Home.
        old_mode = str(cache.get('_home_showcase_mode') or '')
        old_slides = cache.get('_home_showcase_slides') or []
        if mode and old_mode and mode != old_mode:
            cache.pop('_home_showcase_slides', None)
            cache['_home_showcase_mode'] = mode
            save_panel(cache)
            old_slides = []
        if isinstance(old_slides, list) and old_slides:
            _set_home_showcase(old_slides[0])
            return str((old_slides[0] or {}).get('image') or '')
        _set_home_showcase(None)
        return ''
    except Exception as exc:
        log('Atualização visual da Home em segundo plano falhou: %s' % exc, 'debug')
        return ''

def _panel_sync_worker():
    started = time.time()
    final_text = 'Sincronização concluída'
    _set_sync_text('Sincronizando com o painel...')
    try:
        result = sync_panel_for_open() or {}
        elapsed = time.time() - started
        if result.get('stale'):
            final_text = 'Painel indisponível • usando cache local'
            log('Sincronização de painel em segundo plano usou cache (%.2fs).' % elapsed, 'warning')
        elif result.get('ok'):
            final_text = 'Painel sincronizado'
            log('Sincronização de painel em segundo plano concluída em %.2fs.' % elapsed, 'debug')
            _refresh_banner_only()
        else:
            final_text = 'Sincronização do painel falhou'
            log('Sincronização de painel em segundo plano: %s (%.2fs).' % (result.get('reason') or 'falhou', elapsed), 'warning')
    except Exception as exc:
        final_text = 'Sincronização do painel falhou'
        log('Sincronização de painel em segundo plano falhou: %s' % exc, 'warning')
    finally:
        # Brief status feedback preserves the old sync cue without blocking
        # navigation or Heartbeat for the whole network round-trip.
        _set_sync_text(final_text)
        try:
            if xbmc is not None:
                xbmc.sleep(900)
        except Exception:
            pass
        _set_sync_text('')


def run_service():
    if xbmc is None:
        return
    monitor = xbmc.Monitor()
    panel = PanelClient()
    was_active = False
    last_sync_token = ''
    sync_thread = None
    last_sync_done = 0.0
    last_history_save = 0.0
    last_history_hash = ''
    last_history_position = None
    last_history_total = 0.0
    last_history_meta = {}
    last_history_finalized = ''
    while not monitor.abortRequested():
        try:
            activity = load_activity()
            _restore_previous_context(activity)
            activity = load_activity()

            # Quando o usuário deixa o VideoFullScreen, play_and_wait devolve o
            # controle ao router e o serviço persistente assume o histórico.
            # Grava no máximo a cada 5 s e somente filmes/séries do próprio IBO.
            marker = str(activity.get('playback_hash') or '')
            meta = activity.get('playback_meta') if isinstance(activity.get('playback_meta'), dict) else {}
            if marker and str(meta.get('kind') or '') in ('movie', 'series'):
                if marker != last_history_hash:
                    last_history_hash = marker
                    last_history_save = 0.0
                    last_history_position = None
                    last_history_total = 0.0
                    last_history_meta = dict(meta)
                    last_history_finalized = ''
                try:
                    hist_player = xbmc.Player()
                    playing_video = bool(hist_player.isPlayingVideo())
                    current = ''
                    if playing_video:
                        try:
                            current = hist_player.getPlayingFile() or ''
                        except Exception:
                            pass
                    own_file = bool(playing_video and (not current or playback_fingerprint(current) == marker))
                    if own_file:
                        # Amostra a posição a cada volta (~1 s), mas mantém a
                        # escrita em disco homologada em no máximo uma vez a
                        # cada 5 s. Assim Stop pode persistir a última amostra
                        # sem aumentar o ritmo normal de I/O do histórico.
                        pos = float(hist_player.getTime() or 0.0)
                        total = float(hist_player.getTotalTime() or 0.0)
                        last_history_position = pos
                        if total > 0.0:
                            last_history_total = total
                        last_history_meta = dict(meta)
                        if time.time() - last_history_save >= 5.0:
                            if record_progress(meta, pos, total):
                                _publish_history_revision(meta, pos, total, final=False)
                            last_history_save = time.time()
                    elif last_history_position is not None and last_history_finalized != marker:
                        # O marcador ainda pertence ao ONEPLAY, mas o player já
                        # parou/trocou. Grave uma última amostra antes de
                        # _playback_active() consumir o marcador. O repaint da
                        # tela aberta recebe um sinal específico de finalização.
                        if record_progress(last_history_meta or meta, last_history_position, last_history_total):
                            _publish_history_revision(last_history_meta or meta, last_history_position, last_history_total, final=True)
                        last_history_finalized = marker
                        last_history_save = time.time()
                        log('Histórico em background: posição final sincronizada após Stop.', 'debug')
                except Exception as exc:
                    log('Histórico em background: %s' % exc, 'debug')
            elif not marker:
                last_history_hash = ''
                last_history_save = 0.0
                last_history_position = None
                last_history_total = 0.0
                last_history_meta = {}
                last_history_finalized = ''

            own_playback_active = _playback_active()
            _set_background_video_active(own_playback_active)
            active = _usage_active(activity) and (bool(activity.get('ui_active')) or own_playback_active)

            # A panel/theme refresh request never runs in the plugin interpreter.
            # Keep it on a daemon worker owned by the persistent service so Home
            # stays instant and Heartbeat remains responsive.
            token = str(activity.get('panel_sync_token') or '')
            if sync_thread is not None and not sync_thread.is_alive() and last_sync_token:
                # Record completion once. Duplicate plugin invocations after
                # playback must not start another 50+s visual sync immediately.
                if last_sync_done <= 0:
                    last_sync_done = time.time()
            if token and token != last_sync_token and (sync_thread is None or not sync_thread.is_alive()):
                last_sync_token = token
                if last_sync_done and (time.time() - last_sync_done) < 90:
                    log('Sincronização de painel ignorada pelo cooldown de sessão.', 'debug')
                    # O cooldown só evita o snapshot completo. Banner é uma
                    # leitura visual curta e deve acompanhar o painel ao reabrir.
                    banner_thread = threading.Thread(target=_refresh_banner_only, name='IBO-BannerRefresh')
                    banner_thread.daemon = True
                    banner_thread.start()
                else:
                    _set_sync_text('Sincronizando com o painel...')
                    sync_thread = threading.Thread(target=_panel_sync_worker, name='IBO-PanelSync')
                    sync_thread.daemon = True
                    sync_thread.start()
                    last_sync_done = 0.0

            if active:
                session = load_session()
                if session:
                    last = int(session.get('last_health_at') or 0)
                    # Entering the IBO must put the device Online immediately;
                    # after that preserve the homologated 60 s cadence.
                    due = (not was_active) or last <= 0 or int(time.time()) - last >= HEARTBEAT_SECONDS
                    if due:
                        try:
                            result = send_health(panel)
                            if result and not result.get('_ended_usage'):
                                log('Heartbeat OK: allowed=%s used=%s limit=%s mode=%s' % (
                                    result.get('allowed', True), result.get('used', 0),
                                    result.get('limit', 0), result.get('mode', '')), 'debug')
                        except Exception as exc:
                            log('Heartbeat falhou: %s' % exc, 'warning')
            if was_active and not active:
                log('Heartbeat encerrado: sessão de uso do IBO finalizada.', 'debug')
            was_active = active
        except Exception as exc:
            log('Loop Health: %s' % exc, 'error')
        if monitor.waitForAbort(1.0):
            break
    _set_background_video_active(False)
