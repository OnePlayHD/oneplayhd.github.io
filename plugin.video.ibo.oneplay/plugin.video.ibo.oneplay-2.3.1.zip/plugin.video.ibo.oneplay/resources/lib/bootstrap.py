# -*- coding: utf-8 -*-
"""Cold-start launcher for ONEPLAY IBO 2.3.1.

Resolver/exit handling stays minimal. On a deliberate launch the transient
plugin root is detached and IBOShell is shown before importing router.py and its
large auth/screens/player dependency graph. UI ownership remains in the same
plugin invoker; no service-owned window, RunScript or modal cover is introduced.
"""
import base64
import sys
import time
import urllib.parse

from .constants import PLUGIN_URL
from .log import log
from .shell import open_shell, close_shell
from .state import clear_exit_return, mark_ui

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except Exception:
    xbmc = None
    xbmcgui = None
    xbmcplugin = None

_EXIT_GUARD_PROPERTY = 'IBO.V2.ExitPending'


def _complete_directory(handle):
    if xbmcplugin is None or handle is None:
        return
    try:
        xbmcplugin.endOfDirectory(int(handle), succeeded=True, updateListing=False, cacheToDisc=False)
    except TypeError:
        try:
            xbmcplugin.endOfDirectory(int(handle), True)
        except Exception as exc:
            log('Falha ao concluir diretório do plugin: %s' % exc, 'warning')
    except Exception as exc:
        log('Falha ao concluir diretório do plugin: %s' % exc, 'warning')


def _detach_plugin_root(handle):
    if xbmcplugin is None or handle is None:
        return False
    try:
        xbmcplugin.endOfDirectory(int(handle), succeeded=False, updateListing=False, cacheToDisc=False)
        log('Navegação: raiz plugin:// do IBO destacada; histórico anterior preservado.', 'debug')
        return True
    except TypeError:
        try:
            xbmcplugin.endOfDirectory(int(handle), False)
            log('Navegação: raiz plugin:// do IBO destacada por API compatível; histórico anterior preservado.', 'debug')
            return True
        except Exception as exc:
            log('Navegação: destaque da raiz indisponível; mantendo fluxo homologado 2.1.4: %s' % exc, 'warning')
    except Exception as exc:
        log('Navegação: destaque da raiz indisponível; mantendo fluxo homologado 2.1.4: %s' % exc, 'warning')
    _complete_directory(handle)
    return False


def _clear_exit_guard():
    if xbmcgui is None:
        return
    try:
        xbmcgui.Window(10000).clearProperty(_EXIT_GUARD_PROPERTY)
    except Exception:
        pass


def _consume_exit_guard():
    if xbmcgui is None:
        return False
    try:
        window = xbmcgui.Window(10000)
        raw = str(window.getProperty(_EXIT_GUARD_PROPERTY) or '')
        if not raw:
            return False
        try:
            age = max(0.0, time.time() - float(raw))
        except Exception:
            age = 999.0
        current = int(xbmcgui.getCurrentWindowId())
        consume = age <= 3.0 and current == 10025
        if consume:
            window.clearProperty(_EXIT_GUARD_PROPERTY)
            log('Reentrada automática do MyVideoNav interceptada após SAIR.', 'debug')
        elif age > 3.0:
            window.clearProperty(_EXIT_GUARD_PROPERTY)
        return consume
    except Exception as exc:
        log('Falha ao consumir guard de saída: %s' % exc, 'debug')
        return False


def _request_history_return_after_guarded_reentry():
    if xbmc is None or xbmcgui is None:
        return False
    deadline = time.time() + 0.45
    while time.time() < deadline:
        try:
            busy = bool(
                xbmc.getCondVisibility('Window.IsActive(busydialog)') or
                xbmc.getCondVisibility('Window.IsActive(busydialognocancel)') or
                xbmc.getCondVisibility('Window.IsActive(progressdialog)')
            )
        except Exception:
            busy = False
        if busy:
            try:
                xbmc.sleep(10)
            except Exception:
                break
            continue
        try:
            current = int(xbmcgui.getCurrentWindowId())
        except Exception:
            current = 0
        try:
            folder = str(xbmc.getInfoLabel('Container.FolderPath') or '').strip()
        except Exception:
            folder = ''
        if current == 10025:
            if folder and not folder.startswith(PLUGIN_URL):
                return True
            if folder.startswith(PLUGIN_URL) or not folder:
                try:
                    xbmc.executebuiltin('Action(Back)')
                    log('SAIR: reentrada transitória concluída; retorno solicitado pelo histórico do Kodi.', 'debug')
                    return True
                except Exception as exc:
                    log('SAIR: reentrada concluída, mas o retorno não pôde ser solicitado: %s' % exc, 'debug')
                    return False
        elif current not in (0, 13000, 13001):
            return True
        try:
            xbmc.sleep(10)
        except Exception:
            break
    return False


def _resolve_media_invocation(handle):
    try:
        query = str(sys.argv[2] or '') if len(sys.argv) > 2 else ''
    except Exception:
        query = ''
    if query.startswith('?'):
        query = query[1:]
    try:
        params = urllib.parse.parse_qs(query, keep_blank_values=False)
    except Exception:
        params = {}
    action = str((params.get('ibo_action') or [''])[0] or '').strip().lower()
    if action != 'resolve_media':
        return False

    # Resolver-only dependencies stay off the deliberate cold-start path.
    # They are imported only for Kodi's secondary plugin:// -> DynPath call.
    from .ffmpeg_direct import configure_ffmpeg_direct, ffmpeg_direct_available, ffmpeg_direct_format
    from .media_relay import is_current_relay_url, relay_mime_for

    success = False
    item = xbmcgui.ListItem(label='') if xbmcgui is not None else None
    try:
        encoded = str((params.get('target') or [''])[0] or '').strip()
        if not encoded:
            raise ValueError('target ausente')
        padding = '=' * ((4 - len(encoded) % 4) % 4)
        target = base64.urlsafe_b64decode((encoded + padding).encode('ascii')).decode('utf-8')
        if not is_current_relay_url(target):
            raise ValueError('target fora do relay atual')
        if item is None:
            raise RuntimeError('ListItem indisponível')
        item.setPath(target)
        try:
            item.setMimeType(relay_mime_for(target))
            item.setContentLookup(False)
            item.setProperty('IsPlayable', 'true')
        except Exception:
            pass
        fd_requested = str((params.get('fd') or ['0'])[0] or '0') == '1'
        realtime = str((params.get('rt') or ['0'])[0] or '0') == '1'
        fd_applied = False
        fmt = ''
        if fd_requested:
            fmt = ffmpeg_direct_format(target)
            if fmt and ffmpeg_direct_available():
                fd_applied = configure_ffmpeg_direct(item, fmt, 'live' if realtime else 'vod')
            if not fd_applied:
                log('Resolver seguro de mídia: FFmpeg Direct solicitado, mas indisponível; DynPath seguirá no padrão Kodi.', 'warning')
        success = True
        if fd_applied:
            log('Resolver seguro de mídia: Path plugin convertido em DynPath localhost + FFmpeg Direct (%s).' % fmt, 'debug')
        else:
            log('Resolver seguro de mídia: Path plugin convertido em DynPath localhost.', 'debug')
    except Exception as exc:
        log('Resolver seguro de mídia recusou a solicitação: %s' % exc, 'warning')
    if xbmcplugin is not None and handle is not None and item is not None:
        try:
            xbmcplugin.setResolvedUrl(int(handle), bool(success), item)
        except Exception as exc:
            log('Resolver seguro de mídia não conseguiu concluir o handle: %s' % exc, 'error')
    return True


def _sync_native_dns_override():
    """Apply the explicit Kodi-native DNS toggle without touching fast local routes.

    With the option off (default), dns.py is not imported unless this interpreter
    had already installed the override, keeping the homologated cold path intact.
    """
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon()
        enabled = (addon.getSetting('dns_override') or 'false').strip().lower() == 'true'
        if not enabled and 'resources.lib.dns' not in sys.modules:
            return False
        from .dns import apply_configured_override
        return bool(apply_configured_override(addon=addon))
    except Exception as exc:
        log('DNS alternativo: configuração nativa não pôde ser aplicada (%s).' % exc.__class__.__name__, 'warning')
        return False


def run_plugin():
    handle = None
    try:
        handle = int(sys.argv[1])
    except Exception:
        pass

    if _resolve_media_invocation(handle):
        return

    if _consume_exit_guard():
        _complete_directory(handle)
        if _request_history_return_after_guarded_reentry():
            log('Reentrada automática concluída; retorno entregue ao histórico do Kodi.', 'debug')
        else:
            log('Reentrada automática concluída; serviço manterá o fallback de retorno.', 'debug')
        return

    clear_exit_return()
    _clear_exit_guard()
    root_detached = _detach_plugin_root(handle)
    shell = open_shell()
    try:
        mark_ui(True, 'root')
    except Exception:
        pass

    # DNS alternativo é uma escolha manual do usuário e só é sincronizado
    # depois que o Shell já está visível. Resolver local/SAIR continuam no fast-path.
    _sync_native_dns_override()

    # Heavy dependency graph starts only after the ONEPLAY shell is visible.
    try:
        from .router import run_session_from_bootstrap
        return run_session_from_bootstrap(handle, root_detached, shell)
    except Exception as exc:
        try:
            mark_ui(False, 'bootstrap_error')
        except Exception:
            pass
        close_shell(shell)
        log('Falha no bootstrap tardio do ONEPLAY: %s' % exc, 'error')
        try:
            if xbmcgui is not None:
                xbmcgui.Dialog().ok('ONEPLAY IBO', 'Falha ao iniciar o ONEPLAY.\nReinicie o Kodi e tente novamente.')
        except Exception:
            pass
        return None
