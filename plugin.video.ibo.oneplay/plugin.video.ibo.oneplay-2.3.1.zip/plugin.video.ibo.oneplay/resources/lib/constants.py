# -*- coding: utf-8 -*-
ADDON_ID = 'plugin.video.ibo.oneplay'
ADDON_NAME = 'IBO'
ADDON_VERSION = '2.3.1'
STATE_SCHEMA = 2
DEFAULT_PANEL_URL = 'https://ibo.oneplayhd.com/api/'
USER_AGENT = 'IBO-Kodi/2.3.1'
XTREAM_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'
DEVICE_TYPE = 'kodi'
APP_VERSION_CODE = 328
HEARTBEAT_SECONDS = 60
AUTO_REFRESH_EVERY = 3
PANEL_AES_KEY1 = b'FIJo0GopkIRAPjbR'
PANEL_AES_KEY2 = b'RbjPARIkpoG0oJIF'
MAX_RESPONSE_BYTES = 16 * 1024 * 1024
PLUGIN_URL = 'plugin://plugin.video.ibo.oneplay/'
