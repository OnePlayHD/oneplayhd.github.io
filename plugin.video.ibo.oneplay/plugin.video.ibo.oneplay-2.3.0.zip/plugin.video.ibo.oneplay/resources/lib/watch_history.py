# -*- coding: utf-8 -*-
"""Histórico privado de reprodução do ONEPLAY IBO.

Nunca lê/escreve MyVideos*.db, Textures*.db ou Thumbnails do Kodi. O arquivo
vive apenas em addon_data/plugin.video.ibo.oneplay e é protegido por um mutex
de filesystem porque default.py e service.py usam intérpretes Python distintos.
"""
import os
import shutil
import time

from .log import log
from .storage import read_json, state_path, write_json

HISTORY_PATH = state_path('watch_history_v2.json')
LOCK_DIR = HISTORY_PATH + '.lock'
HISTORY_SCHEMA = 1
MAX_ITEMS = 240
RESUME_MIN_SECONDS = 30.0
WATCHED_RATIO = 0.90


def _now():
    return int(time.time())


def _key(kind, stream_id):
    kind = str(kind or '').strip().lower()
    sid = str(stream_id or '').strip()
    return '%s:%s' % (kind, sid) if kind in ('movie', 'series') and sid else ''


def _empty():
    return {'schema': HISTORY_SCHEMA, 'updated_at': 0, 'items': {}}


def _load_unlocked():
    data = read_json(HISTORY_PATH, {})
    if not isinstance(data, dict) or int(data.get('schema') or 0) != HISTORY_SCHEMA:
        return _empty()
    items = data.get('items')
    if not isinstance(items, dict):
        data['items'] = {}
    return data


def load_history():
    return _load_unlocked()


def _acquire_lock(timeout=0.65, stale=8.0):
    deadline = time.monotonic() + max(0.10, float(timeout))
    while time.monotonic() < deadline:
        try:
            os.mkdir(LOCK_DIR)
            try:
                with open(os.path.join(LOCK_DIR, 'owner'), 'w', encoding='ascii') as fh:
                    fh.write('%s\n%s\n' % (os.getpid(), time.time()))
            except Exception:
                pass
            return True
        except FileExistsError:
            try:
                age = time.time() - os.path.getmtime(LOCK_DIR)
            except Exception:
                age = 0.0
            if age > stale:
                try:
                    shutil.rmtree(LOCK_DIR)
                    continue
                except Exception:
                    pass
            time.sleep(0.025)
        except Exception:
            time.sleep(0.025)
    return False


def _release_lock():
    try:
        shutil.rmtree(LOCK_DIR)
    except Exception:
        pass


def _write_mutation(mutator):
    locked = _acquire_lock()
    if not locked:
        log('Histórico: mutex ocupado; atualização adiada para evitar sobrescrita.', 'debug')
        return False
    try:
        data = _load_unlocked()
        changed = bool(mutator(data))
        if not changed:
            return True
        items = data.get('items') or {}
        if len(items) > MAX_ITEMS:
            ordered = sorted(items.items(), key=lambda pair: int((pair[1] or {}).get('updated_at') or 0), reverse=True)
            data['items'] = dict(ordered[:MAX_ITEMS])
        data['schema'] = HISTORY_SCHEMA
        data['updated_at'] = _now()
        write_json(HISTORY_PATH, data)
        return True
    except Exception as exc:
        log('Histórico: falha ao persistir progresso: %s' % exc, 'warning')
        return False
    finally:
        _release_lock()


def _safe_float(value):
    try:
        return max(0.0, float(value or 0.0))
    except Exception:
        return 0.0


def _normalize_meta(meta):
    src = meta if isinstance(meta, dict) else {}
    allowed = (
        'kind', 'stream_id', 'title', 'extension', 'art', 'plot', 'year',
        'season', 'episode', 'series_id', 'series_title', 'series_art',
    )
    out = {}
    for field in allowed:
        value = src.get(field)
        if value is None:
            continue
        if field in ('season', 'episode', 'year'):
            try:
                out[field] = int(value)
            except Exception:
                out[field] = str(value or '')
        else:
            out[field] = str(value or '')
    out['kind'] = str(out.get('kind') or '').lower()
    out['stream_id'] = str(out.get('stream_id') or '')
    return out


def record_progress(meta, position, total=0.0):
    info = _normalize_meta(meta)
    key = _key(info.get('kind'), info.get('stream_id'))
    if not key:
        return False
    pos = _safe_float(position)
    length = _safe_float(total)
    def mutate(data):
        items = data.setdefault('items', {})
        previous = items.get(key) if isinstance(items.get(key), dict) else {}
        row = dict(previous)
        row.update(info)
        effective_length = length if length > 0.0 else _safe_float(previous.get('total'))
        effective_ratio = (pos / effective_length) if effective_length > 0.0 else 0.0
        effective_watched = bool(effective_length >= 60.0 and effective_ratio >= WATCHED_RATIO)
        row['position'] = round(pos, 3)
        row['total'] = round(effective_length, 3)
        row['percent'] = round(min(100.0, max(0.0, effective_ratio * 100.0)), 2) if effective_length > 0 else 0.0
        row['watched'] = effective_watched
        row['updated_at'] = _now()
        row.setdefault('started_at', row['updated_at'])
        items[key] = row
        return True

    return _write_mutation(mutate)



def mark_watched(meta, total=0.0):
    info = _normalize_meta(meta)
    key = _key(info.get('kind'), info.get('stream_id'))
    if not key:
        return False
    length = _safe_float(total)

    def mutate(data):
        items = data.setdefault('items', {})
        previous = items.get(key) if isinstance(items.get(key), dict) else {}
        row = dict(previous)
        row.update(info)
        effective_length = length if length > 0.0 else _safe_float(previous.get('total'))
        row['total'] = round(effective_length, 3)
        row['watched'] = True
        row['percent'] = 100.0
        if effective_length > 0.0:
            row['position'] = round(effective_length, 3)
        else:
            row['position'] = round(_safe_float(previous.get('position')), 3)
        row['updated_at'] = _now()
        row.setdefault('started_at', row['updated_at'])
        items[key] = row
        return True

    return _write_mutation(mutate)

def get_entry(kind, stream_id):
    key = _key(kind, stream_id)
    if not key:
        return {}
    row = (load_history().get('items') or {}).get(key)
    return dict(row) if isinstance(row, dict) else {}


def resume_seconds(kind, stream_id):
    row = get_entry(kind, stream_id)
    if not row or row.get('watched'):
        return 0.0
    pos = _safe_float(row.get('position'))
    total = _safe_float(row.get('total'))
    if pos < RESUME_MIN_SECONDS:
        return 0.0
    if total > 0 and pos >= total * WATCHED_RATIO:
        return 0.0
    return pos


def is_watched(kind, stream_id):
    return bool(get_entry(kind, stream_id).get('watched'))


def _continuable(row):
    if not isinstance(row, dict) or row.get('watched'):
        return False
    pos = _safe_float(row.get('position'))
    total = _safe_float(row.get('total'))
    if pos < RESUME_MIN_SECONDS:
        return False
    if total > 0 and pos >= total * WATCHED_RATIO:
        return False
    return True


def continue_movies(limit=80):
    rows = [dict(row) for row in (load_history().get('items') or {}).values()
            if isinstance(row, dict) and row.get('kind') == 'movie' and _continuable(row)]
    rows.sort(key=lambda row: int(row.get('updated_at') or 0), reverse=True)
    result = []
    for row in rows[:max(1, int(limit))]:
        result.append({
            'stream_id': str(row.get('stream_id') or ''),
            'name': str(row.get('title') or 'Filme'),
            'stream_icon': str(row.get('art') or ''),
            'container_extension': str(row.get('extension') or 'mp4'),
            'plot': str(row.get('plot') or ''),
            'year': row.get('year') or '',
            '_ibo_history': True,
            '_ibo_resume': row.get('position') or 0,
            '_ibo_percent': row.get('percent') or 0,
        })
    return result


def continue_series(limit=80):
    # Uma série aparece uma vez, apontando para o episódio parcial mais recente.
    grouped = {}
    for row in (load_history().get('items') or {}).values():
        if not isinstance(row, dict) or row.get('kind') != 'series' or not _continuable(row):
            continue
        series_id = str(row.get('series_id') or '')
        if not series_id:
            continue
        old = grouped.get(series_id)
        if old is None or int(row.get('updated_at') or 0) > int(old.get('updated_at') or 0):
            grouped[series_id] = dict(row)
    rows = sorted(grouped.values(), key=lambda row: int(row.get('updated_at') or 0), reverse=True)
    result = []
    for row in rows[:max(1, int(limit))]:
        result.append({
            'series_id': str(row.get('series_id') or ''),
            'name': str(row.get('series_title') or row.get('title') or 'Série'),
            'cover': str(row.get('series_art') or row.get('art') or ''),
            'plot': str(row.get('plot') or ''),
            '_ibo_history': True,
            '_ibo_resume_season': row.get('season') or 0,
            '_ibo_resume_episode': row.get('episode') or 0,
            '_ibo_resume_stream_id': str(row.get('stream_id') or ''),
            '_ibo_resume': row.get('position') or 0,
            '_ibo_percent': row.get('percent') or 0,
        })
    return result


def clear_history():
    def mutate(data):
        data['items'] = {}
        return True
    return _write_mutation(mutate)


def format_position(value):
    total = int(max(0.0, _safe_float(value)))
    hours, rem = divmod(total, 3600)
    minutes, seconds = divmod(rem, 60)
    if hours:
        return '%d:%02d:%02d' % (hours, minutes, seconds)
    return '%d:%02d' % (minutes, seconds)


def latest_series_resume(series_id):
    sid = str(series_id or '')
    if not sid:
        return {}
    rows = [dict(row) for row in (load_history().get('items') or {}).values()
            if isinstance(row, dict) and row.get('kind') == 'series'
            and str(row.get('series_id') or '') == sid and _continuable(row)]
    rows.sort(key=lambda row: int(row.get('updated_at') or 0), reverse=True)
    return rows[0] if rows else {}
