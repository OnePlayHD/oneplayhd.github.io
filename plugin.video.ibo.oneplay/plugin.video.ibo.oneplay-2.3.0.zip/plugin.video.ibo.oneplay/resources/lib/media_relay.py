# -*- coding: utf-8 -*-
"""Credential-safe loopback media relay for ONEPLAY IBO.

Security and transport contract:
- Kodi/VideoPlayer sees only 127.0.0.1 URLs with opaque random ids.
- Xtream credentials/upstream URLs live only in Python memory.
- Redirects are followed inside the relay and never exposed to Kodi.
- HLS manifests are recursively rewritten (variants, segments, keys, maps, media).
- VOD/TS is streamed incrementally; Range/206 is passed through.
- HEAD/Stat is answered locally and never blocks on an upstream server.
- Stop scrubs upstream URLs/credentials immediately but leaves a short metadata
  tombstone so Kodi's post-stop CSaveFileState::Stat returns instantly.
"""
import http.client
import http.cookiejar
import json
import os
import re
import secrets
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

try:
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
except ImportError:  # pragma: no cover
    BaseHTTPRequestHandler = None
    ThreadingHTTPServer = None

from .constants import XTREAM_USER_AGENT
from .log import log
from .storage import delete, read_json, state_path, write_json

_RELAY_STATE = state_path('media_relay_v1.json')
_RELAY_VERSION = 4
_CONTROL_PATH = '/_ibo/register'
_RELEASE_PATH = '/_ibo/release'
_MAX_CONTROL_BODY = 64 * 1024
_MAX_MANIFEST_BYTES = 2 * 1024 * 1024
_COPY_CHUNK = 128 * 1024
_LIVE_TS_COPY_CHUNK = 16 * 1024
_RESOURCE_COPY_CHUNK = 64 * 1024
_VOD_RESUME_ATTEMPTS = 2
_ENTRY_TTL = 6 * 60 * 60
_RELEASE_TOMBSTONE_TTL = 45.0
_MAX_ENTRIES = 8192
_URI_QUOTED_RE = re.compile(r'(?i)(URI\s*=\s*)(["\'])(.*?)(\2)')
_URI_BARE_RE = re.compile(r'(?i)(URI\s*=\s*)([^,\s]+)')


def _safe_kind(value):
    kind = str(value or '').strip().lower()
    return kind if kind in ('live', 'movie', 'series', 'hls', 'resource') else 'resource'


def _valid_upstream(url):
    try:
        parsed = urllib.parse.urlparse(str(url or '').strip())
    except Exception:
        return False
    return parsed.scheme in ('http', 'https') and bool(parsed.netloc)


def _suffix_for(url, kind=''):
    try:
        path = (urllib.parse.urlparse(str(url or '')).path or '').lower()
    except Exception:
        path = ''
    for suffix in ('.m3u8', '.mp4', '.mkv', '.ts', '.m4s', '.aac', '.key', '.vtt', '.webvtt'):
        if path.endswith(suffix):
            return suffix
    if str(kind) == 'live':
        return '.m3u8'
    if str(kind) in ('movie', 'series'):
        return '.mp4'
    return '.bin'


def _mime_for(url='', kind=''):
    suffix = _suffix_for(url, kind)
    return {
        '.m3u8': 'application/vnd.apple.mpegurl',
        '.mp4': 'video/mp4',
        '.mkv': 'video/x-matroska',
        '.ts': 'video/mp2t',
        '.m4s': 'video/iso.segment',
        '.aac': 'audio/aac',
        '.vtt': 'text/vtt',
        '.webvtt': 'text/vtt',
        '.key': 'application/octet-stream',
    }.get(suffix, 'application/octet-stream')


class _Registry(object):
    def __init__(self, port):
        self.port = int(port)
        self._lock = threading.RLock()
        self._entries = {}
        self._reverse = {}

    def _drop_locked(self, token):
        row = self._entries.pop(token, None)
        if not row:
            return
        key = row.get('reverse_key')
        if key and self._reverse.get(key) == token:
            self._reverse.pop(key, None)

    def _cleanup_locked(self):
        now = time.monotonic()
        expired = []
        for token, row in self._entries.items():
            released_at = float(row.get('released_at') or 0.0)
            if released_at:
                if now - released_at > _RELEASE_TOMBSTONE_TTL:
                    expired.append(token)
            elif now - float(row.get('last') or row.get('created') or now) > _ENTRY_TTL:
                expired.append(token)
        for token in expired:
            self._drop_locked(token)
        overflow = len(self._entries) - _MAX_ENTRIES
        if overflow > 0:
            victims = sorted(self._entries.items(), key=lambda item: float(item[1].get('last') or 0.0))[:overflow]
            for token, _row in victims:
                self._drop_locked(token)

    def add(self, url, kind='resource', session_id='', root=False):
        url = str(url or '').strip()
        if not _valid_upstream(url):
            raise ValueError('upstream inválido')
        kind = _safe_kind(kind)
        session_id = str(session_id or '').strip() or secrets.token_urlsafe(24)
        reverse_key = '%s\n%s\n%s' % (session_id, kind, url)
        now = time.monotonic()
        with self._lock:
            self._cleanup_locked()
            existing = self._reverse.get(reverse_key)
            if existing and existing in self._entries and not self._entries[existing].get('released_at'):
                self._entries[existing]['last'] = now
                return existing, session_id
            token = secrets.token_urlsafe(32)
            self._entries[token] = {
                'url': url,
                'kind': kind,
                'session_id': session_id,
                'root': bool(root),
                'created': now,
                'last': now,
                'released_at': 0.0,
                'reverse_key': reverse_key,
                'suffix': _suffix_for(url, kind),
                'content_type': _mime_for(url, kind),
                'content_length': '',
                'accept_ranges': 'bytes' if kind in ('movie', 'series') else '',
                'etag': '',
                'last_modified': '',
            }
            self._reverse[reverse_key] = token
            self._cleanup_locked()
            return token, session_id

    def get(self, token):
        with self._lock:
            self._cleanup_locked()
            row = self._entries.get(str(token or ''))
            if not row:
                return None
            row['last'] = time.monotonic()
            return dict(row)

    def update_meta(self, token, headers):
        with self._lock:
            row = self._entries.get(str(token or ''))
            if not row:
                return
            content_type = str(headers.get('Content-Type') or headers.get('content-type') or '').strip()
            content_length = str(headers.get('Content-Length') or headers.get('content-length') or '').strip()
            content_range = str(headers.get('Content-Range') or headers.get('content-range') or '').strip()
            accept_ranges = str(headers.get('Accept-Ranges') or headers.get('accept-ranges') or '').strip()
            etag = str(headers.get('ETag') or headers.get('etag') or '').strip()
            last_modified = str(headers.get('Last-Modified') or headers.get('last-modified') or '').strip()
            if content_type:
                row['content_type'] = content_type
            # Em resposta 206, Content-Length é somente o pedaço solicitado.
            # Para o HEAD sintético/Stat do Kodi precisamos guardar o tamanho
            # TOTAL indicado por Content-Range, nunca o tamanho parcial.
            total_length = ''
            match = re.search(r'/\s*(\d+)\s*$', content_range) if content_range else None
            if match:
                total_length = match.group(1)
            elif content_length.isdigit():
                total_length = content_length
            if total_length.isdigit():
                row['content_length'] = total_length
            if accept_ranges:
                row['accept_ranges'] = accept_ranges
            if etag:
                row['etag'] = etag
            if last_modified:
                row['last_modified'] = last_modified
            row['last'] = time.monotonic()

    def retire_token(self, token):
        """Make one media handle terminal without releasing sibling resources.

        Used for a direct Live TS root after its upstream transport has ended or
        timed out. Kodi may retry a transient curl error automatically; a retired
        handle answers 410 immediately instead of reopening the same stalled
        provider connection for another 20 s retry cycle.
        """
        token = str(token or '').strip()
        if not token:
            return False
        now = time.monotonic()
        with self._lock:
            row = self._entries.get(token)
            if not row:
                return False
            key = row.get('reverse_key')
            if key and self._reverse.get(key) == token:
                self._reverse.pop(key, None)
            row['url'] = ''
            row['reverse_key'] = ''
            row['released_at'] = now
            row['last'] = now
            self._cleanup_locked()
            return True

    def release_session(self, session_id):
        """Scrub secrets now; retain only non-secret metadata briefly for HEAD/Stat."""
        session_id = str(session_id or '').strip()
        if not session_id:
            return 0
        now = time.monotonic()
        count = 0
        with self._lock:
            for token, row in self._entries.items():
                if row.get('session_id') != session_id:
                    continue
                key = row.get('reverse_key')
                if key and self._reverse.get(key) == token:
                    self._reverse.pop(key, None)
                # Critical: credential-bearing upstream URL leaves memory now.
                row['url'] = ''
                row['reverse_key'] = ''
                row['released_at'] = now
                row['last'] = now
                count += 1
            self._cleanup_locked()
        return count

    def local_url(self, token, upstream_url='', kind=''):
        return 'http://127.0.0.1:%d/v1/%s/stream%s' % (
            self.port, str(token), _suffix_for(upstream_url, kind)
        )

    def clear(self):
        with self._lock:
            self._entries.clear()
            self._reverse.clear()


class _RelayContext(object):
    def __init__(self, port, control_token):
        self.port = int(port)
        self.control_token = str(control_token)
        self.registry = _Registry(port)
        self.cookie_jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.cookie_jar))

    def open_upstream(self, url, method='GET', headers=None, timeout=20.0):
        hdr = {
            'User-Agent': XTREAM_USER_AGENT,
            'Accept': '*/*',
            'Accept-Encoding': 'identity',
            'Connection': 'close',
        }
        for key, value in (headers or {}).items():
            if value:
                hdr[str(key)] = str(value)
        req = urllib.request.Request(str(url), headers=hdr, method=str(method or 'GET').upper())
        # Não serialize a abertura upstream: FFmpeg/HLS faz requisições paralelas
        # de playlists/segmentos e o lock antigo transformava latência de rede em
        # fila, produzindo stalls/watchdog no aparelho real. CookieJar já protege
        # sua estrutura interna com RLock no CPython; o opener/redirect handlers
        # são usados sem estado por requisição.
        return self.opener.open(req, timeout=max(3.0, float(timeout or 0.0)))


class _RelayHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    # HLS/FFmpeg can open several loopback connections at once. A larger listen
    # backlog prevents metadata/HEAD requests from sitting behind media bursts.
    request_queue_size = 64
    block_on_close = False

    def handle_error(self, request, client_address):
        # Kodi routinely closes loopback sockets while stopping/seeking. Those
        # aborts are normal lifecycle, not add-on failures, and must not flood log.
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionResetError, ConnectionAbortedError, BrokenPipeError, socket.timeout)):
            return
        try:
            super(_RelayHTTPServer, self).handle_error(request, client_address)
        except Exception:
            pass


class _RelayHandler(BaseHTTPRequestHandler):
    # One request per local TCP connection. This deliberately avoids HTTP/1.1
    # keep-alive wait states that previously delayed Stop and generated Win10054.
    protocol_version = 'HTTP/1.0'
    server_version = 'IBORelay/4'
    sys_version = ''
    # Small loopback metadata replies should leave immediately.
    wbufsize = 0
    disable_nagle_algorithm = True

    def log_message(self, _format, *args):
        return

    @property
    def context(self):
        return self.server.relay_context

    def _begin(self, status, content_type='text/plain; charset=utf-8', content_length=None, extra=None):
        self.close_connection = True
        self.send_response(int(status))
        if content_type:
            self.send_header('Content-Type', str(content_type))
        if content_length is not None:
            self.send_header('Content-Length', str(content_length))
        self.send_header('Connection', 'close')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        for name, value in (extra or {}).items():
            if value not in (None, ''):
                self.send_header(str(name), str(value))
        self.end_headers()
        try:
            self.wfile.flush()
        except Exception:
            pass

    def _plain(self, status, text=''):
        body = str(text or '').encode('utf-8')
        self._begin(status, content_length=len(body))
        if self.command != 'HEAD' and body:
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                pass

    def _json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        self._begin(status, 'application/json; charset=utf-8', len(body))
        if self.command != 'HEAD':
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                pass

    def _authorized_control(self):
        supplied = str(self.headers.get('X-IBO-Relay-Token') or '')
        expected = str(self.context.control_token or '')
        return bool(supplied and expected and secrets.compare_digest(supplied, expected))

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path not in (_CONTROL_PATH, _RELEASE_PATH):
            return self._plain(404, 'Not found')
        if not self._authorized_control():
            return self._plain(403, 'Forbidden')
        try:
            length = int(self.headers.get('Content-Length') or 0)
        except Exception:
            length = 0
        if length <= 0 or length > _MAX_CONTROL_BODY:
            return self._plain(400, 'Bad request')
        try:
            payload = json.loads(self.rfile.read(length).decode('utf-8'))
        except Exception:
            return self._plain(400, 'Bad request')
        if path == _RELEASE_PATH:
            count = self.context.registry.release_session((payload or {}).get('session_id'))
            return self._json(200, {'ok': True, 'released': int(count)})
        url = str((payload or {}).get('url') or '').strip()
        kind = _safe_kind((payload or {}).get('kind'))
        if not _valid_upstream(url):
            return self._plain(400, 'Bad upstream')
        try:
            token, session_id = self.context.registry.add(url, kind=kind, root=True)
            local = self.context.registry.local_url(token, url, kind)
        except Exception:
            return self._plain(500, 'Relay registration failed')
        return self._json(200, {'ok': True, 'url': local, 'session_id': session_id})

    def do_HEAD(self):
        self._serve_head()

    def do_GET(self):
        self._serve_get()

    def _entry_token(self):
        path = urllib.parse.urlparse(self.path).path
        parts = [part for part in path.split('/') if part]
        if len(parts) < 2 or parts[0] != 'v1':
            return '', None
        token = parts[1]
        return token, self.context.registry.get(token)

    def _forward_headers(self):
        result = {}
        for name in ('Range', 'If-Range'):
            value = self.headers.get(name)
            if value:
                result[name] = value
        return result

    def _serve_head(self):
        """Never contact upstream for Kodi Stat/GetMimeType.

        This is what removes the 20+ second post-Stop freeze seen in the real log.
        """
        _token, entry = self._entry_token()
        if not entry:
            return self._plain(404, 'Expired media handle')
        extra = {}
        if entry.get('accept_ranges'):
            extra['Accept-Ranges'] = entry.get('accept_ranges')
        if entry.get('etag'):
            extra['ETag'] = entry.get('etag')
        if entry.get('last_modified'):
            extra['Last-Modified'] = entry.get('last_modified')
        length = entry.get('content_length')
        return self._begin(
            200,
            entry.get('content_type') or _mime_for('', entry.get('kind')),
            int(length) if str(length or '').isdigit() else None,
            extra,
        )

    def _is_manifest(self, upstream_url, headers, sample=b''):
        content_type = str((headers or {}).get('Content-Type') or (headers or {}).get('content-type') or '').lower()
        try:
            path = urllib.parse.urlparse(str(upstream_url or '')).path.lower()
        except Exception:
            path = ''
        return 'mpegurl' in content_type or path.endswith('.m3u8') or bytes(sample or b'').lstrip().startswith(b'#EXTM3U')

    def _rewrite_uri(self, uri, base_url, session_id):
        text = str(uri or '').strip()
        if not text or text.startswith('data:'):
            return text
        absolute = urllib.parse.urljoin(str(base_url or ''), text)
        if not _valid_upstream(absolute):
            return text
        token, _sid = self.context.registry.add(absolute, kind='resource', session_id=session_id)
        return self.context.registry.local_url(token, absolute, 'resource')

    def _rewrite_manifest(self, raw, base_url, session_id):
        text = bytes(raw or b'').decode('utf-8-sig', 'replace')
        output = []
        for line in text.splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith('#'):
                output.append(self._rewrite_uri(stripped, base_url, session_id))
                continue
            def quoted(match):
                return '%s%s%s%s' % (
                    match.group(1), match.group(2),
                    self._rewrite_uri(match.group(3), base_url, session_id), match.group(4)
                )
            rewritten = _URI_QUOTED_RE.sub(quoted, line)
            if rewritten == line and 'URI=' in line.upper():
                def bare(match):
                    return '%s%s' % (match.group(1), self._rewrite_uri(match.group(2), base_url, session_id))
                rewritten = _URI_BARE_RE.sub(bare, line)
            output.append(rewritten)
        return ('\n'.join(output) + '\n').encode('utf-8')

    def _send_binary_headers(self, response):
        status = int(getattr(response, 'status', response.getcode()) or 200)
        extra = {}
        for name in ('Content-Range', 'Accept-Ranges', 'Last-Modified', 'ETag', 'Expires'):
            value = response.headers.get(name)
            if value:
                extra[name] = value
        length = response.headers.get('Content-Length')
        self._begin(
            status,
            response.headers.get('Content-Type') or 'application/octet-stream',
            int(length) if str(length or '').isdigit() else None,
            extra,
        )

    @staticmethod
    def _response_span(response):
        """Return (start, expected_body_length, end) for a binary response."""
        try:
            status = int(getattr(response, 'status', response.getcode()) or 200)
        except Exception:
            status = 200
        length_text = str(response.headers.get('Content-Length') or '').strip()
        expected = int(length_text) if length_text.isdigit() else None
        start = 0
        end = (expected - 1) if expected is not None and expected > 0 else None
        content_range = str(response.headers.get('Content-Range') or '').strip()
        match = re.match(r'(?i)^bytes\s+(\d+)-(\d+)/(?:\d+|\*)$', content_range)
        if status == 206 and match:
            start = int(match.group(1))
            end = int(match.group(2))
            if expected is None:
                expected = max(0, end - start + 1)
        return start, expected, end

    def _resume_vod_response(self, url, next_absolute, end_absolute, entry, timeout=8.0):
        """Resume a truncated VOD body without exposing the retry to Kodi.

        Headers have already been sent downstream, so a continuation is accepted
        only when the provider proves an exact 206 starting at next_absolute.
        Anything else is closed and Kodi remains free to perform its own Range.
        """
        range_value = 'bytes=%d-' % int(next_absolute)
        if end_absolute is not None and int(end_absolute) >= int(next_absolute):
            range_value = 'bytes=%d-%d' % (int(next_absolute), int(end_absolute))
        headers = {'Range': range_value}
        if_range = str(self.headers.get('If-Range') or entry.get('etag') or entry.get('last_modified') or '').strip()
        if if_range:
            headers['If-Range'] = if_range
        resumed = self.context.open_upstream(url, method='GET', headers=headers, timeout=timeout)
        try:
            status = int(getattr(resumed, 'status', resumed.getcode()) or 0)
            content_range = str(resumed.headers.get('Content-Range') or '').strip()
            match = re.match(r'(?i)^bytes\s+(\d+)-(\d+)/(?:\d+|\*)$', content_range)
            if status != 206 or not match or int(match.group(1)) != int(next_absolute):
                resumed.close()
                return None
            return resumed
        except Exception:
            try:
                resumed.close()
            except Exception:
                pass
            return None

    def _serve_get(self):
        token, entry = self._entry_token()
        if not entry:
            return self._plain(404, 'Expired media handle')
        if entry.get('released_at') or not entry.get('url'):
            return self._plain(410, 'Released media handle')

        url = str(entry.get('url') or '')
        session_id = str(entry.get('session_id') or '')
        response = None
        headers_sent = False
        try:
            # A resource entry is normally an HLS child (segment/key/variant).
            # It must fail before the player watchdog rather than keeping a
            # relay worker blocked for the generic VOD 20 s budget. VOD roots
            # retain the longer timeout because remote Range seeks can be slow.
            upstream_timeout = 8.0 if entry.get('kind') in ('resource', 'hls', 'live') else 20.0
            started_at = time.monotonic()
            response = self.context.open_upstream(
                url, method='GET', headers=self._forward_headers(), timeout=upstream_timeout
            )
            effective_url = str(getattr(response, 'geturl', lambda: url)() or url)
            self.context.registry.update_meta(token, response.headers)
            manifest = self._is_manifest(url, response.headers) or self._is_manifest(effective_url, response.headers)
            if manifest:
                raw = response.read(_MAX_MANIFEST_BYTES + 1)
                if len(raw) > _MAX_MANIFEST_BYTES:
                    return self._plain(502, 'Manifest too large')
                body = self._rewrite_manifest(raw, effective_url, session_id)
                self._begin(200, 'application/vnd.apple.mpegurl', len(body))
                headers_sent = True
                try:
                    self.wfile.write(body)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                    pass
                return

            self._send_binary_headers(response)
            headers_sent = True
            span_start, expected_length, span_end = self._response_span(response)
            bytes_sent = 0
            resume_attempts = 0
            allow_internal_resume = entry.get('kind') in ('movie', 'series') and expected_length is not None

            direct_live_ts = bool(
                entry.get('kind') == 'live' and
                str(entry.get('suffix') or '').lower() == '.ts'
            )
            if direct_live_ts:
                read_size = _LIVE_TS_COPY_CHUNK
            elif entry.get('kind') in ('resource', 'hls'):
                read_size = _RESOURCE_COPY_CHUNK
            else:
                read_size = _COPY_CHUNK

            # HTTPResponse.read(128 KiB) can wait until the requested amount is
            # accumulated. That is fine for VOD, but on a low-bitrate Live TS it
            # can leave Kodi's FileCache with no localhost bytes for many seconds.
            # Prefer read1() for streaming media so currently available bytes are
            # forwarded promptly; this also makes a user Stop observable quickly
            # through the downstream socket instead of entering Curl retry loops.
            stream_reader = getattr(response, 'read1', None)
            if not callable(stream_reader) or entry.get('kind') in ('movie', 'series'):
                stream_reader = response.read

            while True:
                read_failed = False
                try:
                    chunk = stream_reader(read_size)
                except http.client.IncompleteRead as exc:
                    # Preserve every byte already received before the early EOF.
                    chunk = bytes(getattr(exc, 'partial', b'') or b'')
                    read_failed = True
                except (socket.timeout, TimeoutError, OSError, http.client.HTTPException):
                    chunk = b''
                    read_failed = True

                if chunk:
                    try:
                        self.wfile.write(chunk)
                        bytes_sent += len(chunk)
                    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
                        break

                complete = expected_length is not None and bytes_sent >= int(expected_length)
                if complete:
                    break
                if chunk and not read_failed:
                    continue

                # Upstream ended early. For VOD only, continue the SAME HTTP body
                # using a verified exact Range. Kodi sees one continuous response,
                # avoiding CURLE_PARTIAL_FILE without duplicating/skipping bytes.
                # A direct Live TS is not seekable VOD. Once its upstream
                # transport dies, retire only this root token before returning.
                # Kodi's automatic transient retries will then receive 410
                # immediately instead of reopening the same stalled connection.
                if direct_live_ts:
                    self.context.registry.retire_token(token)

                if (allow_internal_resume and resume_attempts < _VOD_RESUME_ATTEMPTS
                        and expected_length is not None and bytes_sent < int(expected_length)):
                    next_absolute = int(span_start) + int(bytes_sent)
                    try:
                        response.close()
                    except Exception:
                        pass
                    response = None
                    try:
                        resumed = self._resume_vod_response(
                            effective_url, next_absolute, span_end, entry, timeout=8.0
                        )
                    except Exception:
                        resumed = None
                    resume_attempts += 1
                    if resumed is not None:
                        response = resumed
                        # Do not alter bytes_sent/span_start: resumed bytes append to
                        # the original downstream body and are counted cumulatively.
                        continue
                break
        except urllib.error.HTTPError as exc:
            if not headers_sent:
                # Do not forward Location or provider body; both may contain secrets.
                log('Relay V4: upstream recusou mídia (HTTP %s, tipo=%s).' % (getattr(exc, 'code', 0) or 0, entry.get('kind') or 'resource'), 'warning')
                return self._plain(int(getattr(exc, 'code', 502) or 502), 'Upstream media error')
        except (urllib.error.URLError, socket.timeout, TimeoutError, OSError, http.client.HTTPException) as exc:
            if not headers_sent:
                try:
                    elapsed = max(0.0, time.monotonic() - started_at)
                except Exception:
                    elapsed = 0.0
                log('Relay V4: upstream sem resposta (tipo=%s, %.2fs, erro=%s).' % (entry.get('kind') or 'resource', elapsed, exc.__class__.__name__), 'warning')
                return self._plain(502, 'Upstream media unavailable')
        except Exception:
            if not headers_sent:
                return self._plain(502, 'Media relay failure')
        finally:
            try:
                if response is not None:
                    response.close()
            except Exception:
                pass



class MediaRelayService(object):
    def __init__(self):
        self.server = None
        self.thread = None
        self.control_token = ''

    def start(self):
        if self.server is not None:
            return True
        if ThreadingHTTPServer is None:
            return False
        self.control_token = secrets.token_urlsafe(48)
        server = _RelayHTTPServer(('127.0.0.1', 0), _RelayHandler)
        port = int(server.server_address[1])
        server.relay_context = _RelayContext(port, self.control_token)
        self.server = server
        self.thread = threading.Thread(target=server.serve_forever, name='IBO-MediaRelay')
        self.thread.daemon = True
        self.thread.start()
        write_json(_RELAY_STATE, {
            'version': _RELAY_VERSION,
            'port': port,
            'control_token': self.control_token,
            'started_at': int(time.time()),
        })
        try:
            os.chmod(_RELAY_STATE, 0o600)
        except Exception:
            pass
        log('Relay de mídia seguro V4 ativo em loopback (Path plugin/DynPath localhost).', 'debug')
        return True

    def stop(self):
        delete(_RELAY_STATE)
        server = self.server
        self.server = None
        if server is not None:
            try:
                server.relay_context.registry.clear()
            except Exception:
                pass
            try:
                server.shutdown()
            except Exception:
                pass
            try:
                server.server_close()
            except Exception:
                pass
        thread = self.thread
        self.thread = None
        if thread is not None:
            try:
                thread.join(1.5)
            except Exception:
                pass


def _relay_state():
    data = read_json(_RELAY_STATE, {})
    if not isinstance(data, dict) or int(data.get('version') or 0) != _RELAY_VERSION:
        return {}
    try:
        port = int(data.get('port') or 0)
    except Exception:
        port = 0
    token = str(data.get('control_token') or '')
    if port < 1 or port > 65535 or len(token) < 32:
        return {}
    return {'port': port, 'control_token': token}


def relay_mime_for(url):
    """Public safe MIME helper for the plugin:// resolver route."""
    return _mime_for(str(url or ''), '')


def is_current_relay_url(url):
    """Accept only opaque media URLs served by the currently active loopback relay."""
    raw = str(url or '').strip().split('|', 1)[0]
    state = _relay_state()
    if not state:
        return False
    try:
        parsed = urllib.parse.urlparse(raw)
        if parsed.scheme != 'http' or parsed.hostname != '127.0.0.1':
            return False
        if parsed.username is not None or parsed.password is not None:
            return False
        if int(parsed.port or 0) != int(state.get('port') or 0):
            return False
        path = str(parsed.path or '')
        parts = [part for part in path.split('/') if part]
        if len(parts) != 3 or parts[0] != 'v1' or not parts[1].strip() or not parts[2].startswith('stream.'):
            return False
        return not parsed.query and not parsed.fragment
    except Exception:
        return False


def _control_request(path, payload, timeout=1.2):
    state = _relay_state()
    if not state:
        raise RuntimeError('relay local não está ativo')
    body = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    conn = http.client.HTTPConnection('127.0.0.1', int(state['port']), timeout=max(0.4, float(timeout)))
    try:
        conn.request('POST', path, body=body, headers={
            'Content-Type': 'application/json',
            'Content-Length': str(len(body)),
            'X-IBO-Relay-Token': state['control_token'],
            'Connection': 'close',
        })
        response = conn.getresponse()
        raw = response.read(64 * 1024)
        if int(response.status) != 200:
            raise RuntimeError('relay local recusou a operação (%s)' % int(response.status))
        data = json.loads(raw.decode('utf-8'))
        return data if isinstance(data, dict) else {}
    finally:
        try:
            conn.close()
        except Exception:
            pass


def register_playback(upstream_url, kind, wait_seconds=1.5):
    deadline = time.monotonic() + max(0.2, float(wait_seconds or 0.0))
    last_error = None
    while time.monotonic() < deadline:
        try:
            data = _control_request(_CONTROL_PATH, {'url': str(upstream_url or ''), 'kind': _safe_kind(kind)}, timeout=0.7)
            local_url = str(data.get('url') or '')
            session_id = str(data.get('session_id') or '')
            if local_url.startswith('http://127.0.0.1:') and session_id:
                return local_url, session_id
            last_error = RuntimeError('resposta inválida do relay local')
        except Exception as exc:
            last_error = exc
        time.sleep(0.08)
    raise RuntimeError(str(last_error or 'relay local indisponível'))


def release_playback(session_id):
    session_id = str(session_id or '').strip()
    if not session_id:
        return False
    try:
        data = _control_request(_RELEASE_PATH, {'session_id': session_id}, timeout=0.7)
        return bool(data.get('ok'))
    except Exception:
        return False
