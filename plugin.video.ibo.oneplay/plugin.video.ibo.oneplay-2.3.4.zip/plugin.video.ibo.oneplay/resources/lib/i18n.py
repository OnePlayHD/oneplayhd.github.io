# -*- coding: utf-8 -*-
"""Localização IBO alinhada ao language.json do painel.

O painel define ``language_code`` como idioma inicial. O Kodi pode manter um
``language_code_override`` local por aparelho; o valor ``panel`` volta a seguir
o painel. O arquivo de idiomas embarcado é uma cópia byte-a-byte do contrato
V2.21 do painel, garantindo os mesmos códigos/nomes mesmo sem rede.
"""
import json
import os

from .state import load_panel, load_prefs

_DATA = None
_BY_CODE = None
_ALLOWED = None

# Textos exclusivos do cliente Kodi que não existem no language.json legado.
# Português preserva exatamente os rótulos já homologados. Para os demais
# idiomas, estes poucos rótulos técnicos acompanham o idioma escolhido.
_CUSTOM = {
    'pt': {
        'home':'CASA','games':'JOGOS','portal':'PORTAL','access_portal':'PORTAL DE ACESSO','use_portal':'USAR PORTAL',
        'access_ibo':'ACESSO IBO','return_player':'VOLTAR AO PLAYER','settings_ui':'CONFIGURAÇÕES','confirm':'CONFIRMAR',
        'now':'AGORA','time':'HORÁRIO','program':'PROGRAMA','schedule_epg':'PROGRAMAÇÃO / EPG','next':'PRÓXIMOS',
        'enter':'ENTRAR','wait':'Aguarde...','settings_hint':'Selecione uma opção para alterar',
        'navigate_images':'← / →  NAVEGAR ENTRE AS IMAGENS','network_timeout':'Timeout de rede',
        'failover_attempts':'Tentativas de failover','items_per_page':'Itens por página','ffmpeg_direct':'Reprodutor FFmpeg Direct','universal_cast':'Chromecast / DLNA',
        'change_adult_pin':'Alterar PIN adulto','my_account':'Minha conta','download_apk':'Baixar aplicativos APK',
        'stream_type':'Tipo de fluxo','panel_default':'Padrão do painel','fixed_by_panel':'Fixo pelo painel','selected':'Selecionado','activated':'Ativado','deactivated':'Desativado',
    },
    'en': {
        'home':'HOME','games':'GAMES','portal':'PORTAL','access_portal':'ACCESS PORTAL','use_portal':'USE PORTAL',
        'access_ibo':'IBO ACCESS','return_player':'RETURN TO PLAYER','settings_ui':'SETTINGS','confirm':'CONFIRM',
        'now':'NOW','time':'TIME','program':'PROGRAM','schedule_epg':'SCHEDULE / EPG','next':'NEXT',
        'enter':'LOGIN','wait':'Please wait...','settings_hint':'Select an option to change',
        'navigate_images':'← / →  NAVIGATE BETWEEN IMAGES','network_timeout':'Network timeout',
        'failover_attempts':'Failover attempts','items_per_page':'Items per page','ffmpeg_direct':'FFmpeg Direct Player','universal_cast':'Chromecast / DLNA',
        'change_adult_pin':'Change adult PIN','my_account':'My account','download_apk':'Download APK apps',
        'stream_type':'Stream type','panel_default':'Panel default','fixed_by_panel':'Fixed by panel','selected':'Selected','activated':'Enabled','deactivated':'Disabled',
    },
    'es': {
        'home':'INICIO','games':'JUEGOS','portal':'PORTAL','access_portal':'PORTAL DE ACCESO','use_portal':'USAR PORTAL',
        'access_ibo':'ACCESO IBO','return_player':'VOLVER AL REPRODUCTOR','settings_ui':'AJUSTES','confirm':'CONFIRMAR',
        'now':'AHORA','time':'HORARIO','program':'PROGRAMA','schedule_epg':'PROGRAMACIÓN / EPG','next':'PRÓXIMOS',
        'enter':'ENTRAR','wait':'Espere...','settings_hint':'Seleccione una opción para cambiar',
        'navigate_images':'← / →  NAVEGAR ENTRE IMÁGENES','network_timeout':'Tiempo de espera de red',
        'failover_attempts':'Intentos de failover','items_per_page':'Elementos por página','ffmpeg_direct':'Reproductor FFmpeg Direct',
        'change_adult_pin':'Cambiar PIN adulto','my_account':'Mi cuenta','download_apk':'Descargar aplicaciones APK',
        'stream_type':'Tipo de flujo','panel_default':'Predeterminado del panel','fixed_by_panel':'Fijo por el panel','selected':'Seleccionado','activated':'Activado','deactivated':'Desactivado',
    },
    'it': {
        'home':'HOME','games':'GIOCHI','portal':'PORTALE','access_portal':'PORTALE DI ACCESSO','use_portal':'USA PORTALE',
        'access_ibo':'ACCESSO IBO','return_player':'TORNA AL PLAYER','settings_ui':'IMPOSTAZIONI','confirm':'CONFERMA',
        'now':'ORA','time':'ORARIO','program':'PROGRAMMA','schedule_epg':'PROGRAMMAZIONE / EPG','next':'PROSSIMI',
        'enter':'ACCEDI','wait':'Attendere...','settings_hint':'Seleziona un’opzione da modificare',
        'navigate_images':'← / →  NAVIGA TRA LE IMMAGINI','network_timeout':'Timeout di rete','failover_attempts':'Tentativi di failover',
        'items_per_page':'Elementi per pagina','ffmpeg_direct':'Player FFmpeg Direct','change_adult_pin':'Cambia PIN adulti',
        'my_account':'Il mio account','download_apk':'Scarica app APK','stream_type':'Tipo di flusso',
        'panel_default':'Predefinito del pannello','fixed_by_panel':'Fisso dal pannello','selected':'Selezionato','activated':'Attivato','deactivated':'Disattivato',
    },
    'fr': {
        'home':'ACCUEIL','games':'JEUX','portal':'PORTAIL','access_portal':'PORTAIL D’ACCÈS','use_portal':'UTILISER LE PORTAIL',
        'access_ibo':'ACCÈS IBO','return_player':'RETOUR AU LECTEUR','settings_ui':'PARAMÈTRES','confirm':'CONFIRMER',
        'now':'MAINTENANT','time':'HEURE','program':'PROGRAMME','schedule_epg':'PROGRAMME / EPG','next':'SUIVANTS',
        'enter':'ENTRER','wait':'Veuillez patienter...','settings_hint':'Sélectionnez une option à modifier',
        'navigate_images':'← / →  NAVIGUER ENTRE LES IMAGES','network_timeout':'Délai réseau','failover_attempts':'Tentatives de basculement',
        'items_per_page':'Éléments par page','ffmpeg_direct':'Lecteur FFmpeg Direct','change_adult_pin':'Modifier le PIN adulte',
        'my_account':'Mon compte','download_apk':'Télécharger les APK','stream_type':'Type de flux',
        'panel_default':'Valeur du panneau','fixed_by_panel':'Fixé par le panneau','selected':'Sélectionné','activated':'Activé','deactivated':'Désactivé',
    },
    'de': {
        'home':'START','games':'SPIELE','portal':'PORTAL','access_portal':'ZUGANGSPORTAL','use_portal':'PORTAL VERWENDEN',
        'access_ibo':'IBO-ZUGANG','return_player':'ZUM PLAYER ZURÜCK','settings_ui':'EINSTELLUNGEN','confirm':'BESTÄTIGEN',
        'now':'JETZT','time':'ZEIT','program':'PROGRAMM','schedule_epg':'PROGRAMM / EPG','next':'NÄCHSTE',
        'enter':'ANMELDEN','wait':'Bitte warten...','settings_hint':'Wählen Sie eine Option zum Ändern',
        'navigate_images':'← / →  ZWISCHEN BILDERN NAVIGIEREN','network_timeout':'Netzwerk-Timeout','failover_attempts':'Failover-Versuche',
        'items_per_page':'Elemente pro Seite','ffmpeg_direct':'FFmpeg Direct Player','change_adult_pin':'Erwachsenen-PIN ändern',
        'my_account':'Mein Konto','download_apk':'APK-Apps herunterladen','stream_type':'Stream-Typ',
        'panel_default':'Panel-Standard','fixed_by_panel':'Vom Panel festgelegt','selected':'Ausgewählt','activated':'Aktiviert','deactivated':'Deaktiviert',
    },
    'da': {
        'home':'HJEM','games':'SPIL','portal':'PORTAL','access_portal':'ADGANGSPORTAL','use_portal':'BRUG PORTAL',
        'access_ibo':'IBO-ADGANG','return_player':'TILBAGE TIL AFSPILLER','settings_ui':'INDSTILLINGER','confirm':'BEKRÆFT',
        'now':'NU','time':'TID','program':'PROGRAM','schedule_epg':'PROGRAM / EPG','next':'NÆSTE',
        'enter':'LOG IND','wait':'Vent venligst...','settings_hint':'Vælg en indstilling der skal ændres',
        'navigate_images':'← / →  NAVIGER MELLEM BILLEDER','network_timeout':'Netværkstimeout','failover_attempts':'Failover-forsøg',
        'items_per_page':'Elementer pr. side','ffmpeg_direct':'FFmpeg Direct-afspiller','change_adult_pin':'Skift voksen-PIN',
        'my_account':'Min konto','download_apk':'Download APK-apps','stream_type':'Streamtype',
        'panel_default':'Panelstandard','fixed_by_panel':'Låst af panelet','selected':'Valgt','activated':'Aktiveret','deactivated':'Deaktiveret',
    },
    'tr': {
        'home':'ANA SAYFA','games':'OYUNLAR','portal':'PORTAL','access_portal':'ERİŞİM PORTALI','use_portal':'PORTALI KULLAN',
        'access_ibo':'IBO ERİŞİMİ','return_player':'OYNATICIYA DÖN','settings_ui':'AYARLAR','confirm':'ONAYLA',
        'now':'ŞİMDİ','time':'SAAT','program':'PROGRAM','schedule_epg':'PROGRAM / EPG','next':'SONRAKİ',
        'enter':'GİRİŞ','wait':'Lütfen bekleyin...','settings_hint':'Değiştirmek için bir seçenek seçin',
        'navigate_images':'← / →  GÖRSELLER ARASINDA GEZİN','network_timeout':'Ağ zaman aşımı','failover_attempts':'Failover denemeleri',
        'items_per_page':'Sayfa başına öğe','ffmpeg_direct':'FFmpeg Direct Oynatıcı','change_adult_pin':'Yetişkin PIN’ini değiştir',
        'my_account':'Hesabım','download_apk':'APK uygulamalarını indir','stream_type':'Akış türü',
        'panel_default':'Panel varsayılanı','fixed_by_panel':'Panel tarafından sabit','selected':'Seçili','activated':'Etkin','deactivated':'Devre dışı',
    },
    'ar': {
        'home':'الرئيسية','games':'الألعاب','portal':'البوابة','access_portal':'بوابة الوصول','use_portal':'استخدام البوابة',
        'access_ibo':'وصول IBO','return_player':'العودة إلى المشغل','settings_ui':'الإعدادات','confirm':'تأكيد',
        'now':'الآن','time':'الوقت','program':'البرنامج','schedule_epg':'البرامج / EPG','next':'التالي',
        'enter':'دخول','wait':'يرجى الانتظار...','settings_hint':'اختر خيارًا لتغييره',
        'navigate_images':'← / →  التنقل بين الصور','network_timeout':'مهلة الشبكة','failover_attempts':'محاولات التحويل الاحتياطي',
        'items_per_page':'العناصر لكل صفحة','ffmpeg_direct':'مشغل FFmpeg Direct','change_adult_pin':'تغيير PIN للبالغين',
        'my_account':'حسابي','download_apk':'تنزيل تطبيقات APK','stream_type':'نوع البث',
        'panel_default':'إعداد اللوحة الافتراضي','fixed_by_panel':'ثابت بواسطة اللوحة','selected':'محدد','activated':'مفعّل','deactivated':'معطّل',
    },
    'uk': {
        'home':'ГОЛОВНА','games':'ІГРИ','portal':'ПОРТАЛ','access_portal':'ПОРТАЛ ДОСТУПУ','use_portal':'ВИКОРИСТАТИ ПОРТАЛ',
        'access_ibo':'ДОСТУП IBO','return_player':'ПОВЕРНУТИСЯ ДО ПЛЕЄРА','settings_ui':'НАЛАШТУВАННЯ','confirm':'ПІДТВЕРДИТИ',
        'now':'ЗАРАЗ','time':'ЧАС','program':'ПРОГРАМА','schedule_epg':'ПРОГРАМА / EPG','next':'НАСТУПНІ',
        'enter':'УВІЙТИ','wait':'Зачекайте...','settings_hint':'Виберіть параметр для зміни',
        'navigate_images':'← / →  НАВІГАЦІЯ МІЖ ЗОБРАЖЕННЯМИ','network_timeout':'Тайм-аут мережі','failover_attempts':'Спроби failover',
        'items_per_page':'Елементів на сторінці','ffmpeg_direct':'Плеєр FFmpeg Direct','change_adult_pin':'Змінити PIN для дорослих',
        'my_account':'Мій обліковий запис','download_apk':'Завантажити APK','stream_type':'Тип потоку',
        'panel_default':'За замовчуванням панелі','fixed_by_panel':'Зафіксовано панеллю','selected':'Вибрано','activated':'Увімкнено','deactivated':'Вимкнено',
    },
    'gr': {
        'home':'ΑΡΧΙΚΗ','games':'ΠΑΙΧΝΙΔΙΑ','portal':'ΠΥΛΗ','access_portal':'ΠΥΛΗ ΠΡΟΣΒΑΣΗΣ','use_portal':'ΧΡΗΣΗ ΠΥΛΗΣ',
        'access_ibo':'ΠΡΟΣΒΑΣΗ IBO','return_player':'ΕΠΙΣΤΡΟΦΗ ΣΤΟ PLAYER','settings_ui':'ΡΥΘΜΙΣΕΙΣ','confirm':'ΕΠΙΒΕΒΑΙΩΣΗ',
        'now':'ΤΩΡΑ','time':'ΩΡΑ','program':'ΠΡΟΓΡΑΜΜΑ','schedule_epg':'ΠΡΟΓΡΑΜΜΑ / EPG','next':'ΕΠΟΜΕΝΑ',
        'enter':'ΕΙΣΟΔΟΣ','wait':'Παρακαλώ περιμένετε...','settings_hint':'Επιλέξτε μια ρύθμιση για αλλαγή',
        'navigate_images':'← / →  ΠΛΟΗΓΗΣΗ ΜΕΤΑΞΥ ΕΙΚΟΝΩΝ','network_timeout':'Χρονικό όριο δικτύου','failover_attempts':'Προσπάθειες failover',
        'items_per_page':'Στοιχεία ανά σελίδα','ffmpeg_direct':'Αναπαραγωγή FFmpeg Direct','change_adult_pin':'Αλλαγή PIN ενηλίκων',
        'my_account':'Ο λογαριασμός μου','download_apk':'Λήψη εφαρμογών APK','stream_type':'Τύπος ροής',
        'panel_default':'Προεπιλογή πίνακα','fixed_by_panel':'Κλειδωμένο από τον πίνακα','selected':'Επιλεγμένο','activated':'Ενεργοποιημένο','deactivated':'Απενεργοποιημένο',
    },
    'hi': {
        'home':'होम','games':'गेम्स','portal':'पोर्टल','access_portal':'एक्सेस पोर्टल','use_portal':'पोर्टल उपयोग करें',
        'access_ibo':'IBO एक्सेस','return_player':'प्लेयर पर वापस जाएँ','settings_ui':'सेटिंग्स','confirm':'पुष्टि करें',
        'now':'अभी','time':'समय','program':'कार्यक्रम','schedule_epg':'कार्यक्रम / EPG','next':'अगला',
        'enter':'लॉगिन','wait':'कृपया प्रतीक्षा करें...','settings_hint':'बदलने के लिए विकल्प चुनें',
        'navigate_images':'← / →  चित्रों के बीच जाएँ','network_timeout':'नेटवर्क टाइमआउट','failover_attempts':'फेलओवर प्रयास',
        'items_per_page':'प्रति पृष्ठ आइटम','ffmpeg_direct':'FFmpeg Direct प्लेयर','change_adult_pin':'वयस्क PIN बदलें',
        'my_account':'मेरा खाता','download_apk':'APK ऐप डाउनलोड करें','stream_type':'स्ट्रीम प्रकार',
        'panel_default':'पैनल डिफ़ॉल्ट','fixed_by_panel':'पैनल द्वारा स्थिर','selected':'चयनित','activated':'सक्रिय','deactivated':'निष्क्रिय',
    },
    'bg': {
        'home':'НАЧАЛО','games':'ИГРИ','portal':'ПОРТАЛ','access_portal':'ПОРТАЛ ЗА ДОСТЪП','use_portal':'ИЗПОЛЗВАЙ ПОРТАЛ',
        'access_ibo':'IBO ДОСТЪП','return_player':'ОБРАТНО КЪМ ПЛЕЙЪРА','settings_ui':'НАСТРОЙКИ','confirm':'ПОТВЪРДИ',
        'now':'СЕГА','time':'ЧАС','program':'ПРОГРАМА','schedule_epg':'ПРОГРАМА / EPG','next':'СЛЕДВАЩИ',
        'enter':'ВХОД','wait':'Моля, изчакайте...','settings_hint':'Изберете опция за промяна',
        'navigate_images':'← / →  НАВИГАЦИЯ МЕЖДУ ИЗОБРАЖЕНИЯ','network_timeout':'Мрежов таймаут','failover_attempts':'Опити за failover',
        'items_per_page':'Елементи на страница','ffmpeg_direct':'FFmpeg Direct плейър','change_adult_pin':'Промяна на PIN за възрастни',
        'my_account':'Моят акаунт','download_apk':'Изтегляне на APK приложения','stream_type':'Тип поток',
        'panel_default':'По подразбиране от панела','fixed_by_panel':'Фиксирано от панела','selected':'Избрано','activated':'Активирано','deactivated':'Деактивирано',
    },
}


# Recursos locais da evolução de continuidade. Mantidos separados do contrato
# language.json do painel para não alterar/copiar o arquivo central do painel.
_FEATURE_CUSTOM = {
    'pt': {'cast':'Transmitir','cast_stop':'Parar transmissão','cast_search':'Procurando dispositivos...','cast_none':'Nenhum dispositivo compatível encontrado.','cast_failed':'Não foi possível iniciar a transmissão.','cast_started':'Transmissão iniciada','favorites':'Favoritos','favorite_added':'Adicionado aos favoritos','favorite_removed':'Removido dos favoritos','continue_watching':'Continuar assistindo','watched':'Assistido','next_episode':'Próximo episódio','play_now':'Reproduzir agora','play_in':'Reproduzir em','up_next_auto':'Próximo episódio automático','clear_watch_history':'Limpar histórico de reprodução','clear_watch_history_confirm':'Deseja apagar o progresso e o histórico de filmes e séries deste aparelho?','watch_history_cleared':'Histórico de reprodução limpo com sucesso.'},
    'en': {'cast':'Cast','cast_stop':'Stop casting','cast_search':'Searching for devices...','cast_none':'No compatible device found.','cast_failed':'Could not start casting.','cast_started':'Casting started','favorites':'Favorites','favorite_added':'Added to favorites','favorite_removed':'Removed from favorites','continue_watching':'Continue watching','watched':'Watched','next_episode':'Next episode','play_now':'Play now','play_in':'Play in','up_next_auto':'Auto next episode','clear_watch_history':'Clear playback history','clear_watch_history_confirm':'Delete movie and series progress/history from this device?','watch_history_cleared':'Playback history cleared successfully.'},
    'es': {'cast':'Transmitir','cast_stop':'Detener transmisión','cast_search':'Buscando dispositivos...','cast_none':'No se encontró un dispositivo compatible.','cast_failed':'No se pudo iniciar la transmisión.','cast_started':'Transmisión iniciada','favorites':'Favoritos','favorite_added':'Añadido a favoritos','favorite_removed':'Eliminado de favoritos','continue_watching':'Continuar viendo','watched':'Visto','next_episode':'Siguiente episodio','play_now':'Reproducir ahora','play_in':'Reproducir en','up_next_auto':'Siguiente episodio automático','clear_watch_history':'Borrar historial de reproducción','clear_watch_history_confirm':'¿Borrar el progreso y el historial de películas y series de este dispositivo?','watch_history_cleared':'Historial de reproducción borrado correctamente.'},
    'it': {'favorites':'Preferiti','favorite_added':'Aggiunto ai preferiti','favorite_removed':'Rimosso dai preferiti','continue_watching':'Continua a guardare','watched':'Visto','next_episode':'Prossimo episodio','play_now':'Riproduci ora','play_in':'Riproduci tra','up_next_auto':'Prossimo episodio automatico','clear_watch_history':'Cancella cronologia di riproduzione','clear_watch_history_confirm':'Eliminare progressi e cronologia di film e serie da questo dispositivo?','watch_history_cleared':'Cronologia di riproduzione cancellata.'},
    'fr': {'favorites':'Favoris','favorite_added':'Ajouté aux favoris','favorite_removed':'Retiré des favoris','continue_watching':'Continuer à regarder','watched':'Vu','next_episode':'Épisode suivant','play_now':'Lire maintenant','play_in':'Lecture dans','up_next_auto':'Épisode suivant automatique','clear_watch_history':'Effacer l’historique de lecture','clear_watch_history_confirm':'Supprimer la progression et l’historique des films et séries de cet appareil ?','watch_history_cleared':'Historique de lecture effacé.'},
    'de': {'favorites':'Favoriten','favorite_added':'Zu Favoriten hinzugefügt','favorite_removed':'Aus Favoriten entfernt','continue_watching':'Weiterschauen','watched':'Gesehen','next_episode':'Nächste Folge','play_now':'Jetzt abspielen','play_in':'Wiedergabe in','up_next_auto':'Nächste Folge automatisch','clear_watch_history':'Wiedergabeverlauf löschen','clear_watch_history_confirm':'Fortschritt und Verlauf von Filmen und Serien auf diesem Gerät löschen?','watch_history_cleared':'Wiedergabeverlauf gelöscht.'},
    'da': {'favorites':'Favoritter','favorite_added':'Føjet til favoritter','favorite_removed':'Fjernet fra favoritter','continue_watching':'Fortsæt med at se','watched':'Set','next_episode':'Næste episode','play_now':'Afspil nu','play_in':'Afspil om','up_next_auto':'Automatisk næste episode','clear_watch_history':'Ryd afspilningshistorik','clear_watch_history_confirm':'Slet fremskridt og historik for film og serier på denne enhed?','watch_history_cleared':'Afspilningshistorik ryddet.'},
    'tr': {'favorites':'Favoriler','favorite_added':'Favorilere eklendi','favorite_removed':'Favorilerden kaldırıldı','continue_watching':'İzlemeye devam et','watched':'İzlendi','next_episode':'Sonraki bölüm','play_now':'Şimdi oynat','play_in':'Oynatmaya kalan','up_next_auto':'Otomatik sonraki bölüm','clear_watch_history':'Oynatma geçmişini temizle','clear_watch_history_confirm':'Bu cihazdaki film ve dizi ilerlemesi/geçmişi silinsin mi?','watch_history_cleared':'Oynatma geçmişi temizlendi.'},
    'ar': {'favorites':'المفضلة','favorite_added':'تمت الإضافة إلى المفضلة','favorite_removed':'تمت الإزالة من المفضلة','continue_watching':'متابعة المشاهدة','watched':'تمت المشاهدة','next_episode':'الحلقة التالية','play_now':'تشغيل الآن','play_in':'التشغيل خلال','up_next_auto':'الحلقة التالية تلقائيًا','clear_watch_history':'مسح سجل التشغيل','clear_watch_history_confirm':'هل تريد حذف تقدم وسجل الأفلام والمسلسلات من هذا الجهاز؟','watch_history_cleared':'تم مسح سجل التشغيل.'},
    'uk': {'favorites':'Обране','favorite_added':'Додано до обраного','favorite_removed':'Видалено з обраного','continue_watching':'Продовжити перегляд','watched':'Переглянуто','next_episode':'Наступна серія','play_now':'Відтворити зараз','play_in':'Відтворення через','up_next_auto':'Автоматична наступна серія','clear_watch_history':'Очистити історію відтворення','clear_watch_history_confirm':'Видалити прогрес та історію фільмів і серіалів на цьому пристрої?','watch_history_cleared':'Історію відтворення очищено.'},
    'gr': {'favorites':'Αγαπημένα','favorite_added':'Προστέθηκε στα αγαπημένα','favorite_removed':'Αφαιρέθηκε από τα αγαπημένα','continue_watching':'Συνέχεια παρακολούθησης','watched':'Προβλήθηκε','next_episode':'Επόμενο επεισόδιο','play_now':'Αναπαραγωγή τώρα','play_in':'Αναπαραγωγή σε','up_next_auto':'Αυτόματο επόμενο επεισόδιο','clear_watch_history':'Εκκαθάριση ιστορικού αναπαραγωγής','clear_watch_history_confirm':'Διαγραφή προόδου και ιστορικού ταινιών/σειρών από αυτή τη συσκευή;','watch_history_cleared':'Το ιστορικό αναπαραγωγής διαγράφηκε.'},
    'hi': {'favorites':'पसंदीदा','favorite_added':'पसंदीदा में जोड़ा गया','favorite_removed':'पसंदीदा से हटाया गया','continue_watching':'देखना जारी रखें','watched':'देखा गया','next_episode':'अगला एपिसोड','play_now':'अभी चलाएँ','play_in':'चलाएँ','up_next_auto':'अगला एपिसोड स्वतः','clear_watch_history':'प्लेबैक इतिहास साफ़ करें','clear_watch_history_confirm':'इस डिवाइस से फ़िल्म और सीरीज़ की प्रगति/इतिहास हटाएँ?','watch_history_cleared':'प्लेबैक इतिहास साफ़ हो गया।'},
    'bg': {'favorites':'Любими','favorite_added':'Добавено в любими','favorite_removed':'Премахнато от любими','continue_watching':'Продължи гледането','watched':'Гледано','next_episode':'Следващ епизод','play_now':'Пусни сега','play_in':'Пускане след','up_next_auto':'Автоматичен следващ епизод','clear_watch_history':'Изчисти историята на възпроизвеждане','clear_watch_history_confirm':'Да се изтрият прогресът и историята на филми и сериали от това устройство?','watch_history_cleared':'Историята на възпроизвеждане е изчистена.'},
}
for _feature_code, _feature_words in _FEATURE_CUSTOM.items():
    _CUSTOM.setdefault(_feature_code, {}).update(_feature_words)


def _load():
    global _DATA, _BY_CODE, _ALLOWED
    if _DATA is None:
        path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'language.json')
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                value = json.load(handle)
            _DATA = value if isinstance(value, list) else []
        except Exception:
            _DATA = []
        _BY_CODE = {str(row.get('code') or '').strip(): row for row in _DATA if isinstance(row, dict) and str(row.get('code') or '').strip()}
        _ALLOWED = tuple(_BY_CODE.keys()) or ('pt',)
    return _DATA


def available_languages():
    _load()
    return [(code, str((_BY_CODE.get(code) or {}).get('name') or code)) for code in _ALLOWED]


def normalize_code(value, fallback='pt'):
    _load()
    code = str(value or '').strip().lower().replace('-', '_')
    aliases = {'pt_br':'pt','en_gb':'en','en_us':'en','es_es':'es','el':'gr','el_gr':'gr','uk_ua':'uk','hi_in':'hi','bg_bg':'bg'}
    code = aliases.get(code, code)
    return code if code in _ALLOWED else (fallback if fallback in _ALLOWED else _ALLOWED[0])


def panel_language_code(panel=None):
    data = panel if isinstance(panel, dict) else load_panel()
    return normalize_code((data or {}).get('language_code') or 'pt')


def effective_language_code(panel=None):
    prefs = load_prefs()
    override = str(prefs.get('language_code_override') or 'panel').strip().lower()
    if override and override != 'panel':
        return normalize_code(override, panel_language_code(panel))
    return panel_language_code(panel)


def tr(key, fallback='', code=None):
    _load()
    lang = normalize_code(code, effective_language_code()) if code else effective_language_code()
    row = _BY_CODE.get(lang) or {}
    words = row.get('words') if isinstance(row.get('words'), dict) else {}
    value = words.get(str(key))
    if value not in (None, ''):
        return str(value)
    return str(fallback or key)


def ui(key, fallback='', code=None):
    lang = normalize_code(code, effective_language_code()) if code else effective_language_code()
    value = (_CUSTOM.get(lang) or {}).get(str(key))
    if value not in (None, ''):
        return str(value)
    value = (_CUSTOM.get('en') or {}).get(str(key))
    if value not in (None, ''):
        return str(value)
    return str(fallback or key)


def language_name(code):
    _load()
    normalized = normalize_code(code)
    return str((_BY_CODE.get(normalized) or {}).get('name') or normalized)


def window_labels(code=None):
    lang = normalize_code(code, effective_language_code()) if code else effective_language_code()
    return {
        'IBO.L.Home': ui('home', 'CASA', lang),
        'IBO.L.Games': ui('games', 'JOGOS', lang),
        'IBO.L.Portal': ui('portal', 'PORTAL', lang),
        'IBO.L.AccessPortal': ui('access_portal', 'PORTAL DE ACESSO', lang),
        'IBO.L.UsePortal': ui('use_portal', 'USAR PORTAL', lang),
        'IBO.L.AccessIbo': ui('access_ibo', 'ACESSO IBO', lang),
        'IBO.L.ReturnPlayer': ui('return_player', 'VOLTAR AO PLAYER', lang),
        'IBO.L.Settings': ui('settings_ui', 'CONFIGURAÇÕES', lang),
        'IBO.L.Confirm': ui('confirm', 'CONFIRMAR', lang),
        'IBO.L.Now': ui('now', 'AGORA', lang),
        'IBO.L.Time': ui('time', 'HORÁRIO', lang),
        'IBO.L.Program': ui('program', 'PROGRAMA', lang),
        'IBO.L.ScheduleEPG': ui('schedule_epg', 'PROGRAMAÇÃO / EPG', lang),
        'IBO.L.Next': ui('next', 'PRÓXIMOS', lang),
        'IBO.L.Enter': ui('enter', 'ENTRAR', lang),
        'IBO.L.Wait': ui('wait', 'Aguarde...', lang),
        'IBO.L.SettingsHint': ui('settings_hint', 'Selecione uma opção para alterar', lang),
        'IBO.L.NavigateImages': ui('navigate_images', '← / →  NAVEGAR ENTRE AS IMAGENS', lang),
        'IBO.L.LiveTV': tr('live_tv', 'CANAIS', lang),
        'IBO.L.Movies': tr('movies', 'FILMES', lang),
        'IBO.L.Series': tr('series', 'SÉRIES', lang),
        'IBO.L.Search': tr('search', 'PROCURAR', lang).upper(),
        'IBO.L.Update': tr('reload_portal', 'ATUALIZAR', lang).upper(),
        'IBO.L.Exit': tr('exit', 'SAIR', lang).replace('!','').upper(),
        'IBO.L.Back': tr('back', 'VOLTAR', lang).upper(),
        'IBO.L.Continue': tr('str_continue', 'CONTINUAR', lang).upper(),
        'IBO.L.Cancel': tr('cancel', 'CANCELAR', lang).upper(),
        'IBO.L.Ok': tr('ok', 'OK', lang).upper(),
        'IBO.L.Play': tr('play', 'REPRODUZIR', lang).upper(),
        'IBO.L.MyAccount': ui('my_account', 'Minha conta', lang).upper(),
    }
