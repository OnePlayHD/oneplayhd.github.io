# -*- coding: utf-8 -*-
import base64
import os
import re
import sys
import time
import urllib.parse

from .auth import automatic_test, automatic_test_ready, recover_registered_access, manual_login, panel_subset, session_client, switch_portal, sync_panel_for_open, validate_session_identity_for_open
from .constants import PLUGIN_URL
from .log import log
from .content_errors import content_title, humanize_content_error
from .portal_errors import humanize_portal_error
from .media_relay import is_current_relay_url, relay_mime_for
from .ffmpeg_direct import configure_ffmpeg_direct, ffmpeg_direct_available, ffmpeg_direct_format
from .panel import PanelClient
from .player import play_and_wait, resume_background_player_and_wait, prepare_cast_media
from .health import _refresh_banner_only
from .screens import (
    run_progress, open_progress, close_progress, claim_content_opening, begin_player_return, finish_player_return, show_access, show_account, show_browser, show_confirm, show_games, show_home, show_info,
    show_login, show_message, show_series_episodes, show_settings, show_up_next, show_cast_device_choice, open_shell, close_shell, begin_content_opening, _release_background_resume_transition, _wait_background_resume_quiet
)
from .state import clear_exit_return, clear_session, load_panel, load_session, mark_ui, request_exit_return, request_panel_sync, save_panel, save_session
from .storage import clear_cache, clear_catalog_cache, shutdown_image_workers
from .prefs import get_int
from .watch_history import resume_seconds
from .i18n import ui
from .cast import discover_devices, start_cast, stop_active_cast, cast_active
from .dlna_compat import is_lg_webos_renderer, prepare_lg_live_ts
from .apk_downloader import cleanup_downloaded_apks

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcplugin
except Exception:
    xbmc = None
    xbmcaddon = None
    xbmcgui = None
    xbmcplugin = None

ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path') if xbmcaddon is not None else ''


def _complete_directory(handle):
    """Resolve a transient plugin directory successfully.

    This is intentionally retained for the historical SAIR fallback: if a
    platform still auto-reloads ``plugin://`` after Shell closes, that second
    handle must be completed before one history Back can be requested.
    """
    if xbmcplugin is None or handle is None:
        return
    try:
        xbmcplugin.endOfDirectory(int(handle), succeeded=True, updateListing=False, cacheToDisc=False)
    except TypeError:
        # Older/stubbed Kodi APIs may expose fewer keyword arguments.
        try:
            xbmcplugin.endOfDirectory(int(handle), True)
        except Exception as exc:
            log('Falha ao concluir diretório do plugin: %s' % exc, 'warning')
    except Exception as exc:
        log('Falha ao concluir diretório do plugin: %s' % exc, 'warning')


def _detach_plugin_root(handle):
    """Finalize the transient launcher root successfully.

    The IBO does not render a native plugin listing; interaction moves directly
    to IBOShell/custom XML windows.  Real Kodi 21.3 logs proved that completing
    this launcher with ``succeeded=False`` creates an artificial XFILE/GUI
    directory error on every opening.  Complete the empty directory normally
    instead.  Returning True remains an internal lifecycle marker so the
    already-homologated explicit Home/Matrix exit path is unchanged.

    No Back, hard-coded destination or modal cover is introduced here.
    """
    if xbmcplugin is None or handle is None:
        return False
    try:
        xbmcplugin.endOfDirectory(int(handle), succeeded=True, updateListing=False, cacheToDisc=False)
        log('Navegação: raiz plugin:// concluída como diretório transitório vazio; saída explícita preservada.', 'debug')
        return True
    except TypeError:
        try:
            xbmcplugin.endOfDirectory(int(handle), True)
            log('Navegação: raiz plugin:// concluída por API compatível; saída explícita preservada.', 'debug')
            return True
        except Exception as exc:
            log('Navegação: conclusão da raiz transitória indisponível: %s' % exc, 'warning')
    except Exception as exc:
        log('Navegação: conclusão da raiz transitória indisponível: %s' % exc, 'warning')
    return False


def _sync_panel_background():
    # Network synchronization is owned by xbmc.service, not by the plugin
    # interpreter. The UI only leaves a request token and opens immediately.
    if not load_session():
        return None
    try:
        return request_panel_sync()
    except Exception as exc:
        log('Não foi possível solicitar sincronização do painel: %s' % exc, 'warning')
        return None

def _media(name):
    return os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', name)


def _banner(panel):
    panel = panel or {}
    if str(panel.get('theme') or '1') != '2':
        return ''
    # Never hold Home opening on ads.php. The background panel sync refreshes
    # this cached URL; until then use the packaged IBO banner immediately.
    return str(panel.get('_banner_url') or '') or _media('banner.png')





def _universal_cast_enabled():
    return bool(get_int('universal_cast', default=0, low=0, high=1))


def _cast_device_label(device):
    protocol = str((device or {}).get('protocol') or '')
    suffix = 'Google Cast' if protocol == 'googlecast' else 'DLNA'
    model = str((device or {}).get('model') or '').strip()
    tail = ' • %s' % suffix
    if model and model.casefold() not in str((device or {}).get('name') or '').casefold():
        tail += ' • %s' % model
    return '%s%s' % (str((device or {}).get('name') or 'Dispositivo'), tail)


def _choose_cast_device():
    # OFF is intentionally the default. In this state no discovery, relay or
    # external receiver interaction may start; the UI keeps the homologated
    # 2.3.4 OK/OK-longo behavior.
    if not _universal_cast_enabled():
        return None
    devices = run_progress(ui('cast_search', 'Procurando dispositivos...'), lambda: discover_devices(timeout=2.4)) or []
    if not devices:
        show_message('TRANSMITIR', ui('cast_none', 'Nenhum dispositivo compatível encontrado.'))
        return None

    # Fluxo normal: seletor próprio do ONEPLAY, centralizado e consistente com
    # as demais janelas da skin. O DialogSelect do Kodi existe somente como
    # fail-open caso uma skin/plataforma rejeite o XML customizado.
    try:
        choice = show_cast_device_choice(devices, title=ui('cast', 'Transmitir'))
    except Exception as exc:
        log('Universal Cast: seletor ONEPLAY indisponível; usando fallback nativo: %s' % exc, 'warning')
        labels = [_cast_device_label(row) for row in devices]
        try:
            choice = xbmcgui.Dialog().select(ui('cast', 'Transmitir'), labels)
        except Exception:
            choice = -1

    if choice is None:
        return None
    try:
        choice = int(choice)
    except Exception:
        return None
    if choice < 0 or choice >= len(devices):
        return None
    return devices[choice]


def _cast_to_device(device, kind, stream_id, title, extension='', art='', plot='', year=None, season=None, episode=None, skip_probe=False):
    """Prepare a fonte e entregue somente a URL protegida ao receiver escolhido.

    ``stage`` distingue falha de mídia (em que Live pode tentar outra variante
    técnica do mesmo canal) de falha do receiver/rede local (em que trocar a
    fonte seria incorreto e poderia mascarar o problema real).
    """
    if not _universal_cast_enabled():
        return {'ok': False, 'cancelled': True, 'disabled': True}
    # LG/webOS MediaRenderer compatibility: before exposing HLS to a strict
    # DLNA renderer, test the *same* Live stream_id as direct MPEG-TS on the
    # currently active Xtream server.  This optional probe never changes the
    # saved output/DNS/session.  If TS is not proven valid, execute the exact
    # V11 preparation path in the same progress window.
    requested_ext = str(extension or '').strip().lower().lstrip('.')

    def _prepare_cast_source():
        if str(kind or '') == 'live' and requested_ext != 'ts' and is_lg_webos_renderer(device):
            compat = prepare_lg_live_ts(stream_id) or {}
            if compat.get('ok'):
                return compat
            if not compat.get('fallback', True):
                return compat
        return prepare_cast_media(
            kind, stream_id, title, extension, art, plot, year, season, episode, skip_probe=skip_probe,
            inspect_media=bool(is_lg_webos_renderer(device) and str(kind or '') in ('movie', 'series')),
        )

    prepared = run_progress('Preparando transmissão...', _prepare_cast_source) or {}
    if not prepared.get('ok'):
        outcome = dict(prepared) if isinstance(prepared, dict) else {}
        outcome['ok'] = False
        outcome['stage'] = 'media'
        return outcome
    relay_id = str(prepared.get('relay_session_id') or '')
    try:
        run_progress('Conectando à TV...', lambda: start_cast(
            device, prepared.get('url'), relay_id, prepared.get('mime'), title=title, kind=kind,
        ))
    except Exception as exc:
        log('Universal Cast: falha ao iniciar receiver (%s): %s' % (str((device or {}).get('protocol') or ''), exc), 'warning')
        return {'ok': False, 'error': str(exc), 'stage': 'receiver'}
    show_message('TRANSMITIR', '%s\n%s' % (ui('cast_started', 'Transmissão iniciada'), str((device or {}).get('name') or 'TV')))
    return {'ok': True, 'stage': 'receiver'}


def _cast_prepared(kind, stream_id, title, extension='', art='', plot='', year=None, season=None, episode=None, skip_probe=False):
    device = _choose_cast_device()
    if not device:
        return {'ok': False, 'cancelled': True}
    return _cast_to_device(
        device, kind, stream_id, title, extension, art, plot, year, season, episode, skip_probe=skip_probe,
    )


def _cast_live_with_variants(client, primary, context):
    """Cast Live com a mesma autoridade de variantes do player local.

    A TV é escolhida uma única vez. A primária passa pelo mesmo preflight e
    failover DNS homologados. Somente se essa preparação de mídia falhar é
    feita uma passagem limitada pelas demais fontes técnicas do mesmo canal,
    incluindo a recuperação da categoria original quando a origem é Favoritos.
    Falha de receiver nunca provoca troca de fonte.
    """
    device = _choose_cast_device()
    if not device:
        return {'ok': False, 'cancelled': True}

    primary = primary if isinstance(primary, dict) else {}
    title = str(primary.get('name') or primary.get('title') or 'Canal')
    art = primary.get('stream_icon') or ''
    plot = primary.get('plot') or ''
    extension = primary.get('container_extension') or getattr(client, 'output', '') or 'm3u8'
    outcome = _cast_to_device(
        device, 'live', primary.get('stream_id'), title, extension, art, plot,
    )
    if outcome.get('ok') or outcome.get('cancelled') or outcome.get('stage') != 'media':
        return outcome

    rows = _live_variant_rows(client, primary, context)
    candidates = _live_variant_candidates(primary, rows)
    if not candidates:
        return outcome

    last = outcome
    for index, candidate in enumerate(candidates, 1):
        candidate_ext = candidate.get('container_extension') or extension
        log('Universal Cast Live: fonte técnica %d/%d, stream %s (origem %s).' % (
            index, len(candidates), str(candidate.get('stream_id') or ''), str(primary.get('stream_id') or ''),
        ), 'debug')
        last = _cast_to_device(
            device, 'live', candidate.get('stream_id'), title, candidate_ext, art, plot,
        )
        if last.get('ok') or last.get('cancelled') or last.get('stage') != 'media':
            return last
    return last


def _cast_stop_ui():
    if stop_active_cast(notify_device=True, ui_fast=True):
        show_message('TRANSMITIR', 'Transmissão encerrada.')
    else:
        show_message('TRANSMITIR', 'Nenhuma transmissão ativa.')



def _play_with_opening(kind, stream_id, title, extension='', art='', plot='', year=None, season=None, episode=None, epg_rows=None,
                       skip_probe=False, resume_at=0.0, playback_meta=None, up_next=None, up_next_prompt=None):
    # Prefer the window opened on the original Select event.  Fallback opening
    # remains for programmatic/legacy playback paths that did not originate in
    # one of the interactive IBO screens.
    holder = {'win': claim_content_opening()}

    def _opening_start():
        if holder.get('win') is None:
            holder['win'] = open_progress('Abrindo conteúdo...')

    def _opening_stop():
        close_progress(holder.get('win'))
        holder['win'] = None

    return play_and_wait(
        kind, stream_id, title, extension, art, plot, year, season, episode,
        opening_start=_opening_start, opening_stop=_opening_stop, epg_rows=epg_rows,
        return_start=lambda: begin_player_return('Aguarde...'), skip_probe=skip_probe,
        resume_at=resume_at, playback_meta=playback_meta, up_next=up_next, up_next_prompt=up_next_prompt
    )



def _resume_player_with_opening():
    """Entrega o mesmo player ao fullscreen sem criar modal de handoff.

    A tela de conteúdo já fechou e o IBOShell/videowindow é a cobertura visual.
    Antes de ativar 12005, espere a tecla que originou a transição estabilizar
    no próprio Shell; isso substitui o antigo rearm automático do fullscreen.
    """
    try:
        if not _wait_background_resume_quiet():
            return False
        return resume_background_player_and_wait(
            opening_stop=None,
            return_start=lambda: begin_player_return('Aguarde...'),
        )
    finally:
        _release_background_resume_transition()


_QUALITY_TOKEN_RE = re.compile(
    r'(?i)(?:^|[\s+\-_.|\[\]()])'
    r'(?:4k|uhd|fhd|full\s*hd|hd|sd|hevc|h\.?265|h\.?264|backup|bkp|alt|alternativo)'
    r'(?:[⁰¹²³⁴⁵⁶⁷⁸⁹]+)?'
    r'(?=$|[\s+\-_.|\[\]()])'
)
_TRAILING_SOURCE_VARIANT_RE = re.compile(r'[⁰¹²³⁴⁵⁶⁷⁸⁹]+(?=\s*$)')
_BRAND_PLUS_RE = re.compile(r'(?<=\w)\+(?=\s|$)')


def _channel_base_name(value):
    text = str(value or '').strip().casefold()
    text = _QUALITY_TOKEN_RE.sub(' ', text)
    # Some IPTV lists use trailing superscript digits as source identifiers
    # (HD¹/HD²/HD³, Disney+ 1², etc.).  Strip only a trailing superscript
    # marker; ordinary channel numbers such as SporTV 2/Premiere 3 remain.
    text = _TRAILING_SOURCE_VARIANT_RE.sub('', text)
    # Preserve '+' when it is part of the channel/service name (Disney+,
    # Paramount+, FIFA+, HBO+) instead of confusing it with a quality marker.
    # Quality forms such as +HD/HD+ have already been removed above.
    text = _BRAND_PLUS_RE.sub(' plus ', text)
    text = re.sub(r'[^\w]+', ' ', text, flags=re.UNICODE)
    return ' '.join(text.split())


def _channel_quality_rank(value):
    text = str(value or '').casefold()
    # Superscript source markers must not hide the underlying quality from
    # the ranker (for example HD² must still rank as HD).
    text = re.sub(r'[⁰¹²³⁴⁵⁶⁷⁸⁹]+', '', text)
    if re.search(r'\b(?:4k|uhd)\b', text):
        rank = 400
    elif re.search(r'\b(?:fhd|full\s*hd)\b', text):
        rank = 300
    elif re.search(r'\bhd\b', text):
        rank = 200
    elif re.search(r'\bsd\b', text):
        rank = 100
    else:
        rank = 150
    if re.search(r'\b(?:hevc|h\.?265)\b', text):
        rank += 5
    if re.search(r'\b(?:backup|bkp|alt|alternativo)\b', text):
        rank -= 25
    return rank


def _live_variant_candidates(primary, rows):
    """Todas as fontes técnicas do mesmo canal, sem limite artificial.

    A identidade é o nome-base já normalizado pelo contrato existente
    (_channel_base_name), que remove apenas marcadores de qualidade/backup.
    Stream IDs repetidos são deduplicados para cada volta do fallback.
    """
    primary = primary if isinstance(primary, dict) else {}
    base = _channel_base_name(primary.get('name') or primary.get('title'))
    primary_id = str(primary.get('stream_id') or '')
    if not base or not primary_id:
        return []
    found = []
    seen_ids = {primary_id}
    for index, row in enumerate(rows if isinstance(rows, list) else []):
        if not isinstance(row, dict):
            continue
        sid = str(row.get('stream_id') or '')
        if not sid or sid in seen_ids:
            continue
        name = str(row.get('name') or row.get('title') or '')
        if _channel_base_name(name) != base:
            continue
        seen_ids.add(sid)
        found.append((_channel_quality_rank(name), -index, row))
    found.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return [dict(item[2]) for item in found]


def _series_episode_records(info, series_row=None):
    episodes = (info or {}).get('episodes') or {}
    if not isinstance(episodes, dict):
        return []

    def _num(value, fallback=0):
        try:
            return int(value)
        except Exception:
            try:
                return int(float(str(value)))
            except Exception:
                return fallback

    records = []
    for season_key, season_rows in episodes.items():
        season_num = _num(season_key, 0)
        for source_index, row in enumerate(season_rows if isinstance(season_rows, list) else []):
            if not isinstance(row, dict):
                continue
            sid = str(row.get('id') or row.get('stream_id') or '')
            if not sid:
                continue
            ep_num = _num(row.get('episode_num') or row.get('episode_number'), source_index + 1)
            details = row.get('info') if isinstance(row.get('info'), dict) else {}
            title = str(row.get('title') or details.get('name') or ('Episódio %s' % ep_num))
            art = str(details.get('movie_image') or details.get('cover_big') or (series_row or {}).get('cover') or '')
            records.append({
                'id': sid,
                'title': title,
                'extension': str(row.get('container_extension') or 'mp4'),
                'art': art,
                'plot': str(details.get('plot') or details.get('description') or ''),
                'season': season_num,
                'episode': ep_num,
            })
    records.sort(key=lambda row: (int(row.get('season') or 0), int(row.get('episode') or 0)))
    return records


def _next_series_episode(info, current_id, series_row=None):
    rows = _series_episode_records(info, series_row=series_row)
    current = str(current_id or '')
    for index, row in enumerate(rows):
        if str(row.get('id') or '') == current:
            return dict(rows[index + 1]) if index + 1 < len(rows) else None
    return None


def _wait_player_teardown(timeout=1.8):
    if xbmc is None:
        return True
    player = xbmc.Player()
    monitor = xbmc.Monitor()
    deadline = time.monotonic() + max(0.4, float(timeout))
    while time.monotonic() < deadline:
        try:
            if not player.isPlaying():
                return True
        except Exception:
            return True
        try:
            if monitor.waitForAbort(0.05):
                return False
        except Exception:
            try:
                xbmc.sleep(50)
            except Exception:
                break
    try:
        player.stop()
    except Exception:
        pass
    tail = time.monotonic() + 0.45
    while time.monotonic() < tail:
        try:
            if not player.isPlaying():
                return True
        except Exception:
            return True
        try:
            if monitor.waitForAbort(0.05):
                return False
        except Exception:
            break
    return False


def _live_variant_rows(client, primary, context):
    """Catálogo técnico usado pelo fallback Live.

    Em categorias normais, preserva exatamente o snapshot já exibido. Em
    Favoritos, o snapshot contém apenas os itens favoritados e não pode limitar
    as fontes técnicas do canal. Nesse caso, recupera sob demanda (somente
    depois de a fonte primária falhar) a categoria original gravada no próprio
    favorito e une esse catálogo ao snapshot atual, deduplicando stream_id.

    Se a categoria original estiver ausente ou indisponível, retorna o snapshot
    de Favoritos sem transformar a falha de uma consulta auxiliar em falha do
    player. Nenhuma URL/credencial é persistida ou registrada aqui.
    """
    context = context if isinstance(context, dict) else {}
    current_rows = context.get('items_snapshot') or []
    if str(context.get('category_id') or '') != '__favorites__':
        return current_rows

    primary = primary if isinstance(primary, dict) else {}
    source_category = str(primary.get('category_id') or primary.get('_ibo_category_id') or '').strip()
    if not source_category:
        log('Fallback Live Favoritos: categoria original ausente; mantendo snapshot local de Favoritos.', 'debug')
        return current_rows

    try:
        category_rows = client.live_streams(source_category) or []
    except Exception as exc:
        log('Fallback Live Favoritos: categoria original indisponível; mantendo snapshot local (%s).' % exc, 'debug')
        return current_rows

    if not isinstance(category_rows, list) or not category_rows:
        log('Fallback Live Favoritos: categoria original vazia; mantendo snapshot local.', 'debug')
        return current_rows

    merged = []
    seen = set()
    for row in list(category_rows) + list(current_rows if isinstance(current_rows, list) else []):
        if not isinstance(row, dict):
            continue
        sid = str(row.get('stream_id') or '')
        if sid and sid in seen:
            continue
        if sid:
            seen.add(sid)
        merged.append(row)

    variants = _live_variant_candidates(primary, merged)
    log('Fallback Live Favoritos: categoria original %s disponibilizou %d variante(s) técnica(s) do canal.' %
        (source_category, len(variants)), 'debug')
    return merged


def _try_live_variants(client, primary, context, epg_rows=None):
    """Fallback circular entre todas as fontes do mesmo canal.

    A fonte primária já falhou antes de entrar aqui. Primeiro percorremos todas
    as demais variantes do mesmo nome-base; depois reinserimos a primária no
    fim do anel. Se todas falharem, o anel recomeça e continua enquanto o Kodi
    estiver ativo ou até o usuário cancelar a janela de tentativa com Back.

    Stop durante uma reprodução continua sendo autoridade do usuário: um stream
    que terminou por Stop retorna normalmente e não é religado pelo círculo.
    """
    rows = _live_variant_rows(client, primary, context)
    candidates = _live_variant_candidates(primary, rows)
    if not candidates:
        return None

    # V2.0.96 preservado: o fallback troca somente a fonte técnica. Nome, logo,
    # descrição e snapshot EPG continuam pertencendo ao canal selecionado.
    primary_title = str(primary.get('name') or primary.get('title') or 'Canal')
    primary_art = primary.get('stream_icon') or ''
    primary_plot = primary.get('plot') or ''
    primary_epg_rows = list(epg_rows) if isinstance(epg_rows, list) else []

    # A primária entra no fim porque já acabou de falhar no fluxo normal:
    # P -> A -> B -> C -> P -> A -> B -> C ...
    ring = [dict(row) for row in candidates] + [dict(primary)]

    try:
        active_client = session_client()
    except Exception:
        active_client = client

    try:
        monitor = xbmc.Monitor() if xbmc is not None else None
    except Exception:
        monitor = None

    opening_window = begin_content_opening('Tentando outra fonte do canal...')
    last_outcome = None
    cycle = 1

    def _kodi_aborted():
        if monitor is None:
            return False
        try:
            return bool(monitor.abortRequested())
        except Exception:
            return False

    def _user_cancelled():
        try:
            return getattr(opening_window, 'result', None) == 'back'
        except Exception:
            return False

    try:
        while True:
            for index, candidate in enumerate(ring):
                if _kodi_aborted():
                    return {'ok': False, 'aborted': True, 'error': 'Execução cancelada pelo Kodi.'}
                if _user_cancelled():
                    log('Fallback circular: cancelado pelo usuário; retornando à lista de canais.', 'debug')
                    return {'ok': False, 'cancelled': True, 'error': ''}

                stream_id = str(candidate.get('stream_id') or '')
                if not stream_id:
                    continue
                extension = candidate.get('container_extension') or active_client.output
                raw = active_client.live_url(stream_id, extension)

                log('Fallback circular: ciclo %d, fonte %d/%d, stream %s (origem %s).' % (
                    cycle, index + 1, len(ring), stream_id, primary.get('stream_id')
                ), 'debug')

                try:
                    # Uma prova bounded por tentativa. O player recebe
                    # skip_probe=True para não duplicar a mesma requisição.
                    active_client.probe(raw, timeout=2.5, kind='live')
                except Exception as exc:
                    log('Fallback de qualidade: variante %s indisponível: %s' % (stream_id, exc), 'debug')
                    if _user_cancelled():
                        return {'ok': False, 'cancelled': True, 'error': ''}
                    continue

                # Snapshot EPG original continua soberano em todas as voltas.
                variant_epg_rows = primary_epg_rows
                if not variant_epg_rows:
                    try:
                        variant_epg_rows = active_client.short_epg_cached(stream_id, limit=8)
                    except Exception:
                        variant_epg_rows = []

                log('Fallback de qualidade: usando variante %s de %s; contexto EPG original=%s.' % (
                    stream_id, primary.get('stream_id'), 'preservado' if primary_epg_rows else 'indisponível'
                ), 'debug')

                last_outcome = _play_with_opening(
                    'live', stream_id, primary_title,
                    extension, primary_art, primary_plot, epg_rows=variant_epg_rows,
                    skip_probe=True,
                )

                # Reprodução saudável, Stop normal, Back para ONEPLAY e shutdown
                # mantêm exatamente o contrato já homologado/testado.
                if (last_outcome.get('ok') or last_outcome.get('aborted')
                        or last_outcome.get('backgrounded')):
                    return last_outcome
                if last_outcome.get('cancelled'):
                    return last_outcome

                # Watchdog/start failure: prepara a próxima tentativa do anel.
                opening_window = begin_content_opening('Tentando outra fonte do canal...')

            # Todas as fontes do nome-base falharam nesta volta. Recomeçar é
            # intencional: uma origem temporariamente ruim pode ter se recuperado.
            cycle += 1
            log('Fallback circular: todas as %d fontes falharam; iniciando ciclo %d.' % (
                len(ring), cycle
            ), 'debug')

            if _user_cancelled():
                return {'ok': False, 'cancelled': True, 'error': ''}
            if _kodi_aborted():
                return {'ok': False, 'aborted': True, 'error': 'Execução cancelada pelo Kodi.'}

            # Pequeno respiro entre voltas evita martelar o servidor caso todas
            # as probes falhem instantaneamente. Continua sendo cancelável.
            if monitor is not None:
                try:
                    if monitor.waitForAbort(1.0):
                        return {'ok': False, 'aborted': True, 'error': 'Execução cancelada pelo Kodi.'}
                except Exception:
                    time.sleep(1.0)
            else:
                time.sleep(1.0)
    finally:
        # Se nenhuma variante chegou/permaneceu no player, a janela antecipada
        # ainda pode ser nossa; feche-a sem afetar qualquer outro modal do Kodi.
        pending = claim_content_opening()
        if pending is not None:
            close_progress(pending)

def _login_loop():
    """Login manual puro.

    O Teste Automático pertence exclusivamente ao bootstrap de um dispositivo
    sem acesso cadastrado. Depois que a tela de login apareceu, ENTRAR e VOLTAR
    são as únicas ações possíveis e nenhuma tentativa automática é repetida.
    """
    while not load_session():
        result = show_login() or {'action': 'exit'}
        action = result.get('action') if isinstance(result, dict) else 'exit'
        if action == 'exit':
            return False
        if action != 'login':
            continue
        outcome = run_progress('Localizando acesso nas DNS do IBO...', lambda: manual_login(result.get('username'), result.get('password')))
        if outcome.get('ok'):
            # Fresh login starts with no session, so run_plugin() could not request
            # the background panel/banner sync before entering this loop. Trigger
            # it now; Home still opens immediately and health.py resolves the
            # Theme 2 banner asynchronously through the existing pipeline.
            _sync_panel_background()
            return True
        show_message('ACESSO IBO', outcome.get('error') or 'Não foi possível autenticar.')
    return True


def _movie_detail(client, row):
    vod_id = str((row or {}).get('stream_id') or '')
    try:
        pack = run_progress('Carregando informações do filme...', lambda: client.vod_info(vod_id)) or {}
    except Exception as exc:
        log('Filmes: falha técnica ao carregar informações: %s' % exc, 'warning')
        show_message('FILMES', humanize_content_error(exc, kind='movie', phase='details'))
        return
    info = pack.get('info') or {}
    movie_data = pack.get('movie_data') or {}
    poster = str(info.get('movie_image') or row.get('stream_icon') or '')
    backdrop = info.get('backdrop_path') or info.get('backdrop') or ''
    if isinstance(backdrop, list):
        backdrop = backdrop[0] if backdrop else ''
    title = str(info.get('name') or movie_data.get('name') or row.get('name') or 'Filme')
    plot_text = str(info.get('plot') or info.get('description') or '')
    year = info.get('releasedate') or info.get('year') or row.get('year') or ''
    genre = str(info.get('genre') or '')
    duration = str(info.get('duration') or '')
    rating = str(info.get('rating') or '')
    meta = '  •  '.join([x for x in (str(year), genre, duration, ('Nota ' + rating if rating else '')) if x])
    stream_id = str(movie_data.get('stream_id') or row.get('stream_id') or '')
    extension = movie_data.get('container_extension') or row.get('container_extension') or 'mp4'
    resume_at = resume_seconds('movie', stream_id)
    payload = {
        'title': title, 'plot': plot_text, 'poster': poster, 'backdrop': backdrop,
        'meta': meta, 'resume_at': resume_at, 'kind': 'movie', 'stream_id': stream_id,
    }
    while True:
        detail_action = show_info(payload)
        if detail_action == 'resume_player':
            _resume_player_with_opening()
            # O mesmo player pode ter avançado vários minutos em background.
            # Reabra o detalhe já com o ponto local mais recente, sem request.
            resume_at = resume_seconds('movie', stream_id)
            payload['resume_at'] = resume_at
            continue
        if detail_action == 'cast_stop':
            _cast_stop_ui()
            continue
        if detail_action == 'cast':
            year_num = None
            try:
                year_num = int(str(year)[:4])
            except Exception:
                pass
            outcome = _cast_prepared('movie', stream_id, title, extension, poster, plot_text, year_num)
            if not outcome.get('ok') and not outcome.get('cancelled'):
                show_message('TRANSMITIR', humanize_content_error(outcome.get('error'), kind='movie', phase='playback', fallback=ui('cast_failed', 'Não foi possível iniciar a transmissão.')))
            continue
        if detail_action != 'play':
            return None
        year_num = None
        try:
            year_num = int(str(year)[:4])
        except Exception:
            pass
        playback_meta = {
            'kind': 'movie', 'stream_id': stream_id, 'title': title,
            'extension': extension, 'art': poster, 'plot': plot_text,
            'portal_id': str((load_session() or {}).get('portal_id') or ''),
        }
        if year_num is not None:
            playback_meta['year'] = year_num
        outcome = _play_with_opening(
            'movie', stream_id, title, extension, poster, plot_text, year_num,
            resume_at=resume_at, playback_meta=playback_meta,
        )
        if outcome.get('aborted'):
            return 'abort'
        if not outcome.get('ok'):
            show_message('REPRODUÇÃO', humanize_content_error(outcome.get('error'), kind='movie', phase='playback', fallback='Filme indisponível\nNão foi possível abrir esta mídia agora. Tente novamente.'))
        # Atualiza o ponto exibido caso o usuário tenha parado e permaneça nesta
        # mesma tela de detalhes; não existe novo request Xtream/TMDB.
        resume_at = resume_seconds('movie', stream_id)
        payload['resume_at'] = resume_at

def _series_detail(client, row):
    series_id = str((row or {}).get('series_id') or '')
    series_title = str((row or {}).get('name') or 'Série')
    series_art = str((row or {}).get('cover') or (row or {}).get('cover_big') or '')
    try:
        info = run_progress('Carregando temporadas e episódios...', lambda: client.series_info(series_id)) or {}
    except Exception as exc:
        log('Séries: falha técnica ao carregar temporadas/episódios: %s' % exc, 'warning')
        show_message('SÉRIES', humanize_content_error(exc, kind='series', phase='details'))
        return
    while True:
        result = show_series_episodes(client, row, info)
        if isinstance(result, dict) and result.get('action') == 'resume_player':
            _resume_player_with_opening()
            continue
        if isinstance(result, dict) and result.get('action') == 'cast_stop':
            _cast_stop_ui()
            continue
        if isinstance(result, dict) and result.get('action') == 'cast':
            current_id = str(result.get('id') or '')
            title = str(result.get('title') or 'Episódio')
            outcome = _cast_prepared(
                'series', current_id, title, result.get('extension') or 'mp4',
                result.get('art') or series_art, result.get('plot') or '',
                season=result.get('season'), episode=result.get('episode'),
            )
            if not outcome.get('ok') and not outcome.get('cancelled'):
                show_message('TRANSMITIR', humanize_content_error(outcome.get('error'), kind='series', phase='playback', fallback=ui('cast_failed', 'Não foi possível iniciar a transmissão.')))
            continue
        if not isinstance(result, dict) or result.get('action') != 'play':
            return

        current = dict(result)
        while current:
            current_id = str(current.get('id') or '')
            next_item = _next_series_episode(info, current_id, series_row=row)
            playback_meta = {
                'kind': 'series', 'stream_id': current_id, 'title': str(current.get('title') or ''),
                'extension': str(current.get('extension') or 'mp4'), 'art': str(current.get('art') or series_art),
                'plot': str(current.get('plot') or ''), 'season': current.get('season'), 'episode': current.get('episode'),
                'series_id': series_id, 'series_title': series_title, 'series_art': series_art,
                'portal_id': str((load_session() or {}).get('portal_id') or ''),
            }
            resume_at = resume_seconds('series', current_id)
            auto_next = bool(get_int('up_next_auto', default=0, low=0, high=1))

            def _prompt(next_row, _remaining):
                return show_up_next(next_row, auto=auto_next, seconds=8)

            outcome = _play_with_opening(
                'series', current_id, current.get('title'), current.get('extension'),
                current.get('art'), current.get('plot'), None, current.get('season'), current.get('episode'),
                resume_at=resume_at, playback_meta=playback_meta, up_next=next_item, up_next_prompt=_prompt if next_item else None,
            )
            if outcome.get('aborted'):
                return 'abort'
            if outcome.get('up_next') and next_item:
                if not _wait_player_teardown():
                    show_message('PRÓXIMO EPISÓDIO', 'O player anterior ainda está encerrando. Abra o próximo episódio novamente.')
                    break
                current = dict(next_item)
                begin_content_opening('Abrindo próximo episódio...')
                continue
            if not outcome.get('ok'):
                show_message('REPRODUÇÃO', humanize_content_error(outcome.get('error'), kind='series', phase='playback', fallback='Episódio indisponível\nNão foi possível abrir esta mídia agora. Tente novamente.'))
            break

def _categories(client, mode):
    if mode == 'live':
        return client.live_categories()
    if mode == 'movie':
        return client.vod_categories()
    return client.series_categories()


def _section_loop(initial_mode):
    mode = initial_mode
    contexts = {'live': {}, 'movie': {}, 'series': {}}
    categories_cache = {}
    while mode in ('live', 'movie', 'series'):
        try:
            client = session_client()
        except Exception as exc:
            log('%s: sessão de conteúdo inválida: %s' % (content_title(mode), exc), 'warning')
            show_message(content_title(mode), humanize_content_error(exc, kind=mode, phase='session'))
            return 'home'
        if mode not in categories_cache:
            try:
                categories_cache[mode] = run_progress('Carregando categorias...', lambda: _categories(client, mode)) or []
            except Exception as exc:
                log('%s: falha técnica ao carregar categorias: %s' % (content_title(mode), exc), 'warning')
                show_message(content_title(mode), humanize_content_error(exc, kind=mode, phase='categories'))
                return 'home'
        result = show_browser(mode, categories_cache[mode], client, contexts.get(mode)) or {'action': 'home'}
        action = result.get('action') if isinstance(result, dict) else 'home'
        if action == 'home':
            return 'home'
        if action == 'section':
            mode = str(result.get('mode') or mode)
            continue
        context = result.get('context') or {}
        contexts[mode] = context
        if action == 'resume_player':
            _resume_player_with_opening()
            continue
        if action == 'cast_stop':
            _cast_stop_ui()
            continue
        if action == 'cast_live':
            row = result.get('item') or {}
            outcome = _cast_live_with_variants(client, row, context)
            if not outcome.get('ok') and not outcome.get('cancelled'):
                show_message('TRANSMITIR', humanize_content_error(outcome.get('error'), kind='live', phase='playback', fallback=ui('cast_failed', 'Não foi possível iniciar a transmissão.')))
            continue
        if action == 'cast_movie':
            row = result.get('item') or {}
            title = str(row.get('name') or row.get('title') or 'Filme')
            extension = row.get('container_extension') or 'mp4'
            outcome = _cast_prepared('movie', row.get('stream_id'), title, extension, row.get('stream_icon') or '', row.get('plot') or '', row.get('year'))
            if not outcome.get('ok') and not outcome.get('cancelled'):
                show_message('TRANSMITIR', humanize_content_error(outcome.get('error'), kind='movie', phase='playback', fallback=ui('cast_failed', 'Não foi possível iniciar a transmissão.')))
            continue
        if action == 'play_live':
            row = result.get('item') or {}
            # Reuse only the EPG snapshot already fetched by IBOLive. This is
            # deliberately cache-only: player metadata must never add network
            # latency or make a channel wait for get_short_epg.
            try:
                epg_rows = client.short_epg_cached(row.get('stream_id'), limit=8)
            except Exception as exc:
                epg_rows = []
                log('EPG em cache indisponível para o player: %s' % exc, 'debug')
            outcome = _play_with_opening('live', row.get('stream_id'), str(row.get('name') or row.get('title') or 'Canal'),
                                    row.get('container_extension') or client.output, row.get('stream_icon') or '',
                                    row.get('plot') or '', epg_rows=epg_rows)
            if outcome.get('aborted'):
                return 'abort'
            if not outcome.get('ok'):
                # Segunda camada local: percorre todas as fontes do mesmo
                # nome-base e, se necessário, continua em círculo. Não cruza
                # para outro canal e preserva o snapshot EPG do item original.
                alternate = _try_live_variants(client, row, context, epg_rows=epg_rows)
                if alternate is not None:
                    outcome = alternate
                if outcome.get('aborted'):
                    return 'abort'
                if outcome.get('cancelled'):
                    continue
            if not outcome.get('ok'):
                show_message('REPRODUÇÃO', humanize_content_error(outcome.get('error'), kind='live', phase='playback', fallback='Canal indisponível\nNão foi possível abrir esta mídia agora. Tente novamente.'))
            continue
        if action == 'movie_detail':
            if _movie_detail(session_client(), result.get('item') or {}) == 'abort':
                return 'abort'
            continue
        if action == 'series_detail':
            if _series_detail(session_client(), result.get('item') or {}) == 'abort':
                return 'abort'
            continue
    return 'home'


def _portal_locked(portal):
    return str((portal or {}).get('is_protected') or '').lower() in ('1', 'true', 'yes', 'on')


def _access_manager():
    session = load_session()
    if not session:
        return 'session_gone'
    client = PanelClient()
    try:
        # V2.0.4 usa o snapshot leve do index.php: sem failover/probe, sem
        # credenciais e normalmente em subsegundos no próprio painel.
        state = run_progress('Consultando acessos no painel...', lambda: client.index_state(timeout=3))
    except Exception as exc:
        log('PORTAL: falha técnica ao consultar acessos: %s' % exc, 'warning')
        show_message('PORTAL', humanize_portal_error(exc, operation='list'))
        return 'nochange'
    denied = str(state.get('access_denied') or '').strip()
    if state.get('device_blocked') or denied:
        clear_session()
        show_message('PORTAL', humanize_portal_error(denied or 'Acesso bloqueado. Uso não autorizado.', operation='list', reason='access_denied'))
        return 'session_gone'
    portals = client.accesses_from_state(state)
    cache = load_panel()
    cache.update(panel_subset(state))
    save_panel(cache)
    if not portals:
        show_message('PORTAL', 'Nenhum acesso disponível\nEste dispositivo não possui acessos liberados no painel.')
        return 'nochange'

    while True:
        result = show_access(load_session(), portals) or {'action':'back'}
        action = result.get('action') if isinstance(result, dict) else 'back'
        if action == 'back':
            return 'back'
        pid = str(result.get('id') or '')
        selected = next((row for row in portals if str((row or {}).get('id') or '') == pid), None)
        if action == 'locked':
            show_message('PORTAL', 'Acesso protegido\nEste acesso não pode ser excluído porque o gerenciamento está bloqueado no painel.')
            continue
        if action == 'use':
            outcome = run_progress('Conectando ao portal selecionado...', lambda: switch_portal(pid))
            if outcome.get('ok'):
                # Trocar o portal substitui o snapshot salvo por connect_from_panel().
                # Solicite imediatamente a mesma sincronização visual usada no login/
                # reabertura. O service mantém o cooldown da leitura completa, mas
                # ainda atualiza o banner do Tema 2 pelo caminho curto.
                _sync_panel_background()
                log('Troca de portal: sincronização visual do painel solicitada.', 'debug')
                show_message('PORTAL', 'Acesso conectado\nO acesso selecionado está pronto para uso.')
                return 'changed'
            log('PORTAL: troca de acesso recusada/falhou (reason=%s): %s' % (
                str(outcome.get('reason') or ''), str(outcome.get('error') or 'sem detalhe')), 'warning')
            show_message('PORTAL', humanize_portal_error(
                outcome.get('error'), operation='connect', reason=outcome.get('reason')))
            continue
        if action == 'delete':
            # Defesa dupla: mesmo se uma UI antiga/stale emitir delete, não
            # chamamos update.php quando o painel marcou o acesso protegido.
            if _portal_locked(selected):
                show_message('PORTAL', 'Acesso protegido\nEste acesso não pode ser excluído porque o gerenciamento está bloqueado no painel.')
                continue
            name = str(result.get('name') or ('DNS ' + pid))
            if not show_confirm('EXCLUIR ACESSO', 'Remover %s deste dispositivo?\n\nA sessão será encerrada imediatamente.' % name):
                continue
            try:
                response = run_progress('Excluindo acesso...', lambda: client.delete_access(pid, timeout=4))
            except Exception as exc:
                log('PORTAL: falha técnica ao excluir acesso: %s' % exc, 'warning')
                show_message('PORTAL', humanize_portal_error(exc, operation='delete'))
                continue
            success = int(response.get('success') or response.get('result') or 0) == 1 or response.get('status') is True
            if not success:
                panel_error = response.get('message') or response.get('mensagem') or response.get('access_denied') or ''
                log('PORTAL: painel não concluiu exclusão (reason=%s): %s' % (
                    str(response.get('reason') or response.get('status') or ''), str(panel_error or 'sem detalhe')), 'warning')
                show_message('PORTAL', humanize_portal_error(
                    panel_error, operation='delete', reason=response.get('reason'), response=response))
                # Se a trava foi habilitada no painel depois de abrir a tela,
                # refresca o estado leve antes da próxima tentativa.
                if response.get('management_locked') or str(response.get('access_manage_locked') or '') == 'yes':
                    try:
                        fresh = client.index_state(timeout=3)
                        portals = client.accesses_from_state(fresh) or portals
                    except Exception:
                        pass
                continue
            clear_session()
            show_message('PORTAL', 'Acesso removido\nO acesso foi excluído deste dispositivo com sucesso.')
            return 'session_gone'


def _manual_refresh_action():
    """Atualiza dados do painel/catálogo preservando o cache físico de artes."""
    clear_catalog_cache()

    def _manual_refresh():
        # ATUALIZAR é uma solicitação explícita do usuário e não deve depender
        # do cooldown da sincronização automática do service.
        sync = sync_panel_for_open() or {}
        if sync.get('ok') and not sync.get('stale'):
            _refresh_banner_only()
        return sync

    sync = run_progress('Atualizando painel, tema e catálogos...', _manual_refresh) or {}
    if not sync.get('ok'):
        show_message('ATUALIZAR', sync.get('error') or 'O acesso não está mais disponível.')
        return 'abort'
    if sync.get('stale'):
        show_message('ATUALIZAR', 'Painel indisponível. Mantendo as últimas configurações salvas.')
        return 'stale'
    # Sucesso segue diretamente para o loop da Home; o progresso já encerrou.
    # Diálogo informativo fica reservado a falha/estado stale.
    return 'ok'


def _home_loop():
    while load_session():
        session = load_session()
        panel = load_panel()
        action = show_home(session, panel, _banner(panel)) or 'exit'
        if action == 'exit':
            return False
        if action in ('live', 'movie', 'series'):
            if _section_loop(action) == 'abort':
                return False
            continue
        if action == 'games':
            try:
                games = run_progress('Carregando jogos...', lambda: PanelClient().games_view(timeout=4)) or {}
                show_games(games)
            except Exception as exc:
                log('JOGOS indisponível: %s' % exc, 'warning')
                show_message('JOGOS', 'Não foi possível carregar os jogos/eventos do painel.')
            continue
        if action == 'account':
            # Mantido apenas por compatibilidade interna com versões anteriores.
            show_account(load_session())
            continue
        if action == 'access':
            _access_manager()
            if not load_session():
                return True
            continue
        if action == 'settings':
            # Subjanelas informativas/canceladas retornam ao pai Configurações.
            # Uma troca real de portal muda o contexto da sessão e retorna à Home.
            while load_session():
                settings_result = show_settings()
                settings_action = settings_result.get('action') if isinstance(settings_result, dict) else ''
                if settings_action == 'access':
                    access_result = _access_manager()
                    if not load_session() or access_result == 'session_gone':
                        return True
                    if access_result in ('back', 'nochange'):
                        continue
                    break
                if settings_action == 'refresh':
                    if _manual_refresh_action() == 'abort':
                        return True
                break
            continue
        if action == 'refresh':
            if _manual_refresh_action() == 'abort':
                return True
            continue
    return True


_EXIT_GUARD_PROPERTY = 'IBO.V2.ExitPending'
_MATRIX_RETURN_HINT_PROPERTY = 'OnePlayMatrix.IBOReturnFast'


def _arm_exit_guard():
    """Mark the intentional IBO exit before ShellWindow exposes MyVideoNav.

    Kodi 21 immediately reloads the underlying ``plugin://`` directory while
    the first interpreter is unwinding.  That automatic invocation must finish
    as an empty directory instead of reopening the IBO UI.  Navigation back to
    the caller is coordinated by the persistent service, not by a hard-coded
    target window.
    """
    if xbmcgui is None:
        return
    try:
        xbmcgui.Window(10000).setProperty(_EXIT_GUARD_PROPERTY, '%.6f' % time.time())
    except Exception as exc:
        log('Não foi possível armar guard de saída: %s' % exc, 'debug')


def _clear_exit_guard():
    if xbmcgui is None:
        return
    try:
        xbmcgui.Window(10000).clearProperty(_EXIT_GUARD_PROPERTY)
    except Exception:
        pass


def _launched_from_matrix():
    """Return True only for the explicit ONEPLAY Matrix hand-off.

    The 2.2.8 opening path is intentionally untouched.  This marker is used
    exclusively after the ONEPLAY UI session has ended so direct exits can
    target Home while Matrix exits keep Kodi's preserved caller history.
    """
    try:
        query = str(sys.argv[2] or '') if len(sys.argv) > 2 else ''
    except Exception:
        query = ''
    return 'origin=oneplay_matrix' in query.lower()


def _replace_matrix_shell_with_matrix(timeout=0.85):
    """Retorna ao Matrix com Home válida preservada como predecessor.

    O launcher Matrix -> IBO usa ReplaceWindow para que o Matrix não permaneça
    renderizado por baixo das janelas ONEPLAY no Android. No retorno, porém,
    reconstruir o Matrix também por ReplaceWindow deixa sua raiz sem um pai
    navegável; o próximo Back tenta derivar ``plugin://`` e o Kodi exibe Busy
    antes de falhar e cair na Home.

    A saída correta é assimétrica e deliberada: ainda sob controle do Shell do
    IBO, substitua-o primeiro pela Home nativa (destino local/provado da saída
    direta) e então abra o Matrix em Videos. Assim Home -> Matrix passa a ser o
    histórico real e o próximo Back sai diretamente para Home, sem consultar
    ``plugin://``. Este helper continua exclusivo de ``origin=oneplay_matrix``.
    """
    if xbmc is None or xbmcgui is None:
        return False
    target = 'plugin://plugin.video.OnePlay.Matrix/'

    # Fast-path volátil de retorno: a raiz Matrix continua sendo a mesma URL,
    # mas sua próxima invocação sabe que veio do IBO e evita trabalho visual
    # desnecessário. O marcador é consumido uma única vez pelo Matrix.
    try:
        xbmcgui.Window(10000).setProperty(_MATRIX_RETURN_HINT_PROPERTY, str(time.time()))
    except Exception:
        pass

    # 1) Semeie uma origem válida no histórico. ReplaceWindow(Home) já é o
    # caminho homologado da saída direta e não depende de plugin://.
    home_ready = False
    try:
        try:
            xbmc.executebuiltin('ReplaceWindow(Home)', True)
        except TypeError:
            xbmc.executebuiltin('ReplaceWindow(Home)')
        home_deadline = time.time() + 0.45
        while time.time() < home_deadline:
            try:
                if int(xbmcgui.getCurrentWindowId()) == 10000:
                    home_ready = True
                    break
            except Exception:
                pass
            try:
                xbmc.sleep(10)
            except Exception:
                break
    except Exception as exc:
        log('SAIR Matrix: não foi possível semear Home antes do Matrix: %s' % exc, 'debug')

    # 2) Com Home ativa, ActivateWindow(...,return) adiciona Videos/Matrix por cima
    # dela e marca a raiz Matrix como startDirectory nativa do MyVideoNav. Assim
    # o Back na raiz não tenta derivar plugin://; cai no histórico Home.
    # Se esta etapa for recusada por alguma skin/build, preserve o fallback
    # anterior via ReplaceWindow em vez de interromper a saída do usuário.
    if home_ready:
        command = 'ActivateWindow(Videos,%s,return)' % target
    else:
        command = 'ReplaceWindow(Videos,%s)' % target
    try:
        try:
            xbmc.executebuiltin(command, True)
        except TypeError:
            xbmc.executebuiltin(command)
    except Exception as exc:
        if home_ready:
            log('SAIR Matrix: ActivateWindow(Videos, Matrix) indisponível; usando fallback ReplaceWindow: %s' % exc, 'debug')
            try:
                fallback = 'ReplaceWindow(Videos,%s)' % target
                try:
                    xbmc.executebuiltin(fallback, True)
                except TypeError:
                    xbmc.executebuiltin(fallback)
            except Exception as fallback_exc:
                log('SAIR Matrix: fallback ReplaceWindow(Videos, Matrix) indisponível: %s' % fallback_exc, 'debug')
                return False
        else:
            log('SAIR Matrix: ReplaceWindow(Videos, Matrix) indisponível: %s' % exc, 'debug')
            return False

    # O builtin aceito entrega o retorno ao window manager. A checagem abaixo
    # é somente diagnóstica; nunca dispare um segundo Back/retorno enquanto a
    # Home local do Matrix ainda estiver sendo populada.
    deadline = time.time() + max(0.15, float(timeout or 0.0))
    last_current = 0
    last_folder = ''
    while time.time() < deadline:
        try:
            last_current = int(xbmcgui.getCurrentWindowId())
        except Exception:
            last_current = 0
        try:
            last_folder = str(xbmc.getInfoLabel('Container.FolderPath') or '').strip()
        except Exception:
            last_folder = ''
        if last_current == 10025 and last_folder.lower().startswith(target.lower()):
            if home_ready:
                log('SAIR Matrix: retorno concluído com Home preservada como predecessor; Back não depende de plugin://.', 'debug')
            else:
                log('SAIR Matrix: retorno explícito concluído via fallback sem depender do histórico anterior.', 'debug')
            return True
        if last_current == 10025 and last_folder and not last_folder.lower().startswith(PLUGIN_URL.lower()):
            log('SAIR Matrix: janela de Vídeos já entregue ao contexto externo (%s).' % last_folder, 'debug')
            return True
        try:
            xbmc.sleep(10)
        except Exception:
            break
    log('SAIR Matrix: retorno aceito; Home do Matrix ainda em carregamento (janela=%s, pasta=%s, home_seed=%s).' % (last_current, last_folder, home_ready), 'debug')
    return True


def _replace_direct_shell_with_home(timeout=0.55):
    """Replace the closing Shell with Home without exposing MyVideoNav.

    Kodi's ReplaceWindow uses the window manager's swapping mode: it removes
    the current window from history before adding the destination.  Home is
    already present in a normal direct launch history, and AddToWindowHistory
    truncates everything above an existing destination.  The result is a
    direct Shell -> Home transition that removes the transient MyVideoNav frame
    instead of briefly rendering it and then issuing Action(Back).

    This helper is exit-only and must never run for origin=oneplay_matrix.
    It returns:
      * 'home' when Home became active;
      * 'caller' when another non-IBO context became active;
      * 'myvideonav' when Kodi exposed MyVideoNav (use old settle fallback);
      * 'shell' when the Shell stayed active (use old close/fallback path).
    """
    if xbmc is None or xbmcgui is None:
        return 'shell'
    try:
        xbmc.executebuiltin('ReplaceWindow(Home)')
    except Exception as exc:
        log('SAIR direto: ReplaceWindow(Home) indisponível; usando fallback histórico: %s' % exc, 'debug')
        return 'shell'

    deadline = time.time() + max(0.10, float(timeout or 0.0))
    last = 0
    while time.time() < deadline:
        try:
            last = int(xbmcgui.getCurrentWindowId())
        except Exception:
            last = 0
        if last == 10000:
            log('SAIR direto: Shell substituído diretamente pela Home; MyVideoNav não foi exposto.', 'debug')
            return 'home'
        if last == 10025:
            return 'myvideonav'
        if last not in (0, 13000, 13001):
            log('SAIR direto: Kodi já ativou contexto não-IBO (janela %s).' % last, 'debug')
            return 'caller'
        try:
            xbmc.sleep(10)
        except Exception:
            break
    return 'myvideonav' if last == 10025 else 'shell'


def _consume_exit_guard():
    if xbmcgui is None:
        return False
    try:
        window = xbmcgui.Window(10000)
        raw = str(window.getProperty(_EXIT_GUARD_PROPERTY) or '')
        if not raw:
            return False
        try:
            age = max(0.0, time.time() - float(raw))
        except Exception:
            age = 999.0
        current = int(xbmcgui.getCurrentWindowId())
        # Automatic reload after Shell closes happens in MyVideoNav.  Keep a
        # short guard so a later deliberate launch can never be swallowed.
        consume = age <= 3.0 and current == 10025
        if consume:
            window.clearProperty(_EXIT_GUARD_PROPERTY)
            log('Reentrada automática do MyVideoNav interceptada após SAIR.', 'debug')
        elif age > 3.0:
            window.clearProperty(_EXIT_GUARD_PROPERTY)
        return consume
    except Exception as exc:
        log('Falha ao consumir guard de saída: %s' % exc, 'debug')
        return False



def _settle_detached_exit_immediately(timeout=0.70):
    """Finish a detached-root SAIR without waiting for the 1 s service tick.

    This runs only after IBOHome2 has already closed and ``close_shell()`` has
    been requested, and only when the deliberate launcher root was successfully
    detached at opening.  It never invents a destination:

    * MyVideoNav + empty FolderPath -> the detached launcher frame is empty;
      issue exactly one history Back immediately.
    * MyVideoNav + non-IBO FolderPath -> Kodi already restored the real caller;
      clear the exit token and do not navigate.
    * MyVideoNav + IBO FolderPath -> platform fallback; leave the historical
      2.1.4 ExitPending/service path untouched.

    Three consecutive empty-container samples are required before Back so the
    command is not sent into the Shell closing animation.
    """
    if xbmc is None or xbmcgui is None:
        return False

    deadline = time.time() + max(0.10, float(timeout or 0.0))
    empty_samples = 0
    while time.time() < deadline:
        try:
            busy = bool(
                xbmc.getCondVisibility('Window.IsActive(busydialog)') or
                xbmc.getCondVisibility('Window.IsActive(busydialognocancel)') or
                xbmc.getCondVisibility('Window.IsActive(progressdialog)')
            )
        except Exception:
            busy = False

        try:
            current = int(xbmcgui.getCurrentWindowId())
        except Exception:
            current = 0
        try:
            folder = str(xbmc.getInfoLabel('Container.FolderPath') or '').strip()
        except Exception:
            folder = ''

        if current == 10025:
            if folder.startswith(PLUGIN_URL):
                # Kodi retained/recreated the IBO frame. Do not race it: the
                # homologated guarded reload/service path remains authoritative.
                return False
            if folder:
                clear_exit_return()
                _clear_exit_guard()
                log('SAIR: contexto chamador já restaurado sem etapa intermediária (%s).' % folder, 'debug')
                return True
            if not busy:
                empty_samples += 1
                if empty_samples >= 3:
                    try:
                        xbmc.executebuiltin('Action(Back)')
                        clear_exit_return()
                        _clear_exit_guard()
                        log('SAIR: MyVideoNav vazio concluído imediatamente pelo histórico do Kodi.', 'debug')
                        return True
                    except Exception as exc:
                        log('SAIR: MyVideoNav vazio detectado, mas Back imediato falhou: %s' % exc, 'debug')
                        return False
            else:
                empty_samples = 0
        elif current not in (0, 13000, 13001):
            # Home, AddonBrowser or another non-IBO context is already visible.
            clear_exit_return()
            _clear_exit_guard()
            log('SAIR: contexto anterior já visível após fechar o Shell (janela %s).' % current, 'debug')
            return True
        else:
            empty_samples = 0

        try:
            xbmc.sleep(20)
        except Exception:
            break
    return False


def _request_history_return_after_guarded_reentry():
    """Return through Kodi history only after the transient plugin reload is complete.

    V2.0.16 tried to issue Back immediately after ShellWindow closed. The real
    Kodi log proved that this races the automatic MyVideoNav reload and causes
    XFILE/CGUIMediaWindow directory failures. Here the order is reversed:
    the guarded reload first finishes its directory handle, then (and only then)
    one Back is requested while MyVideoNav still points at this add-on root.
    The persistent service keeps the exit token as a fallback/arbiter and will
    merely clear it if Kodi has already restored the caller.
    """
    if xbmc is None or xbmcgui is None:
        return False
    deadline = time.time() + 0.45
    while time.time() < deadline:
        try:
            busy = bool(
                xbmc.getCondVisibility('Window.IsActive(busydialog)') or
                xbmc.getCondVisibility('Window.IsActive(busydialognocancel)') or
                xbmc.getCondVisibility('Window.IsActive(progressdialog)')
            )
        except Exception:
            busy = False
        if busy:
            try:
                xbmc.sleep(10)
            except Exception:
                break
            continue

        try:
            current = int(xbmcgui.getCurrentWindowId())
        except Exception:
            current = 0
        try:
            folder = str(xbmc.getInfoLabel('Container.FolderPath') or '').strip()
        except Exception:
            folder = ''

        if current == 10025:
            if folder and not folder.startswith(PLUGIN_URL):
                return True
            if folder.startswith(PLUGIN_URL) or not folder:
                try:
                    xbmc.executebuiltin('Action(Back)')
                    log('SAIR: reentrada transitória concluída; retorno solicitado pelo histórico do Kodi.', 'debug')
                    return True
                except Exception as exc:
                    log('SAIR: reentrada concluída, mas o retorno não pôde ser solicitado: %s' % exc, 'debug')
                    return False
        elif current not in (0, 13000, 13001):
            return True

        try:
            xbmc.sleep(10)
        except Exception:
            break
    return False


def _resolve_media_invocation(handle):
    """Resolve the opaque playback route and return True when it was handled.

    This branch must run before every launcher/exit/UI side effect. Kodi invokes
    the same plugin a second time only to resolve CFileItem.DynPath. The plugin
    URL becomes the durable/safe Path; the active local/LAN relay becomes DynPath.
    """
    try:
        query = str(sys.argv[2] or '') if len(sys.argv) > 2 else ''
    except Exception:
        query = ''
    if query.startswith('?'):
        query = query[1:]
    try:
        params = urllib.parse.parse_qs(query, keep_blank_values=False)
    except Exception:
        params = {}
    action = str((params.get('ibo_action') or [''])[0] or '').strip().lower()
    if action != 'resolve_media':
        return False

    success = False
    item = xbmcgui.ListItem(label='') if xbmcgui is not None else None
    try:
        encoded = str((params.get('target') or [''])[0] or '').strip()
        if not encoded:
            raise ValueError('target ausente')
        padding = '=' * ((4 - len(encoded) % 4) % 4)
        target = base64.urlsafe_b64decode((encoded + padding).encode('ascii')).decode('utf-8')
        if not is_current_relay_url(target):
            raise ValueError('target fora do relay atual')
        if item is None:
            raise RuntimeError('ListItem indisponível')
        item.setPath(target)
        try:
            item.setMimeType(relay_mime_for(target))
            item.setContentLookup(False)
            item.setProperty('IsPlayable', 'true')
        except Exception:
            pass

        # FFmpeg Direct must be configured here, on the ListItem returned by
        # setResolvedUrl().  The original ListItem passed to Player.play() owns
        # the durable plugin:// Path; this item owns the local/LAN Relay DynPath and
        # is where Kodi selects an inputstream client.
        fd_requested = str((params.get('fd') or ['0'])[0] or '0') == '1'
        realtime = str((params.get('rt') or ['0'])[0] or '0') == '1'
        fd_applied = False
        if fd_requested:
            fmt = ffmpeg_direct_format(target)
            if fmt and ffmpeg_direct_available():
                fd_applied = configure_ffmpeg_direct(item, fmt, 'live' if realtime else 'vod')
            if not fd_applied:
                log('Resolver seguro de mídia: FFmpeg Direct solicitado, mas indisponível; DynPath seguirá no padrão Kodi.', 'warning')

        success = True
        if fd_applied:
            log('Resolver seguro de mídia: Path plugin convertido em DynPath do Relay local/LAN + FFmpeg Direct (%s).' % fmt, 'debug')
        else:
            log('Resolver seguro de mídia: Path plugin convertido em DynPath do Relay local/LAN.', 'debug')
    except Exception as exc:
        log('Resolver seguro de mídia recusou a solicitação: %s' % exc, 'warning')

    if xbmcplugin is not None and handle is not None and item is not None:
        try:
            xbmcplugin.setResolvedUrl(int(handle), bool(success), item)
        except Exception as exc:
            log('Resolver seguro de mídia não conseguiu concluir o handle: %s' % exc, 'error')
    return True


def run_plugin():
    handle = None
    try:
        handle = int(sys.argv[1])
    except Exception:
        pass

    # Native Kodi playback resolver. It is deliberately first: this invocation
    # is not an app launch and must never touch Shell, session, exit guards or UI.
    if _resolve_media_invocation(handle):
        return

    # If Kodi auto-reloads plugin:// after an intentional SAIR, complete the
    # transient directory first. Only after endOfDirectory succeeds may this
    # invocation ask Kodi history to go Back. This ordering avoids the V2.0.16
    # race that cancelled GetDirectory while it was still starting.
    if _consume_exit_guard():
        _complete_directory(handle)
        if _request_history_return_after_guarded_reentry():
            log('Reentrada automática concluída; retorno entregue ao histórico do Kodi.', 'debug')
        else:
            log('Reentrada automática concluída; serviço manterá o fallback de retorno.', 'debug')
        return

    # A deliberate new launch supersedes any stale exit request/alarm state.
    clear_exit_return()
    _clear_exit_guard()

    # Só uma abertura deliberada do ONEPLAY consome o marcador. A reentrada
    # transitória automática usada pelo SAIR retorna acima e não passa aqui.
    try:
        cleanup = cleanup_downloaded_apks() or {}
        if cleanup.get('removed') or cleanup.get('parts'):
            log(
                'APK: limpeza automática concluída na reabertura '
                '(apk=%d, parciais=%d).' % (
                    int(cleanup.get('removed') or 0),
                    int(cleanup.get('parts') or 0),
                ),
                'info',
            )
    except Exception as exc:
        log('APK: limpeza automática na reabertura falhou: %s' % exc, 'warning')

    # The root plugin:// handle is only a launcher. Finish its empty directory
    # successfully before IBOShell owns the UI. Real Kodi 21.3 proved that
    # succeeded=False creates a false XFILE/CGUIMediaWindow error. No Back or
    # hard-coded destination is emitted, and True remains the lifecycle marker
    # for the already-homologated explicit Home/Matrix exit path.
    root_detached = _detach_plugin_root(handle)
    shell = open_shell()
    mark_ui(True, 'root')
    try:
        # ÚNICA condição que pode liberar Login/Teste Automático: o painel
        # confirmou que este Device ID não possui vínculo. Erro técnico, timeout,
        # credencial Xtream inválida ou failover esgotado NÃO transformam um ID
        # já cadastrado em "novo dispositivo".
        confirmed_no_access = None
        session = load_session()
        if session:
            # Device ID/painel são a identidade/autorização. A cada abertura o
            # vínculo atual é confirmado fora do cooldown visual; as credenciais
            # retornadas pelo painel existem somente em RAM e Xtream só é
            # revalidado quando a revisão autoritativa do acesso muda.
            identity = validate_session_identity_for_open() or {}
            if identity.get('blocked'):
                show_message('ACESSO IBO', identity.get('error') or 'Acesso bloqueado. Uso não autorizado.')
                return
            if identity.get('ok'):
                # Theme/revogação visual continuam no worker/cooldown histórico.
                _sync_panel_background()
            elif identity.get('reason') == 'no_access':
                # O vínculo anterior foi removido do painel. O próprio Device ID
                # confirmou que agora está sem acesso; somente neste caso o Login
                # pode reaparecer (ou Teste Automático, se habilitado).
                confirmed_no_access = identity
            else:
                show_message('ACESSO IBO', identity.get('error') or 'Não foi possível confirmar o acesso deste dispositivo no painel.')
                return
        else:
            # Antes de pedir usuário/senha, o ID do dispositivo consulta somente
            # o index.php leve. Se o painel ainda possui um vínculo (inclusive
            # após bloquear -> desbloquear), restaura-o pelo fluxo oficial sem
            # Teste Automático.
            recovered = run_progress('Verificando acesso do dispositivo...', recover_registered_access) or {}
            if recovered.get('blocked'):
                show_message('ACESSO IBO', recovered.get('error') or 'Acesso bloqueado. Uso não autorizado.')
                return
            if recovered.get('activation_pending'):
                show_message('ACESSO IBO', recovered.get('error') or 'Acesso criado com sucesso. Aguarde alguns instantes para a ativação.')
                return
            if recovered.get('ok'):
                _sync_panel_background()
            elif recovered.get('reason') == 'no_access':
                confirmed_no_access = recovered
            elif recovered.get('reason') == 'index_error':
                # Login manual só existe para Device ID comprovadamente sem vínculo.
                # Se o painel não respondeu, pedir usuário/senha não ajuda e quebra
                # o contrato de o ID ser a fonte de verdade do acesso.
                show_message('ACESSO IBO', recovered.get('error') or 'Não foi possível consultar o painel agora. Tente abrir o ONEPLAY novamente.')
                return
            else:
                # O index encontrou um vínculo, porém a restauração falhou por
                # outro motivo (Xtream/DNS/failover/contexto). Não peça as mesmas
                # credenciais que já estão no painel; preserve o ID como autoridade.
                show_message('ACESSO IBO', recovered.get('error') or 'O acesso deste dispositivo está cadastrado, mas não pôde ser iniciado agora.')
                return

        if confirmed_no_access is not None:
            # Device ID comprovadamente sem vínculo: Teste Automático pode criar
            # um acesso; se não criar, somente então o login manual é permitido.
            state = confirmed_no_access.get('state') if isinstance(confirmed_no_access.get('state'), dict) else None
            if automatic_test_ready(state):
                auto = run_progress('Verificando Teste Automático e ativação...', lambda: automatic_test(state)) or {}
                if auto.get('ok'):
                    _sync_panel_background()
                else:
                    panel_state = auto.get('panel') if isinstance(auto.get('panel'), dict) else {}
                    denied = str(panel_state.get('access_denied') or '').strip()
                    if auto.get('reason') == 'denied' or panel_state.get('device_blocked') or denied:
                        show_message('ACESSO IBO', auto.get('error') or denied or 'Acesso bloqueado. Uso não autorizado.')
                        return
                    if auto.get('activation_pending'):
                        show_message('ACESSO IBO', auto.get('error') or 'Acesso criado com sucesso. Aguarde alguns instantes para a ativação.')
                        return
                    if auto.get('test_registry_blocked'):
                        log('Teste Automático não repetido por contrato do tests.php: %s' % (auto.get('error') or auto.get('auto_test_status') or 'registro existente'), 'debug')
                    else:
                        log('Teste Automático da abertura não concluiu; seguindo para login manual: %s' % (auto.get('error') or 'erro não informado'), 'warning')
            else:
                log('Teste Automático: desativado ou não configurado; login manual aberto após no_access confirmado pelo Device ID.', 'debug')
        while True:
            if not load_session():
                if not _login_loop():
                    break
            should_login = _home_loop()
            if not should_login:
                break
            if load_session():
                continue
    except Exception as exc:
        log('Falha no roteador V2: %s' % exc, 'error')
        try:
            show_message('IBO', 'Não foi possível concluir esta operação.\nTente novamente.')
        except Exception:
            pass
    finally:
        # Diferencie SAIR voluntário do encerramento global do Kodi. No shutdown
        # do aplicativo não existe histórico para restaurar e criar ExitPending
        # só deixa um token residual para a próxima abertura.
        aborting = False
        try:
            aborting = bool(xbmc is not None and xbmc.Monitor().abortRequested())
        except Exception:
            aborting = False
        # HÍBRIDO 2.2.8: preserve the exact 2.1.13 opening/history model, but
        # adopt the non-conflicting 2.2.1 shutdown ordering.  All interpreter-
        # owned image work is drained while IBOShell still covers Kodi; only
        # after cleanup do we expose the underlying history.
        # External cast belongs to the same ONEPLAY usage session. Stop it
        # before Heartbeat/usage is ended so a receiver can never keep using
        # provider credentials after SAIR released the panel session.
        try:
            if cast_active():
                stop_active_cast(notify_device=not aborting)
        except Exception as exc:
            log('Universal Cast: limpeza na saída falhou: %s' % exc, 'debug')
        try:
            mark_ui(False, 'shutdown' if aborting else 'exit')
        except Exception:
            pass

        matrix_explicit_exit = bool(
            not aborting and
            root_detached and
            _launched_from_matrix()
        )
        direct_home_exit = bool(
            not aborting and
            root_detached and
            not matrix_explicit_exit
        )

        if aborting:
            clear_exit_return()
            _clear_exit_guard()
            log('Lifecycle híbrido: shutdown global do Kodi; retorno/ExitPending não armados.', 'debug')
        elif not direct_home_exit and not matrix_explicit_exit:
            # Compatibilidade para launchers legados que ainda dependam do
            # histórico. O launcher Matrix atual usa retorno explícito abaixo.
            request_exit_return()
            _arm_exit_guard()

        # Preserve the 2.2.8/2.2.1 cleanup property: all interpreter-owned
        # artwork work finishes while IBOShell is still covering Kodi.
        shutdown_image_workers(timeout=2.25)

        if matrix_explicit_exit:
            # O Matrix atual substitui sua própria janela ao abrir o IBO; ele
            # portanto não fica no histórico visual. Reconstrua-o explicitamente
            # no SAIR, sem tocar em player, telas internas ou abertura direta.
            if _replace_matrix_shell_with_matrix():
                clear_exit_return()
                _clear_exit_guard()
            else:
                # Fallback conservador para instalações com Matrix antigo ou
                # skins que rejeitem ReplaceWindow(Videos,...).
                request_exit_return()
                _arm_exit_guard()
                close_shell(shell)
                _settle_detached_exit_immediately()
        elif direct_home_exit:
            # 2.2.9 EXIT-ONLY refinement.  Do not close Shell first: replacing
            # it with Home lets Kodi remove the Shell entry and truncate the
            # existing history back to Home, so the empty MyVideoNav frame is
            # never rendered.  Opening code above remains byte/AST-equivalent
            # to 2.2.8.
            direct_result = _replace_direct_shell_with_home()
            if direct_result in ('home', 'caller'):
                clear_exit_return()
                _clear_exit_guard()
            else:
                # Conservative rollback to the exact 2.2.8 exit mechanics if
                # this Kodi/skin does not accept ReplaceWindow(Home).
                request_exit_return()
                _arm_exit_guard()
                if direct_result == 'shell':
                    close_shell(shell)
                _settle_detached_exit_immediately()
        else:
            close_shell(shell)
            # 2.1.13/2.2.8 property: detached-root sessions immediately settle
            # only a proven empty MyVideoNav after Shell closes.
            if not aborting and root_detached:
                _settle_detached_exit_immediately()


def run_session_from_bootstrap(handle, root_detached, shell):
    """Continue a deliberate launch after bootstrap already showed IBOShell.

    This is the same application/session body used by run_plugin(); only the
    cold-start ordering changed. All auth, Device ID, Home and exit contracts
    below remain owned by this same plugin interpreter.
    """
    # Só uma abertura deliberada do ONEPLAY consome o marcador. A reentrada
    # transitória automática usada pelo SAIR retorna acima e não passa aqui.
    try:
        cleanup = cleanup_downloaded_apks() or {}
        if cleanup.get('removed') or cleanup.get('parts'):
            log(
                'APK: limpeza automática concluída na reabertura '
                '(apk=%d, parciais=%d).' % (
                    int(cleanup.get('removed') or 0),
                    int(cleanup.get('parts') or 0),
                ),
                'info',
            )
    except Exception as exc:
        log('APK: limpeza automática na reabertura falhou: %s' % exc, 'warning')

    mark_ui(True, 'root')
    try:
        # ÚNICA condição que pode liberar Login/Teste Automático: o painel
        # confirmou que este Device ID não possui vínculo. Erro técnico, timeout,
        # credencial Xtream inválida ou failover esgotado NÃO transformam um ID
        # já cadastrado em "novo dispositivo".
        confirmed_no_access = None
        session = load_session()
        if session:
            # Device ID/painel são a identidade/autorização. A cada abertura o
            # vínculo atual é confirmado fora do cooldown visual; as credenciais
            # retornadas pelo painel existem somente em RAM e Xtream só é
            # revalidado quando a revisão autoritativa do acesso muda.
            identity = validate_session_identity_for_open() or {}
            if identity.get('blocked'):
                show_message('ACESSO IBO', identity.get('error') or 'Acesso bloqueado. Uso não autorizado.')
                return
            if identity.get('ok'):
                # Theme/revogação visual continuam no worker/cooldown histórico.
                _sync_panel_background()
            elif identity.get('reason') == 'no_access':
                # O vínculo anterior foi removido do painel. O próprio Device ID
                # confirmou que agora está sem acesso; somente neste caso o Login
                # pode reaparecer (ou Teste Automático, se habilitado).
                confirmed_no_access = identity
            else:
                show_message('ACESSO IBO', identity.get('error') or 'Não foi possível confirmar o acesso deste dispositivo no painel.')
                return
        else:
            # Antes de pedir usuário/senha, o ID do dispositivo consulta somente
            # o index.php leve. Se o painel ainda possui um vínculo (inclusive
            # após bloquear -> desbloquear), restaura-o pelo fluxo oficial sem
            # Teste Automático.
            recovered = run_progress('Verificando acesso do dispositivo...', recover_registered_access) or {}
            if recovered.get('blocked'):
                show_message('ACESSO IBO', recovered.get('error') or 'Acesso bloqueado. Uso não autorizado.')
                return
            if recovered.get('activation_pending'):
                show_message('ACESSO IBO', recovered.get('error') or 'Acesso criado com sucesso. Aguarde alguns instantes para a ativação.')
                return
            if recovered.get('ok'):
                _sync_panel_background()
            elif recovered.get('reason') == 'no_access':
                confirmed_no_access = recovered
            elif recovered.get('reason') == 'index_error':
                # Login manual só existe para Device ID comprovadamente sem vínculo.
                # Se o painel não respondeu, pedir usuário/senha não ajuda e quebra
                # o contrato de o ID ser a fonte de verdade do acesso.
                show_message('ACESSO IBO', recovered.get('error') or 'Não foi possível consultar o painel agora. Tente abrir o ONEPLAY novamente.')
                return
            else:
                # O index encontrou um vínculo, porém a restauração falhou por
                # outro motivo (Xtream/DNS/failover/contexto). Não peça as mesmas
                # credenciais que já estão no painel; preserve o ID como autoridade.
                show_message('ACESSO IBO', recovered.get('error') or 'O acesso deste dispositivo está cadastrado, mas não pôde ser iniciado agora.')
                return

        if confirmed_no_access is not None:
            # Device ID comprovadamente sem vínculo: Teste Automático pode criar
            # um acesso; se não criar, somente então o login manual é permitido.
            state = confirmed_no_access.get('state') if isinstance(confirmed_no_access.get('state'), dict) else None
            if automatic_test_ready(state):
                auto = run_progress('Verificando Teste Automático e ativação...', lambda: automatic_test(state)) or {}
                if auto.get('ok'):
                    _sync_panel_background()
                else:
                    panel_state = auto.get('panel') if isinstance(auto.get('panel'), dict) else {}
                    denied = str(panel_state.get('access_denied') or '').strip()
                    if auto.get('reason') == 'denied' or panel_state.get('device_blocked') or denied:
                        show_message('ACESSO IBO', auto.get('error') or denied or 'Acesso bloqueado. Uso não autorizado.')
                        return
                    if auto.get('activation_pending'):
                        show_message('ACESSO IBO', auto.get('error') or 'Acesso criado com sucesso. Aguarde alguns instantes para a ativação.')
                        return
                    if auto.get('test_registry_blocked'):
                        log('Teste Automático não repetido por contrato do tests.php: %s' % (auto.get('error') or auto.get('auto_test_status') or 'registro existente'), 'debug')
                    else:
                        log('Teste Automático da abertura não concluiu; seguindo para login manual: %s' % (auto.get('error') or 'erro não informado'), 'warning')
            else:
                log('Teste Automático: desativado ou não configurado; login manual aberto após no_access confirmado pelo Device ID.', 'debug')
        while True:
            if not load_session():
                if not _login_loop():
                    break
            should_login = _home_loop()
            if not should_login:
                break
            if load_session():
                continue
    except Exception as exc:
        log('Falha no roteador V2: %s' % exc, 'error')
        try:
            show_message('IBO', 'Não foi possível concluir esta operação.\nTente novamente.')
        except Exception:
            pass
    finally:
        # Diferencie SAIR voluntário do encerramento global do Kodi. No shutdown
        # do aplicativo não existe histórico para restaurar e criar ExitPending
        # só deixa um token residual para a próxima abertura.
        aborting = False
        try:
            aborting = bool(xbmc is not None and xbmc.Monitor().abortRequested())
        except Exception:
            aborting = False
        # HÍBRIDO 2.2.8: preserve the exact 2.1.13 opening/history model, but
        # adopt the non-conflicting 2.2.1 shutdown ordering.  All interpreter-
        # owned image work is drained while IBOShell still covers Kodi; only
        # after cleanup do we expose the underlying history.
        # External cast belongs to the same ONEPLAY usage session. Stop it
        # before Heartbeat/usage is ended so a receiver can never keep using
        # provider credentials after SAIR released the panel session.
        try:
            if cast_active():
                stop_active_cast(notify_device=not aborting)
        except Exception as exc:
            log('Universal Cast: limpeza na saída falhou: %s' % exc, 'debug')
        try:
            mark_ui(False, 'shutdown' if aborting else 'exit')
        except Exception:
            pass

        matrix_explicit_exit = bool(
            not aborting and
            root_detached and
            _launched_from_matrix()
        )
        direct_home_exit = bool(
            not aborting and
            root_detached and
            not matrix_explicit_exit
        )

        if aborting:
            clear_exit_return()
            _clear_exit_guard()
            log('Lifecycle híbrido: shutdown global do Kodi; retorno/ExitPending não armados.', 'debug')
        elif not direct_home_exit and not matrix_explicit_exit:
            # Compatibilidade para launchers legados que ainda dependam do
            # histórico. O launcher Matrix atual usa retorno explícito abaixo.
            request_exit_return()
            _arm_exit_guard()

        # Preserve the 2.2.8/2.2.1 cleanup property: all interpreter-owned
        # artwork work finishes while IBOShell is still covering Kodi.
        shutdown_image_workers(timeout=2.25)

        if matrix_explicit_exit:
            # O Matrix atual substitui sua própria janela ao abrir o IBO; ele
            # portanto não fica no histórico visual. Reconstrua-o explicitamente
            # no SAIR, sem tocar em player, telas internas ou abertura direta.
            if _replace_matrix_shell_with_matrix():
                clear_exit_return()
                _clear_exit_guard()
            else:
                # Fallback conservador para instalações com Matrix antigo ou
                # skins que rejeitem ReplaceWindow(Videos,...).
                request_exit_return()
                _arm_exit_guard()
                close_shell(shell)
                _settle_detached_exit_immediately()
        elif direct_home_exit:
            # 2.2.9 EXIT-ONLY refinement.  Do not close Shell first: replacing
            # it with Home lets Kodi remove the Shell entry and truncate the
            # existing history back to Home, so the empty MyVideoNav frame is
            # never rendered.  Opening code above remains byte/AST-equivalent
            # to 2.2.8.
            direct_result = _replace_direct_shell_with_home()
            if direct_result in ('home', 'caller'):
                clear_exit_return()
                _clear_exit_guard()
            else:
                # Conservative rollback to the exact 2.2.8 exit mechanics if
                # this Kodi/skin does not accept ReplaceWindow(Home).
                request_exit_return()
                _arm_exit_guard()
                if direct_result == 'shell':
                    close_shell(shell)
                _settle_detached_exit_immediately()
        else:
            close_shell(shell)
            # 2.1.13/2.2.8 property: detached-root sessions immediately settle
            # only a proven empty MyVideoNav after Shell closes.
            if not aborting and root_detached:
                _settle_detached_exit_immediately()
