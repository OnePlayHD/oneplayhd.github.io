# -*- coding: utf-8 -*-
"""Bounded, credential-safe-in-logs media signature probe for LG DLNA VOD.

V19 keeps the V18 probe advisory/fail-open contract but upgrades MP4 handling
from fixed head/tail string sampling to bounded structural box navigation.
Large ``mdat`` payloads are never downloaded just to find metadata: the probe
reads box headers, calculates the next offset and jumps directly to ``moov``.
No URL is returned or logged and playback behavior is never blocked.
"""

import re
import socket
import time
import urllib.error
import urllib.request

from .constants import XTREAM_USER_AGENT


# Preserve the proven V18 initial sampling envelope for non-MP4 formats while
# allowing a small bounded amount of *metadata-only* targeted MP4 reads.
_HEAD_BYTES = 192 * 1024
_TAIL_BYTES = 192 * 1024
_MAX_TARGETED_META = 384 * 1024
_MAX_TOTAL_SAMPLE = _HEAD_BYTES + _MAX_TARGETED_META + _TAIL_BYTES
_RANGE_BLOCK = 8 * 1024
_MAX_RANGE_REQUESTS = 24
_MAX_BOXES_PER_LEVEL = 64
_ALLOWED_DECLARED = ('mp4', 'm4v', 'mov', 'mkv', 'ts')


class _RangeUnavailable(Exception):
    pass


def _clean_ext(value):
    text = str(value or '').strip().lower().lstrip('.')
    if text == 'm4v' or text == 'mov':
        return 'mp4'
    return text if text in _ALLOWED_DECLARED else text[:12]


def _container_mime(container):
    return {
        'mp4': 'video/mp4',
        'mkv': 'video/x-matroska',
        'ts': 'video/mp2t',
    }.get(str(container or ''), '')


def _parse_content_range(headers):
    value = str((headers or {}).get('Content-Range') or '').strip()
    match = re.match(r'^bytes\s+(\d+)-(\d+)/(\d+|\*)$', value, re.I)
    if not match:
        return None
    try:
        start = int(match.group(1))
        end = int(match.group(2))
        total = 0 if match.group(3) == '*' else int(match.group(3))
        if start < 0 or end < start or (total and end >= total):
            return None
        return start, end, total
    except Exception:
        return None


def _parse_total(headers):
    parsed = _parse_content_range(headers)
    if parsed and parsed[2] > 0:
        return int(parsed[2])
    value = str((headers or {}).get('Content-Length') or '').strip()
    if value.isdigit():
        try:
            return int(value)
        except Exception:
            pass
    return 0


def _read_range(url, start, end, timeout):
    start = max(0, int(start))
    end = max(start, int(end))
    headers = {
        'User-Agent': XTREAM_USER_AGENT,
        'Accept': '*/*',
        'Accept-Encoding': 'identity',
        'Connection': 'close',
        'Range': 'bytes=%d-%d' % (start, end),
    }
    req = urllib.request.Request(str(url), headers=headers, method='GET')
    with urllib.request.urlopen(req, timeout=max(0.6, float(timeout))) as response:
        status = int(getattr(response, 'status', response.getcode()) or 0)
        raw = response.read(max(1, end - start + 1)) or b''
        response_headers = dict(response.headers.items())
        cr = _parse_content_range(response_headers)
        exact_range = bool(
            status == 206 and cr and int(cr[0]) == start and int(cr[1]) >= start + max(0, len(raw) - 1)
        )
        return {
            'raw': raw,
            'status': status,
            'headers': response_headers,
            'content_type': str(response.headers.get('Content-Type') or ''),
            'content_range': cr,
            'exact_range': exact_range,
            'total': _parse_total(response_headers),
        }


class _TargetReader(object):
    """Small exact-Range reader with cache, deadline and byte/request caps."""

    def __init__(self, url, total, timeout, initial=b'', initial_exact_range=False):
        self.url = str(url or '')
        self.total = max(0, int(total or 0))
        self.deadline = time.monotonic() + max(0.8, float(timeout or 0.8))
        self.requests = 0
        self.network_bytes = 0
        self.range_validated = bool(initial_exact_range)
        self.cache = []
        if initial:
            self.cache.append((0, len(initial), bytes(initial)))

    def _remaining(self):
        return max(0.05, self.deadline - time.monotonic())

    def _from_cache(self, start, length):
        end = int(start) + int(length)
        for cstart, cend, raw in self.cache:
            if int(start) >= cstart and end <= cend:
                off = int(start) - cstart
                return raw[off:off + int(length)]
        return None

    def read(self, start, length):
        start = max(0, int(start))
        length = max(1, int(length))
        if self.total and start >= self.total:
            return b''
        if self.total:
            length = min(length, self.total - start)
        cached = self._from_cache(start, length)
        if cached is not None:
            return cached
        if self.requests >= _MAX_RANGE_REQUESTS:
            raise _RangeUnavailable('request-cap')
        if self.network_bytes >= _MAX_TARGETED_META:
            raise _RangeUnavailable('byte-cap')
        remaining_budget = _MAX_TARGETED_META - self.network_bytes
        fetch_len = min(max(length, _RANGE_BLOCK), remaining_budget)
        if self.total:
            fetch_len = min(fetch_len, self.total - start)
        if fetch_len <= 0:
            raise _RangeUnavailable('byte-cap')
        result = _read_range(self.url, start, start + fetch_len - 1, self._remaining())
        self.requests += 1
        raw = bytes(result.get('raw') or b'')
        self.network_bytes += len(raw)
        if start > 0 and not result.get('exact_range'):
            raise _RangeUnavailable('range-not-exact')
        if result.get('exact_range'):
            self.range_validated = True
        if result.get('total') and not self.total:
            self.total = int(result.get('total') or 0)
        self.cache.append((start, start + len(raw), raw))
        return raw[:length]


# ---------------------------------------------------------------------------
# Generic/container helpers retained from V18
# ---------------------------------------------------------------------------

def _looks_ts(data):
    raw = bytes(data or b'')
    for stride in (188, 192, 204):
        for offset in range(min(stride, 16)):
            hits = 0
            checked = 0
            pos = offset
            while pos < len(raw) and checked < 4:
                checked += 1
                if raw[pos] == 0x47:
                    hits += 1
                pos += stride
            if checked >= 3 and hits == checked:
                return True
    return False


def _detect_container(head):
    raw = bytes(head or b'')
    if len(raw) >= 4 and raw[:4] == b'\x1a\x45\xdf\xa3':
        return 'mkv', 'high'
    if len(raw) >= 12 and raw[4:8] == b'ftyp':
        return 'mp4', 'high'
    if b'ftyp' in raw[:64]:
        return 'mp4', 'high'
    if _looks_ts(raw[:204 * 4]):
        return 'ts', 'high'
    return '', 'none'


def _first_tag(blob, tags):
    raw = bytes(blob or b'')
    for tag, label in tags:
        if tag in raw:
            return label
    return ''


def _mp4_brand(head):
    raw = bytes(head or b'')
    if len(raw) >= 12 and raw[4:8] == b'ftyp':
        try:
            value = raw[8:12].decode('ascii', 'ignore').strip('\x00 ')
            return value[:8]
        except Exception:
            return ''
    return ''


def _avcc_details(blob):
    raw = bytes(blob or b'')
    pos = raw.find(b'avcC')
    if pos < 0 or pos + 8 > len(raw):
        return '', ''
    try:
        profile_idc = int(raw[pos + 5])
        level_idc = int(raw[pos + 7])
    except Exception:
        return '', ''
    profiles = {
        66: 'baseline', 77: 'main', 88: 'extended', 100: 'high', 110: 'high10',
        122: 'high422', 244: 'high444',
    }
    profile = profiles.get(profile_idc, str(profile_idc))
    level = '%.1f' % (float(level_idc) / 10.0) if level_idc else ''
    return profile, level


def _hvcc_details(blob):
    raw = bytes(blob or b'')
    pos = raw.find(b'hvcC')
    if pos < 0 or pos + 17 > len(raw):
        return '', ''
    try:
        profile_idc = int(raw[pos + 5]) & 0x1f
        level_idc = int(raw[pos + 16])
    except Exception:
        return '', ''
    profiles = {1: 'main', 2: 'main10', 3: 'main-still'}
    profile = profiles.get(profile_idc, str(profile_idc))
    level = '%.1f' % (float(level_idc) / 30.0) if level_idc else ''
    return profile, level


def _detect_codecs(container, head, tail):
    blob = bytes(head or b'') + bytes(tail or b'')
    video = ''
    audio = ''
    profile = ''
    level = ''
    if container == 'mp4':
        video = _first_tag(blob, (
            (b'avc1', 'h264'), (b'avc3', 'h264'),
            (b'hvc1', 'hevc'), (b'hev1', 'hevc'),
            (b'av01', 'av1'), (b'vp09', 'vp9'), (b'mp4v', 'mpeg4'),
        ))
        audio = _first_tag(blob, (
            (b'ec-3', 'eac3'), (b'ac-3', 'ac3'),
            (b'dtsc', 'dts'), (b'dtsh', 'dts-hd'), (b'dtsl', 'dts-hd'),
            (b'Opus', 'opus'), (b'mp4a', 'aac'),
        ))
        if video == 'h264':
            profile, level = _avcc_details(blob)
        elif video == 'hevc':
            profile, level = _hvcc_details(blob)
    elif container == 'mkv':
        upper = blob.upper()
        video = _first_tag(upper, (
            (b'V_MPEG4/ISO/AVC', 'h264'), (b'V_MPEGH/ISO/HEVC', 'hevc'),
            (b'V_AV1', 'av1'), (b'V_VP9', 'vp9'), (b'V_MPEG4/ISO/ASP', 'mpeg4'),
        ))
        audio = _first_tag(upper, (
            (b'A_EAC3', 'eac3'), (b'A_AC3', 'ac3'), (b'A_AAC', 'aac'),
            (b'A_DTS', 'dts'), (b'A_OPUS', 'opus'), (b'A_PCM', 'pcm'),
        ))
    return video or 'unknown', audio or 'unknown', profile, level


# ---------------------------------------------------------------------------
# V19 MP4 structural navigation
# ---------------------------------------------------------------------------

def _box_header(reader, offset, parent_end=0):
    raw = reader.read(offset, 16)
    if len(raw) < 8:
        return None
    size32 = int.from_bytes(raw[0:4], 'big')
    btype = raw[4:8]
    header = 8
    if size32 == 1:
        if len(raw) < 16:
            return None
        size = int.from_bytes(raw[8:16], 'big')
        header = 16
    elif size32 == 0:
        limit = int(parent_end or reader.total or 0)
        if limit <= int(offset):
            return None
        size = limit - int(offset)
    else:
        size = size32
    if size < header:
        return None
    end = int(offset) + int(size)
    limit = int(parent_end or reader.total or 0)
    if limit and end > limit:
        return None
    return {
        'type': btype,
        'offset': int(offset),
        'size': int(size),
        'header': int(header),
        'payload': int(offset) + int(header),
        'end': end,
    }


def _iter_children(reader, start, end, max_boxes=_MAX_BOXES_PER_LEVEL):
    pos = int(start)
    end = int(end)
    seen = 0
    while pos + 8 <= end and seen < int(max_boxes):
        box = _box_header(reader, pos, parent_end=end)
        if not box:
            break
        yield box
        seen += 1
        next_pos = int(box['end'])
        if next_pos <= pos:
            break
        pos = next_pos


def _find_child(reader, parent, target):
    if not parent:
        return None
    for box in _iter_children(reader, parent['payload'], parent['end']):
        if box.get('type') == target:
            return box
    return None


def _scan_top_level(reader):
    boxes = []
    end = int(reader.total or 0)
    if end <= 0:
        return boxes
    pos = 0
    seen = 0
    have_moov = False
    have_mdat = False
    while pos + 8 <= end and seen < _MAX_BOXES_PER_LEVEL:
        box = _box_header(reader, pos, parent_end=end)
        if not box:
            break
        boxes.append(box)
        seen += 1
        have_moov = have_moov or box.get('type') == b'moov'
        have_mdat = have_mdat or box.get('type') == b'mdat'
        pos = int(box['end'])
        # Stop as soon as both ordering anchors are known.  Large mdat boxes
        # are skipped by their declared size; their payload is never read.
        if have_moov and have_mdat:
            break
    return boxes


def _handler_type(reader, mdia):
    hdlr = _find_child(reader, mdia, b'hdlr')
    if not hdlr:
        return b''
    raw = reader.read(hdlr['payload'], min(32, hdlr['end'] - hdlr['payload']))
    # FullBox version/flags (4), pre_defined (4), handler_type (4)
    return raw[8:12] if len(raw) >= 12 else b''


def _stsd_box(reader, mdia):
    minf = _find_child(reader, mdia, b'minf')
    if not minf:
        return None
    stbl = _find_child(reader, minf, b'stbl')
    if not stbl:
        return None
    return _find_child(reader, stbl, b'stsd')


def _parse_sample_entry(reader, stsd):
    if not stsd:
        return None
    base = int(stsd['payload'])
    head = reader.read(base, min(64, stsd['end'] - base))
    if len(head) < 16:
        return None
    # stsd FullBox(4) + entry_count(4), then first sample entry size/type.
    entry_size = int.from_bytes(head[8:12], 'big')
    entry_type = head[12:16]
    if entry_size < 8 or base + 8 + entry_size > stsd['end']:
        return None
    entry_offset = base + 8
    entry_len = min(entry_size, 16 * 1024)
    raw = reader.read(entry_offset, entry_len)
    return {
        'type': entry_type,
        'offset': entry_offset,
        'size': entry_size,
        'raw': raw,
    }


def _codec_from_sample(sample, handler):
    if not sample:
        return 'unknown', '', '', 0, 0
    stype = sample.get('type') or b''
    raw = bytes(sample.get('raw') or b'')
    video_map = {
        b'avc1': 'h264', b'avc3': 'h264', b'hvc1': 'hevc', b'hev1': 'hevc',
        b'av01': 'av1', b'vp09': 'vp9', b'mp4v': 'mpeg4',
    }
    audio_map = {
        b'mp4a': 'aac', b'ac-3': 'ac3', b'ec-3': 'eac3', b'dtsc': 'dts',
        b'dtsh': 'dts-hd', b'dtsl': 'dts-hd', b'Opus': 'opus', b'lpcm': 'pcm',
    }
    codec = video_map.get(stype) or audio_map.get(stype) or 'unknown'
    profile = ''
    level = ''
    width = 0
    height = 0
    if codec == 'h264':
        profile, level = _avcc_details(raw)
    elif codec == 'hevc':
        profile, level = _hvcc_details(raw)
    if handler == b'vide' or stype in video_map:
        # Sample entry begins with size(4)+type(4). Width/height are 28/30
        # bytes after the type field, matching the ISO VisualSampleEntry.
        if len(raw) >= 36:
            try:
                width = int.from_bytes(raw[32:34], 'big')
                height = int.from_bytes(raw[34:36], 'big')
                if width < 16 or width > 16384 or height < 16 or height > 16384:
                    width = height = 0
            except Exception:
                width = height = 0
    return codec, profile, level, width, height


def _mp4_structural_signature(url, total, head, timeout, initial_exact_range=False):
    result = {
        'video': 'unknown', 'audio': 'unknown', 'profile': '', 'level': '',
        'width': 0, 'height': 0, 'layout': 'unknown', 'brand': _mp4_brand(head),
        'sampled_extra': 0, 'range_validated': bool(initial_exact_range),
        'moov_offset': 0, 'moov_size': 0, 'mdat_offset': 0, 'mdat_end': 0,
        'fragmented': False, 'faststart_safe': False,
    }
    if not total or not initial_exact_range:
        return result
    reader = _TargetReader(url, total, timeout, initial=head, initial_exact_range=initial_exact_range)
    try:
        top = _scan_top_level(reader)
        if not top:
            return result
        moov = next((b for b in top if b.get('type') == b'moov'), None)
        mdat = next((b for b in top if b.get('type') == b'mdat'), None)
        if mdat:
            result['mdat_offset'] = int(mdat.get('offset') or 0)
            result['mdat_end'] = int(mdat.get('end') or 0)
        if not moov:
            return result
        result['moov_offset'] = int(moov.get('offset') or 0)
        result['moov_size'] = int(moov.get('size') or 0)
        mvex = _find_child(reader, moov, b'mvex')
        result['fragmented'] = bool(mvex)

        if result['fragmented']:
            layout_base = 'fragmented'
        elif mdat and int(moov['offset']) < int(mdat['offset']):
            layout_base = 'faststart'
        elif mdat and int(moov['offset']) > int(mdat['offset']):
            layout_base = 'moov-tail'
        else:
            layout_base = 'moov-present'
        result['layout'] = '%s@%d+%d' % (layout_base, int(moov['offset']), int(moov['size']))

        # V21 eligibility is deliberately stricter than merely detecting
        # moov-tail.  Virtual faststart is safe only when the media payload is
        # one contiguous mdat immediately followed by a final moov, with no
        # fragmented MP4 machinery and no offset-bearing top-level indexes.
        # Before mdat, only inert/branding boxes are accepted.
        pre_mdat = [b.get('type') for b in top if int(b.get('offset') or 0) < int(mdat.get('offset') or 0)] if mdat else []
        safe_prefix = all(t in (b'ftyp', b'free', b'skip', b'wide') for t in pre_mdat)
        result['faststart_safe'] = bool(
            mdat and not result['fragmented'] and layout_base == 'moov-tail' and
            int(mdat.get('end') or 0) == int(moov.get('offset') or 0) and
            int(moov.get('end') or 0) == int(total) and safe_prefix
        )

        for trak in _iter_children(reader, moov['payload'], moov['end']):
            if trak.get('type') != b'trak':
                continue
            mdia = _find_child(reader, trak, b'mdia')
            if not mdia:
                continue
            handler = _handler_type(reader, mdia)
            stsd = _stsd_box(reader, mdia)
            sample = _parse_sample_entry(reader, stsd)
            codec, profile, level, width, height = _codec_from_sample(sample, handler)
            if handler == b'vide' or (sample and sample.get('type') in (b'avc1', b'avc3', b'hvc1', b'hev1', b'av01', b'vp09', b'mp4v')):
                if result['video'] == 'unknown':
                    result['video'] = codec
                    result['profile'] = profile
                    result['level'] = level
                    result['width'] = int(width or 0)
                    result['height'] = int(height or 0)
            elif handler == b'soun' or (sample and sample.get('type') in (b'mp4a', b'ac-3', b'ec-3', b'dtsc', b'dtsh', b'dtsl', b'Opus', b'lpcm')):
                if result['audio'] == 'unknown':
                    result['audio'] = codec
            if result['video'] != 'unknown' and result['audio'] != 'unknown':
                break
    except (_RangeUnavailable, urllib.error.HTTPError, urllib.error.URLError, socket.timeout, TimeoutError, OSError, ValueError):
        pass
    except Exception:
        pass
    result['sampled_extra'] = int(reader.network_bytes)
    result['range_validated'] = bool(reader.range_validated)
    return result


def _support_hint(container, video, audio, profile='', level='', width=0, height=0):
    """Conservative LG webOS 5.0 UHD hint; never blocks playback."""
    if container not in ('mp4', 'mkv', 'ts'):
        return 'unknown'
    if video == 'unknown':
        return 'unknown'
    if video not in ('h264', 'hevc'):
        return 'outside-core'
    if audio not in ('aac', 'ac3', 'eac3', 'unknown'):
        return 'outside-core'
    if video == 'h264' and profile in ('high10', 'high422', 'high444'):
        return 'outside-core'
    if video == 'hevc' and profile and profile not in ('main', 'main10'):
        return 'outside-core'
    if level:
        try:
            lv = float(level)
            is_uhd = int(width or 0) > 1920 or int(height or 0) > 1080
            max_level = 5.1 if is_uhd else (4.2 if video == 'h264' else 4.1)
            if lv > max_level + 0.001:
                return 'outside-core'
        except Exception:
            pass
    return 'documented'


def probe_vod_signature(url, declared_extension='', timeout=3.2):
    """Return a sanitized bounded media signature.

    For MP4, V19 follows box offsets and reads only metadata neighborhoods;
    large media payloads are skipped mathematically.  For MKV/TS the V18
    bounded head/tail strategy is preserved.  Any failure remains fail-open.
    """
    raw_url = str(url or '').split('|', 1)[0].strip()
    declared = _clean_ext(declared_extension)
    result = {
        'ok': False, 'declared': declared, 'container': '', 'confidence': 'none',
        'mime': '', 'video': 'unknown', 'audio': 'unknown', 'profile': '',
        'level': '', 'width': 0, 'height': 0, 'layout': 'unknown', 'brand': '',
        'support': 'unknown', 'sampled_bytes': 0, 'range_supported': False,
        'range_validated': False, 'total_size': 0, 'moov_offset': 0, 'moov_size': 0,
        'mdat_offset': 0, 'mdat_end': 0, 'fragmented': False, 'faststart_safe': False,
    }
    if not raw_url:
        return result

    total_timeout = max(1.6, min(4.2, float(timeout or 3.2)))
    first_timeout = max(0.8, min(1.5, total_timeout * 0.45))
    head = b''
    tail = b''
    try:
        first = _read_range(raw_url, 0, _HEAD_BYTES - 1, first_timeout)
        head = bytes(first.get('raw') or b'')
        result['sampled_bytes'] += len(head)
        result['range_supported'] = bool(first.get('status') == 206)
        result['range_validated'] = bool(first.get('exact_range'))
        total = int(first.get('total') or 0)
        # V20: preserve the exact total object size proven by Content-Range.
        # This is metadata only; no extra request is made and playback remains
        # fail-open if the origin does not prove a usable total.
        if first.get('exact_range') and total > 0:
            result['total_size'] = int(total)
    except (urllib.error.HTTPError, urllib.error.URLError, socket.timeout, TimeoutError, OSError, ValueError):
        return result
    except Exception:
        return result

    container, confidence = _detect_container(head)
    result['container'] = container
    result['confidence'] = confidence
    result['mime'] = _container_mime(container)
    if not container:
        return result

    if container == 'mp4':
        structural = _mp4_structural_signature(
            raw_url, total, head, max(0.8, total_timeout - first_timeout),
            initial_exact_range=bool(first.get('exact_range')),
        )
        result['sampled_bytes'] += int(structural.get('sampled_extra') or 0)
        result['range_validated'] = bool(structural.get('range_validated') or result['range_validated'])
        result['video'] = str(structural.get('video') or 'unknown')
        result['audio'] = str(structural.get('audio') or 'unknown')
        result['profile'] = str(structural.get('profile') or '')
        result['level'] = str(structural.get('level') or '')
        result['width'] = int(structural.get('width') or 0)
        result['height'] = int(structural.get('height') or 0)
        result['layout'] = str(structural.get('layout') or 'unknown')
        result['brand'] = str(structural.get('brand') or _mp4_brand(head))
        result['moov_offset'] = int(structural.get('moov_offset') or 0)
        result['moov_size'] = int(structural.get('moov_size') or 0)
        result['mdat_offset'] = int(structural.get('mdat_offset') or 0)
        result['mdat_end'] = int(structural.get('mdat_end') or 0)
        result['fragmented'] = bool(structural.get('fragmented'))
        result['faststart_safe'] = bool(structural.get('faststart_safe'))

        # Fail-open diagnostic fallback when structural navigation is not
        # possible (e.g. server ignores Range). Preserve V18 string sampling.
        if result['video'] == 'unknown' and result['audio'] == 'unknown' and total > _HEAD_BYTES:
            try:
                start = max(_HEAD_BYTES, total - _TAIL_BYTES)
                last = _read_range(raw_url, start, total - 1, max(0.7, total_timeout - first_timeout))
                if last.get('exact_range'):
                    tail = bytes(last.get('raw') or b'')
                    result['sampled_bytes'] += len(tail)
                    video, audio, profile, level = _detect_codecs('mp4', head, tail)
                    if video != 'unknown':
                        result['video'] = video
                        result['profile'] = profile
                        result['level'] = level
                    if audio != 'unknown':
                        result['audio'] = audio
            except Exception:
                pass
    else:
        # Preserve V18 behavior for non-MP4 containers.
        if result['range_validated'] and total > _HEAD_BYTES:
            try:
                start = max(_HEAD_BYTES, total - _TAIL_BYTES)
                last = _read_range(raw_url, start, total - 1, max(0.7, total_timeout - first_timeout))
                if last.get('status') in (200, 206):
                    tail = bytes(last.get('raw') or b'')
                    result['sampled_bytes'] += len(tail)
            except Exception:
                tail = b''
        video, audio, profile, level = _detect_codecs(container, head, tail)
        result['video'] = video
        result['audio'] = audio
        result['profile'] = profile
        result['level'] = level

    if result['sampled_bytes'] > _MAX_TOTAL_SAMPLE:
        result['sampled_bytes'] = _MAX_TOTAL_SAMPLE
    result['support'] = _support_hint(
        container, result['video'], result['audio'], result['profile'], result['level'],
        result.get('width') or 0, result.get('height') or 0,
    )
    result['ok'] = True
    return result
