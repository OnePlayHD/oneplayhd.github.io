# -*- coding: utf-8 -*-
import json
import socket
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

from .constants import MAX_RESPONSE_BYTES, USER_AGENT

from .prefs import get_int


def http_status_message(status, retry_after=0, access=False):
    try:
        code = int(status)
    except Exception:
        return 'Falha HTTP.'
    labels = {
        400: 'requisição inválida',
        401: 'não autorizado — login ou credencial inválida',
        402: 'acesso requer pagamento/renovação',
        403: 'acesso negado ou bloqueado',
        404: ('acesso não encontrado — pode indicar login vencido/removido' if access else 'rota ou recurso não encontrado'),
        408: 'servidor sem resposta dentro do prazo',
        409: 'conflito de acesso',
        410: 'acesso/recurso não está mais disponível',
        423: 'acesso bloqueado',
        429: 'limite temporário de tentativas atingido',
        500: 'erro interno do servidor',
        502: 'servidor intermediário não conseguiu alcançar a origem',
        503: 'serviço temporariamente indisponível',
        504: 'servidor intermediário ficou sem resposta',
    }
    text = 'HTTP %d — %s' % (code, labels.get(code, 'erro retornado pelo servidor'))
    if code == 429 and retry_after:
        text += ' (tente novamente em %ss)' % int(retry_after)
    return text


def _looks_like_access_url(url):
    try:
        parsed = urllib.parse.urlparse(str(url or ''))
        path = (parsed.path or '').lower()
        return (path.endswith('/player_api.php') or path.endswith('/get.php') or
                '/live/' in path or '/movie/' in path or '/series/' in path)
    except Exception:
        return False


def transport_error_message(exc):
    reason = getattr(exc, 'reason', exc)
    text = str(reason or '')
    lowered = text.lower()
    cls = reason.__class__.__name__.lower() if reason is not None else ''
    if isinstance(reason, socket.gaierror) or 'gaierror' in cls or any(token in lowered for token in (
            'name or service not known', 'nodename nor servname', 'temporary failure in name resolution',
            'getaddrinfo failed', 'no address associated with hostname')):
        return 'DNS não resolveu o endereço — possível bloqueio DNS ou domínio indisponível.'
    if isinstance(reason, (socket.timeout, TimeoutError)) or 'timed out' in lowered or 'timeout' in cls:
        return 'Servidor sem resposta — tempo de conexão esgotado.'
    if isinstance(reason, ConnectionRefusedError) or 'connection refused' in lowered or 'actively refused' in lowered:
        return 'Servidor recusou a conexão.'
    if isinstance(reason, (ConnectionResetError, ConnectionAbortedError, BrokenPipeError)) or any(token in lowered for token in (
            'connection reset', 'connection aborted', 'broken pipe', 'remote end closed')):
        return 'Conexão interrompida pelo servidor.'
    if isinstance(reason, ssl.SSLError) or 'ssl' in cls or 'certificate' in lowered or 'tls' in lowered:
        return 'Falha SSL/TLS — conexão segura não pôde ser validada.'
    if not text:
        return 'Servidor sem resposta.'
    return 'Falha de comunicação — %s.' % reason.__class__.__name__


class HttpError(Exception):
    def __init__(self, message, status=None, transport=False, body=b'', url='', phase='', elapsed_ms=0, retry_after=0):
        Exception.__init__(self, message)
        self.status = status
        self.transport = bool(transport)
        self.body = body or b''
        self.url = url
        self.phase = str(phase or ('transport' if transport else 'http' if status else 'unknown'))
        try:
            self.elapsed_ms = max(0, int(elapsed_ms or 0))
        except Exception:
            self.elapsed_ms = 0
        try:
            self.retry_after = max(0, int(float(retry_after or 0)))
        except Exception:
            self.retry_after = 0


def timeout_setting(default=8):
    return get_int('request_timeout', default=default, low=5, high=30)


def request(url, method='GET', data=None, headers=None, timeout=None, max_bytes=MAX_RESPONSE_BYTES):
    hdr = dict(headers or {})
    hdr.setdefault('User-Agent', USER_AGENT)
    hdr.setdefault('Accept', '*/*')
    if isinstance(data, str):
        data = data.encode('utf-8')
    req = urllib.request.Request(url, data=data, headers=hdr, method=method.upper())
    started = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=timeout or timeout_setting()) as response:
            status = int(getattr(response, 'status', response.getcode()))
            raw = response.read(max_bytes + 1)
            elapsed_ms = int(max(0.0, time.monotonic() - started) * 1000.0)
            if len(raw) > max_bytes:
                raise HttpError('Resposta excedeu o limite.', status=status, url=url, phase='read', elapsed_ms=elapsed_ms)
            return status, dict(response.headers.items()), raw
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read(min(max_bytes, 65536))
        except Exception:
            body = b''
        elapsed_ms = int(max(0.0, time.monotonic() - started) * 1000.0)
        retry_after = 0
        try:
            retry_after = int(float((exc.headers or {}).get('Retry-After') or 0))
        except Exception:
            retry_after = 0
        message = http_status_message(int(exc.code), retry_after=retry_after, access=_looks_like_access_url(url))
        raise HttpError(message, status=int(exc.code), body=body, url=url, phase='http', elapsed_ms=elapsed_ms, retry_after=retry_after)
    except (urllib.error.URLError, socket.timeout, TimeoutError, OSError, ssl.SSLError) as exc:
        elapsed_ms = int(max(0.0, time.monotonic() - started) * 1000.0)
        raise HttpError(transport_error_message(exc), transport=True, url=url, phase='transport', elapsed_ms=elapsed_ms)

def request_json(url, method='GET', payload=None, timeout=None, headers=None):
    hdr = dict(headers or {})
    body = None
    if payload is not None:
        body = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        hdr.setdefault('Content-Type', 'application/json; charset=utf-8')
        hdr.setdefault('Accept', 'application/json')
    status, response_headers, raw = request(url, method, body, hdr, timeout)
    try:
        data = json.loads(raw.decode('utf-8-sig'))
    except Exception as exc:
        raise HttpError('JSON inválido: %s' % exc, status=status, body=raw[:1024], url=url, phase='decode')
    return status, response_headers, data


def join_url(base, path):
    base = str(base or '').strip()
    if not base.endswith('/'):
        base += '/'
    return urllib.parse.urljoin(base, str(path or '').lstrip('/'))
