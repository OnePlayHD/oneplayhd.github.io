# -*- coding: utf-8 -*-
import glob
import hashlib
import os
import platform
import uuid

from .storage import read_json, state_path, translate, write_json


def _format(value):
    raw = ''.join(ch for ch in str(value).upper() if ch in '0123456789ABCDEF')[:16]
    return ':'.join(raw[i:i+2] for i in range(0, len(raw), 2))


_PERSISTENT_DEVICE_FILE = 'special://masterprofile/ibo_oneplay/device.json'
_DEVICE_SCHEMA = 3
_ANDROID_HARDWARE_SOURCE = 'android_hardware_v1'
_WINDOWS_HARDWARE_SOURCE = 'windows_machine_v1'
_LINUX_HARDWARE_SOURCE = 'linux_machine_v1'
_UWP_HARDWARE_SOURCE = 'uwp_network_hardware_v1'
_RANDOM_SOURCE = 'random_v1'
_STABLE_SOURCES = (
    _ANDROID_HARDWARE_SOURCE,
    _WINDOWS_HARDWARE_SOURCE,
    _LINUX_HARDWARE_SOURCE,
    _UWP_HARDWARE_SOURCE,
)
_ANDROID_HARDWARE_SALT = 'ONEPLAY-IBO-KODI-ANDROID-HARDWARE-V1'
_WINDOWS_HARDWARE_SALT = 'ONEPLAY-IBO-KODI-WINDOWS-HARDWARE-V1'
_LINUX_HARDWARE_SALT = 'ONEPLAY-IBO-KODI-LINUX-HARDWARE-V1'
_UWP_HARDWARE_SALT = 'ONEPLAY-IBO-KODI-UWP-HARDWARE-V1'

_INVALID_MACS = {
    '000000000000',
    'FFFFFFFFFFFF',
    '020000000000',  # valor de privacidade comum em Androids antigos/restritos
}
# Interfaces virtuais/túneis não devem virar identidade do aparelho.
_VIRTUAL_INTERFACE_PREFIXES = (
    'lo', 'tun', 'tap', 'vpn', 'veth', 'docker', 'br-', 'bridge', 'dummy',
    'ifb', 'sit', 'ip6tnl', 'gre', 'gretap', 'erspan', 'rmnet', 'ccmni',
    'p2p', 'ap', 'swlan', 'aware', 'bond',
)


def _valid_device_id(value):
    formatted = _format(value)
    return formatted if len(formatted.replace(':', '')) >= 12 else ''


def _persistent_device_path():
    return translate(_PERSISTENT_DEVICE_FILE)


def _read_device_record(path):
    data = read_json(path, {})
    if not isinstance(data, dict):
        return '', ''
    return _valid_device_id(data.get('device_id')), str(data.get('source') or '').strip()


def _store_device_id(path, device_id, source=''):
    try:
        data = {
            'device_id': device_id,
            'schema': _DEVICE_SCHEMA,
        }
        if source:
            data['source'] = str(source)
        write_json(path, data)
        return True
    except Exception:
        return False


def _is_android():
    try:
        import xbmc
        if xbmc.getCondVisibility('System.Platform.Android'):
            return True
    except Exception:
        pass
    system = str(platform.system() or '').strip().lower()
    if system == 'android':
        return True
    return bool(os.environ.get('ANDROID_ROOT') and os.environ.get('ANDROID_DATA'))


def _kodi_condition(name):
    try:
        import xbmc
        return bool(xbmc.getCondVisibility(name))
    except Exception:
        return False


def _is_uwp():
    # Kodi para Xbox One/Series é a build Windows Store/UWP. O teste do Kodi é
    # a fonte principal porque platform.system() sozinho só informa Windows.
    return _kodi_condition('System.Platform.UWP')


def _is_windows_desktop():
    if _is_uwp():
        return False
    if _kodi_condition('System.Platform.Windows'):
        return True
    return str(platform.system() or '').strip().lower() == 'windows'


def _is_linux():
    # Android também usa kernel Linux, portanto precisa ser excluído primeiro.
    if _is_android():
        return False
    if _kodi_condition('System.Platform.Linux'):
        return True
    return str(platform.system() or '').strip().lower() == 'linux'


def _normalize_hex_identity(value, minimum=16):
    raw = ''.join(ch for ch in str(value or '').strip().upper() if ch in '0123456789ABCDEF')
    if len(raw) < int(minimum):
        return ''
    if len(set(raw)) <= 1:
        return ''
    return raw


def _normalize_mac(value):
    text = str(value or '').strip().upper().replace(':', '').replace('-', '')
    if len(text) != 12 or any(ch not in '0123456789ABCDEF' for ch in text):
        return ''
    if text in _INVALID_MACS or len(set(text)) <= 1:
        return ''
    # Bit menos significativo do primeiro octeto = multicast. Não é endereço
    # individual de interface e por isso não serve como identidade física.
    try:
        if int(text[:2], 16) & 0x01:
            return ''
    except Exception:
        return ''
    return text


def _read_text(path, max_bytes=256):
    try:
        with open(path, 'rb') as handle:
            value = handle.read(max_bytes)
        return value.decode('utf-8', 'ignore').strip()
    except Exception:
        return ''


def _sysfs_mac_candidates():
    """Retorna MACs de interfaces físicas visíveis ao processo do Kodi.

    /sys/class/net é independente do perfil do Kodi, então limpar addon_data ou
    os dados do Kodi não apaga esses valores. A lista é ordenada para que a
    escolha da fonte seja determinística entre reinicializações.
    """
    candidates = []
    for address_path in sorted(glob.glob('/sys/class/net/*/address')):
        interface = os.path.basename(os.path.dirname(address_path)).strip().lower()
        if not interface or interface.startswith(_VIRTUAL_INTERFACE_PREFIXES):
            continue
        mac = _normalize_mac(_read_text(address_path, 64))
        if not mac:
            continue
        candidates.append((interface, mac))
    return candidates


def _kodi_network_mac():
    try:
        import xbmc
        return _normalize_mac(xbmc.getInfoLabel('Network.MacAddress'))
    except Exception:
        return ''


def _uuid_node_mac():
    # uuid.getnode() prefere um MAC universal quando consegue encontrá-lo.
    # Se o Python precisar fabricar um valor aleatório, ele marca o bit de
    # multicast; _normalize_mac() rejeita esse caso e evita falsa estabilidade.
    try:
        return _normalize_mac('%012X' % int(uuid.getnode()))
    except Exception:
        return ''


def _interface_rank(interface):
    name = str(interface or '').lower()
    if name == 'eth0':
        return (0, name)
    if name.startswith(('eth', 'en')):
        return (1, name)
    if name == 'wlan0':
        return (2, name)
    if name.startswith(('wlan', 'wifi')):
        return (3, name)
    return (4, name)


def _android_hardware_identity():
    """Escolhe uma fonte estável sem depender dos dados privados do Kodi.

    Ordem conservadora:
      1) MAC físico em /sys/class/net (Ethernet antes de Wi-Fi);
      2) MAC da interface conectada exposto pelo próprio Kodi;
      3) MAC real encontrado por uuid.getnode().

    Não usamos serial genérico de TV Box porque alguns firmwares repetem o
    mesmo serial entre aparelhos, o que poderia colidir dois clientes. O valor
    bruto nunca é retornado por get_device_id() nem enviado ao painel; ele é
    imediatamente transformado em hash OnePlay.
    """
    if not _is_android():
        return ''

    candidates = _sysfs_mac_candidates()
    if candidates:
        _interface, mac = sorted(candidates, key=lambda item: _interface_rank(item[0]))[0]
        # O nome da interface não entra no hash. Assim eth0 -> en0 após uma
        # atualização de firmware não altera o DID se o MAC físico for o mesmo.
        return 'mac:%s' % mac

    mac = _kodi_network_mac()
    if mac:
        return 'mac:%s' % mac

    mac = _uuid_node_mac()
    if mac:
        return 'mac:%s' % mac

    return ''


def _windows_machine_guid():
    """Lê MachineGuid sem comando externo e sem enviar o valor bruto ao painel."""
    if not _is_windows_desktop():
        return ''
    try:
        import winreg
    except Exception:
        return ''

    views = []
    for view in (getattr(winreg, 'KEY_WOW64_64KEY', 0), 0):
        if view not in views:
            views.append(view)
    for view in views:
        try:
            access = getattr(winreg, 'KEY_READ', 0) | view
            key = winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r'SOFTWARE\Microsoft\Cryptography',
                0,
                access,
            )
            try:
                value, _kind = winreg.QueryValueEx(key, 'MachineGuid')
            finally:
                try:
                    winreg.CloseKey(key)
                except Exception:
                    pass
            token = _normalize_hex_identity(value, minimum=16)
            if token:
                return token
        except Exception:
            continue
    return ''


def _windows_hardware_identity():
    if not _is_windows_desktop():
        return ''
    machine_guid = _windows_machine_guid()
    if machine_guid:
        return 'machine-guid:%s' % machine_guid

    # Fallback apenas para instalações Windows onde o registro esteja
    # excepcionalmente indisponível ao Python do Kodi.
    mac = _kodi_network_mac() or _uuid_node_mac()
    return ('mac:%s' % mac) if mac else ''


def _linux_hardware_identity():
    if not _is_linux():
        return ''

    # machine-id pertence ao sistema operacional, não ao perfil do Kodi; por
    # isso sobrevive a remover/reinstalar o Kodi e a apagar ~/.kodi.
    for path in ('/etc/machine-id', '/var/lib/dbus/machine-id'):
        token = _normalize_hex_identity(_read_text(path, 256), minimum=16)
        if token:
            return 'machine-id:%s' % token

    # Em PCs/mini-PCs Linux, DMI fornece uma segunda fonte fora do Kodi.
    token = _normalize_hex_identity(_read_text('/sys/class/dmi/id/product_uuid', 256), minimum=16)
    if token:
        return 'dmi-uuid:%s' % token

    candidates = _sysfs_mac_candidates()
    if candidates:
        _interface, mac = sorted(candidates, key=lambda item: _interface_rank(item[0]))[0]
        return 'mac:%s' % mac

    mac = _kodi_network_mac() or _uuid_node_mac()
    return ('mac:%s' % mac) if mac else ''


def _uwp_hardware_identity():
    """Identidade persistente para Kodi Windows Store, incluindo Xbox.

    Add-ons Python rodam dentro do sandbox UWP e não possuem uma API Python
    portável para o SystemIdentification do WinRT. O Kodi, porém, expõe o MAC
    do sistema por Network.MacAddress. Esse valor está fora do armazenamento do
    Kodi e sobrevive à remoção/reinstalação do app no mesmo console.
    """
    if not _is_uwp():
        return ''
    mac = _kodi_network_mac() or _uuid_node_mac()
    return ('mac:%s' % mac) if mac else ''


def _stable_platform_spec():
    """Retorna (source, salt, probe) sem consultar hardware antecipadamente."""
    if _is_android():
        return (_ANDROID_HARDWARE_SOURCE, _ANDROID_HARDWARE_SALT, _android_hardware_identity)
    if _is_uwp():
        return (_UWP_HARDWARE_SOURCE, _UWP_HARDWARE_SALT, _uwp_hardware_identity)
    if _is_windows_desktop():
        return (_WINDOWS_HARDWARE_SOURCE, _WINDOWS_HARDWARE_SALT, _windows_hardware_identity)
    if _is_linux():
        return (_LINUX_HARDWARE_SOURCE, _LINUX_HARDWARE_SALT, _linux_hardware_identity)
    return ('', '', None)


def _derived_device_id(namespace, stable_value):
    digest = hashlib.sha256(
        ('%s|%s' % (namespace, stable_value)).encode('utf-8', 'ignore')
    ).hexdigest()[:16]
    return _format(digest)


def _persist_both(local_path, persistent_path, device_id, source):
    _store_device_id(local_path, device_id, source)
    _store_device_id(persistent_path, device_id, source)
    return device_id


def _legacy_random_device_id(local_path):
    seed = '|'.join([
        platform.node() or '',
        '%012X' % uuid.getnode(),
        str(uuid.uuid4()),
        os.path.abspath(local_path),
    ])
    return _format(hashlib.sha256(seed.encode('utf-8', 'ignore')).hexdigest()[:16])


def get_device_id():
    local_path = state_path('device.json')
    persistent_path = _persistent_device_path()

    local, local_source = _read_device_record(local_path)
    persistent, persistent_source = _read_device_record(persistent_path)

    target_source, namespace, identity_probe = _stable_platform_spec()
    if target_source:
        # Uma identidade já migrada para a fonte estável desta plataforma é
        # autoridade durante a instalação atual. Isso impede que uma leitura
        # transitória de hardware troque o DID no meio do uso.
        if persistent and persistent_source == target_source:
            if local != persistent or local_source != persistent_source:
                _store_device_id(local_path, persistent, persistent_source)
            return persistent
        if local and local_source == target_source:
            _store_device_id(persistent_path, local, local_source)
            return local

        # O add-on ainda está em desenvolvimento, então IDs legados aleatórios
        # podem migrar uma única vez para a identidade determinística do
        # aparelho/sistema. A leitura da fonte só acontece aqui, depois de
        # verificar os caches estáveis, para não consultar hardware a cada uso.
        hardware_identity = identity_probe() if identity_probe is not None else ''
        if hardware_identity:
            device_id = _derived_device_id(namespace, hardware_identity)
            return _persist_both(local_path, persistent_path, device_id, target_source)

        # Se a plataforma ocultar temporariamente sua fonte estável, preservar
        # o ID já existente é mais seguro do que trocar de identidade em uso.
        if persistent:
            if local != persistent:
                _store_device_id(local_path, persistent, persistent_source or _RANDOM_SOURCE)
            return persistent
        if local:
            _store_device_id(persistent_path, local, local_source or _RANDOM_SOURCE)
            return local

        # Último recurso: mantém compatibilidade funcional, mas esta única rota
        # não pode prometer persistência após remoção total dos dados do Kodi.
        device_id = _legacy_random_device_id(local_path)
        return _persist_both(local_path, persistent_path, device_id, _RANDOM_SOURCE)

    # Plataformas ainda sem identidade externa mantêm o comportamento legado.
    if local and not persistent:
        _store_device_id(persistent_path, local, local_source or _RANDOM_SOURCE)
        return local

    if persistent:
        if local != persistent:
            _store_device_id(local_path, persistent, persistent_source or _RANDOM_SOURCE)
        return persistent

    device_id = _legacy_random_device_id(local_path)
    return _persist_both(local_path, persistent_path, device_id, _RANDOM_SOURCE)



def get_device_identity_source():
    """Return only the non-sensitive source class used by the current DID."""
    try:
        device_id = get_device_id()
        local_path = state_path('device.json')
        persistent_path = _persistent_device_path()
        local, local_source = _read_device_record(local_path)
        persistent, persistent_source = _read_device_record(persistent_path)
        if persistent == device_id and persistent_source:
            return persistent_source
        if local == device_id and local_source:
            return local_source
    except Exception:
        pass
    return ''
