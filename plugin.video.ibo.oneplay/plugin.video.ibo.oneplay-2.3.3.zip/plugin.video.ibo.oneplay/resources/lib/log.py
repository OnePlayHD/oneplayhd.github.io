# -*- coding: utf-8 -*-
try:
    import xbmc
except Exception:
    xbmc = None

def log(message, level='info'):
    text = '[IBO V2] %s' % str(message)
    if xbmc is None:
        return
    levels = {
        'debug': xbmc.LOGDEBUG,
        'warning': xbmc.LOGWARNING,
        'error': xbmc.LOGERROR,
        'info': xbmc.LOGINFO,
    }
    xbmc.log(text, levels.get(level, xbmc.LOGINFO))
