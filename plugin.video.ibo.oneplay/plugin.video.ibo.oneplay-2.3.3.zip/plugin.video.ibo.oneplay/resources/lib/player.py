# -*- coding: utf-8 -*-
import base64
import time
import urllib.parse

from .auth import failover_for_media, session_client
from .constants import PLUGIN_URL
from .http import HttpError
from .content_errors import humanize_content_error
from .log import log
from .media_relay import register_playback, release_playback
from .ffmpeg_direct import ensure_ffmpeg_direct, ffmpeg_direct_format
from .prefs import get_int
from .state import clear_playback, load_session, mark_playback, playback_fingerprint, save_session
from .watch_history import mark_watched, record_progress

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
except Exception:
    xbmc = None
    xbmcaddon = None
    xbmcgui = None


def _set_info(item, title, plot='', year=None, season=None, episode=None, tagline='', plot_outline=''):
    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(str(title or ''))
        if plot:
            tag.setPlot(str(plot))
        if tagline:
            try:
                tag.setTagLine(str(tagline))
            except Exception:
                pass
        if plot_outline:
            try:
                tag.setPlotOutline(str(plot_outline))
            except Exception:
                pass
        if year:
            tag.setYear(int(year))
        if season is not None:
            tag.setSeason(int(season))
        if episode is not None:
            tag.setEpisode(int(episode))
    except Exception:
        labels = {'Title': str(title or ''), 'Plot': str(plot or '')}
        if tagline:
            labels['Tagline'] = str(tagline)
        if plot_outline:
            labels['PlotOutline'] = str(plot_outline)
        if year:
            labels['Year'] = year
        item.setInfo('Video', labels)


def _decode_epg_text(value):
    text = str(value or '')
    if not text:
        return ''
    try:
        raw = base64.b64decode(text, validate=True)
        decoded = raw.decode('utf-8', 'ignore').strip()
        return decoded or text
    except Exception:
        return text.strip()


def _epg_stamp(value):
    text = str(value or '').strip()
    if not text:
        return 0
    try:
        number = int(float(text))
        if number > 1000000000:
            return number
    except Exception:
        pass
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M'):
        try:
            return int(time.mktime(time.strptime(text, fmt)))
        except Exception:
            pass
    return 0


def _epg_clock(stamp):
    try:
        return time.strftime('%H:%M', time.localtime(int(stamp))) if int(stamp) > 0 else '--:--'
    except Exception:
        return '--:--'


def _format_live_epg(rows, fallback_plot=''):
    """Build Kodi Live OSD metadata in the approved OnePlay VIP now/next style."""
    normalized = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        title = _decode_epg_text(row.get('title') or row.get('name') or '').strip()
        desc = _decode_epg_text(row.get('description') or row.get('desc') or '').strip()
        start = _epg_stamp(row.get('start_timestamp') or row.get('start') or row.get('start_time'))
        end = _epg_stamp(row.get('stop_timestamp') or row.get('end_timestamp') or row.get('end') or row.get('stop'))
        if title or desc or start or end:
            normalized.append((start, end, title or 'Sem título', desc))
    if not normalized:
        return str(fallback_plot or ''), '', ''

    now = int(time.time())
    current_idx = 0
    for idx, item in enumerate(normalized):
        start, end = item[0], item[1]
        if start and end and start <= now < end:
            current_idx = idx
            break
        if start and start >= now:
            current_idx = idx
            break

    start, end, current_title, current_desc = normalized[current_idx]
    current_range = '%s - %s' % (_epg_clock(start), _epg_clock(end))
    current_line = 'Agora: %s | %s' % (current_range, current_title) if current_range else 'Agora: %s' % current_title

    # Referência visual OnePlay VIP 0.3.2: Agora/Próximo em aquamarine no Plot,
    # descrições em texto normal e uma linha vazia separando os dois blocos.
    # Não usar TagLine/PlotOutline para evitar destaque/repetição diferente entre skins.
    parts = ['[COLOR aquamarine]%s[/COLOR]' % current_line]
    if current_desc:
        parts.append(current_desc)

    if current_idx + 1 < len(normalized):
        nstart, nend, next_title, next_desc = normalized[current_idx + 1]
        next_range = '%s - %s' % (_epg_clock(nstart), _epg_clock(nend))
        next_line = 'Próximo: %s | %s' % (next_range, next_title) if next_range else 'Próximo: %s' % next_title
        parts.append('')
        parts.append('[COLOR aquamarine]%s[/COLOR]' % next_line)
        if next_desc:
            parts.append(next_desc)

    return '\n'.join(parts).strip(), '', ''


def _ffmpeg_direct_requested():
    """User preference only. The binary component remains optional."""
    try:
        return bool(get_int('ffmpeg_direct', default=0, low=0, high=1))
    except Exception:
        return False


def _build_url(client, kind, stream_id, extension):
    if kind == 'live':
        return client.live_url(stream_id, extension)
    if kind == 'movie':
        return client.vod_url(stream_id, extension or 'mp4')
    return client.episode_url(stream_id, extension or 'mp4')


def _media_probe_timeout(kind):
    # Live must fail quickly; VOD gets a little more room for storage/CDN wakeup.
    return 3.5 if str(kind) == 'live' else 5.0




def _media_failover_budget(kind):
    # Overall retry budget *after* the first failed media probe. Immediate
    # HTTP/DNS failures can still traverse several mirrors, while a chain of
    # hanging endpoints cannot keep "Abrindo conteúdo..." on screen forever.
    return 8.0 if str(kind) == 'live' else 12.0


def _media_start_timeout(kind):
    # Bound the visible "Abrindo conteúdo..." stage after preflight succeeds.
    return 7.0 if str(kind) == 'live' else 10.0


def _media_unavailable_message(kind, detail=''):
    return humanize_content_error(detail, kind=kind, phase='playback')


def _relay_resolve_url(relay_url, playback_mode='standard', kind=''):
    """Build a credential-free plugin identity for Kodi native resolution.

    Kodi keeps this plugin:// URL as CFileItem.Path while setResolvedUrl supplies
    the loopback relay as CFileItem.DynPath.  If FFmpeg Direct is selected, only
    non-sensitive mode flags are carried to the resolver; the resolver attaches
    the inputstream properties to the *resolved* ListItem, where Kodi actually
    chooses the inputstream client.
    """
    raw = str(relay_url or '').strip()
    if not raw.startswith('http://127.0.0.1:'):
        raise ValueError('relay local inválido')
    token = base64.urlsafe_b64encode(raw.encode('utf-8')).decode('ascii').rstrip('=')
    base = str(PLUGIN_URL or 'plugin://plugin.video.ibo.oneplay/').rstrip('/') + '/'
    params = [
        'ibo_action=resolve_media',
        'target=%s' % urllib.parse.quote(token, safe=''),
    ]
    if str(playback_mode or '') == 'ffmpegdirect':
        params.append('fd=1')
        params.append('rt=1' if str(kind or '') == 'live' else 'rt=0')
    return '%s?%s' % (base, '&'.join(params))


def _prepare(kind, stream_id, title, extension='', art='', plot='', year=None, season=None, episode=None, epg_rows=None, force_standard=False, skip_probe=False):
    if xbmc is None or xbmcgui is None:
        return {'ok': False, 'error': 'Kodi indisponível.'}
    session = load_session()
    if not session:
        return {'ok': False, 'error': 'Sessão ausente.'}
    client = session_client(session)
    ext = extension or (client.output if kind == 'live' else 'mp4')
    raw = _build_url(client, kind, stream_id, ext)

    if not skip_probe:
        probe_timeout = _media_probe_timeout(kind)
        try:
            client.probe(raw, timeout=probe_timeout, kind=kind)
        except HttpError as exc:
            log('Preflight de mídia falhou (%s, %s); acionando failover rápido do mesmo grupo.' % (kind, exc.status or 'rede'), 'warning')
            seen_servers = {str(client.base_url or '').rstrip('/').casefold()}
            last_error = exc
            failed_url = exc.url or raw
            failed_transport = bool(exc.transport)
            failover_started = time.time()
            failover_deadline = failover_started + _media_failover_budget(kind)
            recovered = False
            outcome = {}
            attempts = get_int('failover_attempts', default=5, low=1, high=8)

            for attempt in range(attempts):
                remaining = failover_deadline - time.time()
                if remaining < 1.5:
                    log('Failover de mídia: orçamento total esgotado após %.2fs.' % (time.time() - failover_started), 'warning')
                    break
                outcome = failover_for_media(
                    failed_url,
                    transport=failed_transport,
                    timeout=min(2.5, remaining),
                    excluded_urls=list(seen_servers),
                ) or {}
                if not outcome.get('ok'):
                    if outcome.get('denied'):
                        denied_error = outcome.get('error') or 'Acesso bloqueado.'
                        log('Failover de mídia negado (%s): %s' % (kind, denied_error), 'warning')
                        return {'ok': False, 'error': humanize_content_error(denied_error, kind=kind, phase='playback')}
                    last_error = outcome.get('error') or last_error
                    break

                candidate_session = outcome.get('session') if isinstance(outcome.get('session'), dict) else {}
                try:
                    candidate = session_client(candidate_session)
                except Exception as exc2:
                    last_error = exc2
                    break
                marker = str(candidate.base_url or '').rstrip('/').casefold()
                if not marker or marker in seen_servers:
                    last_error = 'O painel não encontrou outra DNS ainda não testada.'
                    log('Failover de mídia interrompido para evitar repetir a mesma DNS.', 'warning')
                    break
                seen_servers.add(marker)
                candidate_raw = _build_url(candidate, kind, stream_id, ext)

                try:
                    remaining = failover_deadline - time.time()
                    if remaining < 2.0:
                        last_error = 'Tempo de failover esgotado antes da próxima prova de mídia.'
                        break
                    candidate_timeout = min(probe_timeout, remaining)
                    candidate.probe(candidate_raw, timeout=candidate_timeout, kind=kind)
                    session = save_session(candidate_session)
                    client = session_client(session)
                    raw = _build_url(client, kind, stream_id, ext)
                    recovered = True
                    log('Failover de mídia concluído em %.2fs na tentativa %d.' % (time.time() - failover_started, attempt + 1), 'debug')
                    break
                except HttpError as exc2:
                    last_error = exc2
                    failed_url = exc2.url or candidate_raw
                    failed_transport = bool(exc2.transport)
                    log('Failover de mídia: candidato %d falhou (%s); próximo espelho será solicitado.' % (attempt + 1, exc2.status or 'rede'), 'warning')
                    continue
                except Exception as exc2:
                    last_error = exc2
                    break

            if not recovered:
                # Nenhum candidato não comprovado foi persistido; a sessão
                # anterior permanece autoritativa e o browser pode continuar
                # normalmente depois da mensagem de indisponibilidade.
                log('Failover de mídia esgotado (%s): %s' % (kind, last_error), 'warning')
                return {'ok': False, 'error': _media_unavailable_message(kind, last_error)}
        except Exception as exc:
            log('Preflight de mídia falhou fora do HttpError (%s): %s' % (kind, exc), 'warning')
            return {'ok': False, 'error': _media_unavailable_message(kind, exc)}

    # Decide the inputstream before building the plugin resolver URL, but do
    # not attach inputstream properties to this initial ListItem.  Those
    # properties must live on the ListItem returned by setResolvedUrl(), which
    # becomes Kodi's DynPath transport item.
    playback_mode = 'standard'
    ffmpeg_fmt = ffmpeg_direct_format(raw)
    if not force_standard and _ffmpeg_direct_requested() and ffmpeg_fmt:
        if ensure_ffmpeg_direct(interactive=False):
            playback_mode = 'ffmpegdirect'
            log('FFmpeg Direct: modo confirmado para %s (%s); configuração será aplicada no DynPath.' % (kind, ffmpeg_fmt), 'debug')
        else:
            log('FFmpeg Direct solicitado, mas o componente oficial ainda não está disponível/ativo; usando padrão do Kodi.', 'warning')

    # Credential firewall: VideoPlayer receives only an opaque loopback URL.
    # Fail closed: direct Xtream fallback would reintroduce credentials in kodi.log.
    try:
        relay_url, relay_session_id = register_playback(raw, kind)
    except Exception:
        log('Relay de mídia seguro indisponível; reprodução bloqueada para não expor credenciais.', 'error')
        return {'ok': False, 'error': 'Proteção de mídia indisponível. Reinicie o Kodi e tente novamente.'}
    # Kodi-native identity/transport split:
    #   Path    = plugin://... opaque resolver (used by CSaveFileState/database)
    #   DynPath = http://127.0.0.1/... (resolved media transport)
    playable = str(relay_url or '')
    try:
        play_request = _relay_resolve_url(playable, playback_mode=playback_mode, kind=kind)
    except Exception:
        release_playback(relay_session_id)
        log('Identidade segura do player não pôde ser criada; reprodução bloqueada.', 'error')
        return {'ok': False, 'error': 'Proteção de mídia indisponível. Reinicie o Kodi e tente novamente.'}
    li = xbmcgui.ListItem(label=str(title or ''))
    # The local relay URL already has a deterministic suffix. Tell Kodi the MIME
    # up front and disable remote content sniffing; this removes an avoidable
    # metadata round-trip from Play without changing the actual demux path.
    try:
        local_ext = str(ext or '').strip().lower().lstrip('.')
        if str(kind) == 'live' and local_ext == 'm3u8':
            li.setMimeType('application/vnd.apple.mpegurl')
        elif str(kind) == 'live' and local_ext == 'ts':
            li.setMimeType('video/mp2t')
        elif local_ext == 'mp4':
            li.setMimeType('video/mp4')
        elif local_ext == 'mkv':
            li.setMimeType('video/x-matroska')
        li.setContentLookup(False)
    except Exception:
        pass
    media_plot = plot
    tagline = ''
    plot_outline = ''
    if kind == 'live':
        media_plot, tagline, plot_outline = _format_live_epg(epg_rows, fallback_plot=plot)
    _set_info(li, title, media_plot, year, season, episode, tagline=tagline, plot_outline=plot_outline)
    playback_art = str(art or '').strip()
    if not playback_art:
        try:
            addon_path = xbmcaddon.Addon().getAddonInfo('path') if xbmcaddon is not None else ''
            media_dir = '%s/resources/skins/Default/media' % str(addon_path or '').rstrip('/\\')
            fallback_name = 'live_fallback.png' if str(kind) == 'live' else 'no_vod.png'
            playback_art = '%s/%s' % (media_dir, fallback_name) if media_dir else ''
        except Exception:
            playback_art = ''
    if playback_art:
        li.setArt({'thumb': playback_art, 'poster': playback_art, 'icon': playback_art})
    # Player.play() will overwrite Path with play_request as well; setting it
    # here keeps the ListItem internally coherent before the async handoff.
    li.setPath(play_request)
    li.setProperty('ForceResolvePlugin', 'true')
    li.setProperty('IsPlayable', 'true')
    return {
        'ok': True,
        'playable': playable,
        'play_request': play_request,
        'item': li,
        'kind': kind,
        'title': str(title or ''),
        'playback_mode': playback_mode,
        'relay_session_id': relay_session_id,
    }


def play(kind, stream_id, title, extension='', art='', plot='', year=None, season=None, episode=None, epg_rows=None, force_standard=False, skip_probe=False, playback_meta=None, resume_at=0.0):
    prepared = _prepare(kind, stream_id, title, extension, art, plot, year, season, episode, epg_rows, force_standard=force_standard, skip_probe=skip_probe)
    if not prepared.get('ok'):
        return prepared
    playable = prepared['playable']
    mark_playback(playable, kind, title, meta=playback_meta, relay_session_id=prepared.get('relay_session_id') or '', resume_at=resume_at)
    try:
        xbmc.Player().play(prepared.get('play_request') or playable, prepared['item'])
        return {
            'ok': True,
            'url': playable,
            'playable': playable,
            'playback_mode': prepared.get('playback_mode') or 'standard',
            'relay_session_id': prepared.get('relay_session_id') or '',
        }
    except Exception as exc:
        clear_playback()
        release_playback(prepared.get('relay_session_id') or '')
        log('Player: falha técnica ao iniciar VideoPlayer (%s): %s' % (kind, exc), 'error')
        return {'ok': False, 'error': humanize_content_error(exc, kind=kind, phase='player'), 'playback_mode': prepared.get('playback_mode') or 'standard'}


def _activate_fullscreen_with_retry(player, monitor, timeout=1.6):
    """Entrega a GUI ao VideoFullScreen sem depender de ids de dialog.

    O Kodi pode manter ``getCurrentWindowDialogId()`` apontando por algum tempo
    para uma WindowXMLDialog que já recebeu ``Window Deinit``. A 2.0.90 usou
    esse valor stale como trava e passou a recusar falsamente todo retorno ao
    player. Aqui a autoridade é somente observável: o mesmo vídeo continua
    ativo e ``VideoFullScreen`` ficou realmente ativo.

    A operação é idempotente e bounded. Ela nunca chama ``Player.play()``:
    pede o fullscreen, aguarda uma pequena fatia e tenta novamente somente
    enquanto o mesmo VideoPlayer permanece vivo. O mutex/guard de ``screens``
    impede transições concorrentes entre intérpretes.
    """
    if xbmc is None:
        return False
    deadline = time.monotonic() + max(0.4, float(timeout))
    attempts = 0
    while time.monotonic() < deadline:
        if _video_fullscreen_active():
            return True
        try:
            if not player.isPlayingVideo():
                return False
        except Exception:
            return False

        attempts += 1
        try:
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
        except Exception:
            try:
                xbmc.executebuiltin('Action(FullScreen)')
            except Exception:
                pass

        slice_deadline = min(deadline, time.monotonic() + 0.28)
        while time.monotonic() < slice_deadline:
            if _video_fullscreen_active():
                if attempts > 1:
                    log('Player: handoff para fullscreen aceito na tentativa %d.' % attempts, 'debug')
                return True
            try:
                if not player.isPlayingVideo():
                    return False
            except Exception:
                return False
            try:
                if monitor.abortRequested():
                    return False
            except Exception:
                pass
            try:
                if monitor.waitForAbort(0.05):
                    return False
            except Exception:
                try:
                    xbmc.sleep(50)
                except Exception:
                    pass
    return _video_fullscreen_active()


def _suppress_kodi_busy_dialogs():
    """Hide Kodi's native busy spinner only during ONEPLAY media startup.

    The ONEPLAY IBOProgress is the sole startup feedback. Kodi may open
    busydialog/busydialognocancel after Player.play(), placing its blue spinner
    above the custom skin. Close only those two native dialogs, forcefully and
    without animation. Never close unrelated dialogs.
    """
    if xbmc is None:
        return False
    visible = False
    for dialog_name in ('busydialog', 'busydialognocancel'):
        try:
            if xbmc.getCondVisibility('Window.IsVisible(%s)' % dialog_name):
                visible = True
        except Exception:
            pass
        try:
            xbmc.executebuiltin('Dialog.Close(%s,true)' % dialog_name)
        except Exception:
            pass
    return visible


def _wait_player_started(player, monitor, timeout, expected_playable='', startup_tick=None):
    """Confirma que *o stream solicitado* assumiu o VideoPlayer.

    Ao trocar de canal enquanto outro vídeo permanece em background,
    ``isPlayingVideo()`` já é True antes de ``Player.play(novo)`` completar.
    A 2.0.89 podia então confirmar o fingerprint do novo canal contra o player
    antigo. Quando existe ``expected_playable``, só aceite o start depois que
    ``getPlayingFile()`` corresponder ao fingerprint do alvo.
    """
    deadline = time.time() + max(1.0, float(timeout))
    expected_hash = playback_fingerprint(expected_playable)
    while time.time() < deadline:
        if callable(startup_tick):
            try:
                startup_tick()
            except Exception:
                pass
        try:
            if monitor.abortRequested():
                return False
        except Exception:
            pass
        try:
            playing = bool(player.isPlayingVideo() or player.isPlaying())
        except Exception:
            playing = False
        if playing:
            if not expected_hash:
                return True
            try:
                current = str(player.getPlayingFile() or '')
            except Exception:
                current = ''
            if current and playback_fingerprint(current) == expected_hash:
                return True
        try:
            if monitor.waitForAbort(0.05):
                return False
        except Exception:
            try:
                xbmc.sleep(50)
            except Exception:
                break
    return False


def _wait_ffmpeg_direct_live_clock(player, monitor, timeout, expected_playable='', min_progress=0.40, startup_tick=None):
    """Confirma AV útil no Live FFmpeg Direct pelo relógio real do player.

    ``OnPlayBackStarted``/``isPlayingVideo()`` acontecem antes de o
    inputstream.ffmpegdirect terminar de abrir HLS/demux/AV. Para Live, só
    consideramos a primeira tentativa pronta quando o mesmo arquivo continua
    ativo e ``getTime()`` avança de forma mensurável. A espera é bounded e
    acontece enquanto a IBOProgress ainda cobre a transição.
    """
    deadline = time.monotonic() + max(0.10, float(timeout or 0.0))
    expected_hash = playback_fingerprint(expected_playable)
    first_position = None
    while time.monotonic() < deadline:
        if callable(startup_tick):
            try:
                startup_tick()
            except Exception:
                pass
        try:
            if monitor.abortRequested():
                return False
        except Exception:
            pass
        try:
            if not (player.isPlayingVideo() or player.isPlaying()):
                return False
        except Exception:
            return False
        if expected_hash:
            try:
                current = str(player.getPlayingFile() or '')
            except Exception:
                current = ''
            if current and playback_fingerprint(current) != expected_hash:
                return False
        try:
            position = max(0.0, float(player.getTime() or 0.0))
        except Exception:
            position = None
        if position is not None:
            if first_position is None:
                first_position = position
            elif position >= first_position + max(0.10, float(min_progress or 0.0)):
                return True
        try:
            if monitor.waitForAbort(0.05):
                return False
        except Exception:
            try:
                xbmc.sleep(50)
            except Exception:
                pass
    return False


def _ffmpeg_direct_live_window(window_started_at, window_position, now, position,
                               window_seconds=10.0, min_progress=5.0):
    """Avalia progresso útil de Live FFmpeg Direct em uma janela bounded.

    O watchdog histórico detecta zero progresso. Alguns HLS defeituosos no
    FFmpeg Direct, porém, avançam poucos décimos/segundos entre buffers e
    renovam o watchdog de zero progresso. Esta segunda camada usa a mesma
    janela operacional de 10 s do Live: em FFmpegDirect esperamos ao menos
    5 s de timeline real. Mudanças/reinícios de timeline apenas rearmam a
    janela, evitando falso positivo por descontinuidade do HLS.
    """
    try:
        now_value = float(now)
        pos_value = max(0.0, float(position))
    except Exception:
        return window_started_at, window_position, False, None
    if window_position is None or window_started_at is None:
        return now_value, pos_value, False, None
    try:
        base_pos = max(0.0, float(window_position))
        base_time = float(window_started_at)
    except Exception:
        return now_value, pos_value, False, None
    # HLS pode reiniciar a timeline em descontinuidade/troca interna. Não trate
    # uma regressão grande do relógio como travamento; apenas recomece a janela.
    if pos_value + 0.50 < base_pos:
        return now_value, pos_value, False, None
    elapsed = max(0.0, now_value - base_time)
    if elapsed < max(1.0, float(window_seconds or 0.0)):
        return base_time, base_pos, False, None
    progressed = max(0.0, pos_value - base_pos)
    unhealthy = progressed < max(0.5, float(min_progress or 0.0))
    return now_value, pos_value, unhealthy, progressed


def _apply_verified_resume(player, monitor, resume_value, kind, ready_timeout=12.0, startup_tick=None):
    """Aplica resume somente depois que a timeline do Kodi estiver utilizável.

    ``Player.isPlaying()`` pode virar True imediatamente após ``play()``, antes
    de InputStream/Demuxer conhecerem duração/PTS. Nessa fase ``seekTime()``
    não lança exceção, mas também pode ser descartado silenciosamente pelo
    Kodi. Esperamos uma timeline real e confirmamos o resultado pelo relógio
    efetivo do player, com tentativas curtas e limitadas.
    """
    try:
        target = max(0.0, float(resume_value or 0.0))
    except Exception:
        target = 0.0
    if target < 30.0 or str(kind) not in ('movie', 'series'):
        return False

    deadline = time.monotonic() + max(2.0, float(ready_timeout or 0.0))
    total_seen = 0.0
    timeline_ready = False
    while time.monotonic() < deadline:
        if callable(startup_tick):
            try:
                startup_tick()
            except Exception:
                pass
        try:
            if monitor.abortRequested():
                return False
        except Exception:
            pass
        try:
            if not player.isPlaying():
                return False
        except Exception:
            return False
        try:
            total_seen = max(0.0, float(player.getTotalTime() or 0.0))
        except Exception:
            total_seen = 0.0
        try:
            current = max(0.0, float(player.getTime() or 0.0))
        except Exception:
            current = 0.0

        if total_seen > 0.0:
            # Um ponto praticamente no final não deve ser retomado.
            if target >= max(0.0, total_seen - 15.0):
                log('Histórico: retomada ignorada por estar no fim da mídia (%.1fs/%.1fs).' % (target, total_seen), 'debug')
                return False
            timeline_ready = True
            break
        # Alguns inputs não informam duração imediatamente, mas um relógio que
        # já avançou prova que o demux/player possui uma timeline seekable.
        if current >= 0.25:
            timeline_ready = True
            break
        try:
            if monitor.waitForAbort(0.10):
                return False
        except Exception:
            try:
                xbmc.sleep(100)
            except Exception:
                pass

    if not timeline_ready:
        log('Histórico: timeline não ficou pronta para retomar em %.1fs (%s).' % (target, kind), 'warning')
        return False

    tolerance = 8.0
    for attempt in range(1, 4):
        try:
            player.seekTime(target)
        except Exception as exc:
            log('Histórico: Kodi recusou seek de retomada na tentativa %d: %s' % (attempt, exc), 'debug')
            continue

        verify_deadline = time.monotonic() + 1.6
        while time.monotonic() < verify_deadline:
            if callable(startup_tick):
                try:
                    startup_tick()
                except Exception:
                    pass
            try:
                if monitor.abortRequested() or not player.isPlaying():
                    return False
            except Exception:
                pass
            try:
                actual = max(0.0, float(player.getTime() or 0.0))
            except Exception:
                actual = 0.0
            if actual >= max(1.0, target - tolerance):
                log('Histórico: retomada confirmada em %.1fs (alvo %.1fs, %s, tentativa %d).' % (actual, target, kind, attempt), 'debug')
                return True
            try:
                if monitor.waitForAbort(0.10):
                    return False
            except Exception:
                try:
                    xbmc.sleep(100)
                except Exception:
                    pass
        if attempt < 3:
            try:
                if monitor.waitForAbort(0.20):
                    return False
            except Exception:
                try:
                    xbmc.sleep(200)
                except Exception:
                    pass

    log('Histórico: seek de retomada não foi confirmado pelo relógio do Kodi (alvo %.1fs, %s).' % (target, kind), 'warning')
    return False


def _video_fullscreen_active():
    """Return whether Kodi is currently presenting VideoFullScreen."""
    if xbmc is None:
        return False
    try:
        if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
            return True
    except Exception:
        pass
    if xbmcgui is not None:
        try:
            return int(xbmcgui.getCurrentWindowId() or 0) == 12005
        except Exception:
            pass
    return False


def _wait_resumed_vod_auto_fullscreen(player, monitor, timeout=1.6, startup_tick=None):
    """Wait briefly for Kodi's own fullscreen promotion after a verified resume.

    A verified seek can make ``getTime()`` jump to the saved position before
    Kodi has emitted its final AV-start transition. Forcing 12005 during that
    narrow interval races the still-active IBOProgress modal and Kodi rejects
    the request. This helper is intentionally passive: it never calls
    ``ActivateWindow``. If Kodi does not promote by itself within the bounded
    window, the caller closes IBOProgress first and only then uses the existing
    explicit fullscreen fallback.
    """
    deadline = time.monotonic() + max(0.2, float(timeout or 0.0))
    while time.monotonic() < deadline:
        if callable(startup_tick):
            try:
                startup_tick()
            except Exception:
                pass
        if _video_fullscreen_active():
            return True
        try:
            if not player.isPlayingVideo():
                return False
        except Exception:
            return False
        try:
            if monitor.abortRequested():
                return False
        except Exception:
            pass
        try:
            if monitor.waitForAbort(0.05):
                return False
        except Exception:
            try:
                xbmc.sleep(50)
            except Exception:
                pass
    return _video_fullscreen_active()


def _returned_to_addon_ui():
    """Conservative signal that FullScreen video was dismissed to OnePlay/Kodi."""
    if xbmcgui is None:
        return False
    try:
        current_id = int(xbmcgui.getCurrentWindowId() or 0)
    except Exception:
        current_id = 0
    # OSD/seek continuam sobre VideoFullScreen (12005). As janelas OnePlay
    # recebem IDs 13000+ variáveis a cada abertura. MyVideoNav (10025) NÃO é
    # uma UI válida do ONEPLAY: tratá-lo como retorno aceitável mascarou a
    # reinvocação do plugin observada no log real da 2.0.89.
    return 13000 <= current_id <= 13099



def _wait_vod_mp4_ready(player, monitor, expected_playable='', startup_tick=None, safety_timeout=35.0):
    """Observa prontidão real de VOD MP4 sem usar prazo fixo como gatilho visual.

    Para filme/episódio MP4, ``OnPlayBackStarted``/``isPlayingVideo()`` pode
    acontecer muitos segundos antes de o demuxer conhecer duração/PTS. O
    overlay ONEPLAY deve permanecer enquanto isso. Consideramos a mídia pronta
    quando ocorre uma destas provas observáveis:

    * VideoFullScreen já assumiu; ou
    * o relógio real ``getTime()`` começou a avançar.

    ``getTotalTime()`` é observado apenas para diagnóstico; duração conhecida
    sozinha não fecha a cobertura, porque o demux pode conhecer a duração alguns
    décimos antes de haver quadro/relógio realmente útil.

    ``safety_timeout`` NÃO decide o fechamento normal. É apenas um fail-safe
    extremo para não prender a UI para sempre se um servidor/player defeituoso
    mantiver ``isPlaying()`` verdadeiro sem jamais produzir timeline.
    """
    deadline = time.monotonic() + max(5.0, float(safety_timeout or 0.0))
    expected_hash = playback_fingerprint(expected_playable)
    while time.monotonic() < deadline:
        if callable(startup_tick):
            try:
                startup_tick()
            except Exception:
                pass

        try:
            if monitor.abortRequested():
                return 'aborted'
        except Exception:
            pass

        try:
            playing = bool(player.isPlayingVideo() or player.isPlaying())
        except Exception:
            playing = False
        if not playing:
            return 'stopped'

        if expected_hash:
            try:
                current = str(player.getPlayingFile() or '')
            except Exception:
                current = ''
            if current and playback_fingerprint(current) != expected_hash:
                return 'replaced'

        if _video_fullscreen_active():
            return 'fullscreen'

        try:
            total = max(0.0, float(player.getTotalTime() or 0.0))
        except Exception:
            total = 0.0
        try:
            position = max(0.0, float(player.getTime() or 0.0))
        except Exception:
            position = 0.0

        # Para o handoff visual MP4 exigimos relógio real em avanço. Duração
        # conhecida sozinha não basta: avformat_find_stream_info pode terminar
        # antes de o primeiro quadro/PTS útil estar efetivamente correndo.
        if position >= 0.25:
            log(
                'VOD MP4: reproducao pronta (duracao=%.1fs, posicao=%.2fs); '
                'entregando o player ao fullscreen.' % (total, position),
                'debug',
            )
            return 'timeline'

        try:
            if monitor.waitForAbort(0.05):
                return 'aborted'
        except Exception:
            try:
                xbmc.sleep(50)
            except Exception:
                pass

    log(
        'VOD MP4: timeline ainda não pronta no fail-safe de %.0fs; '
        'mantendo o fallback bounded histórico.' % max(5.0, float(safety_timeout or 0.0)),
        'warning',
    )
    return 'timeout'

def play_and_wait(kind, stream_id, title, extension='', art='', plot='', year=None, season=None, episode=None, start_timeout=None, opening_start=None, opening_stop=None, epg_rows=None, return_start=None, skip_probe=False, resume_at=0.0, playback_meta=None, up_next=None, up_next_prompt=None):
    """Play outside IBO modal UI and return after Stop/Back.

    V2.0.3 preserves the stall watchdog so a broken Live stream cannot trap
    the test session forever on Kodi's spinner.
    """
    if xbmc is None:
        return {'ok': False, 'error': 'Kodi indisponível.'}

    opening_active = False
    startup_ui_active = True
    busy_suppressed_logged = False

    def _finish_opening():
        nonlocal opening_active
        if not opening_active:
            return
        opening_active = False
        if callable(opening_stop):
            try:
                opening_stop()
            except Exception as exc:
                log('Falha ao fechar janela de abertura: %s' % exc, 'warning')

    def _startup_tick():
        """Keep Kodi Busy below the ONEPLAY startup and drop IBOProgress at fullscreen."""
        nonlocal busy_suppressed_logged
        if startup_ui_active:
            try:
                if _suppress_kodi_busy_dialogs() and not busy_suppressed_logged:
                    busy_suppressed_logged = True
                    log('Abertura: DialogBusy nativo do Kodi suprimido pela IBOProgress.', 'debug')
            except Exception:
                pass
        # Critical visual contract: once Kodi has actually promoted the same
        # VideoPlayer to fullscreen, remove IBOProgress immediately. Do not
        # wait for DialogBusy to deinit and do not add an artificial tail.
        if opening_active and _video_fullscreen_active():
            _finish_opening()

    # Start/claim the opening UI before waiting for the previous modal to finish
    # deinitializing.  In the normal interactive path it is already visible
    # from the Select event; in fallback paths this still brings it up as early
    # as possible.
    if callable(opening_start):
        try:
            opening_start()
            opening_active = True
        except Exception as exc:
            log('Falha ao abrir janela de abertura: %s' % exc, 'warning')

    _startup_tick()

    # A IBOProgress pertence ao próprio add-on e já cobre a desmontagem da
    # janela de origem. Não consulte ids de dialogs aqui: o Kodi pode manter
    # ids stale durante a animação de fechamento.
    player = xbmc.Player()
    monitor = xbmc.Monitor()
    effective_start_timeout = _media_start_timeout(kind) if start_timeout is None else max(3.0, float(start_timeout))
    try:
        outcome = play(kind, stream_id, title, extension, art, plot, year, season, episode, epg_rows, skip_probe=skip_probe, playback_meta=playback_meta, resume_at=resume_at)
        _startup_tick()
    except Exception:
        _finish_opening()
        raise

    playback_mode = str(outcome.get('playback_mode') or 'standard')
    startup_started_at = time.time()
    started = False
    if outcome.get('ok'):
        # V2.0.99 — o modo escolhido pelo usuário permanece autoridade.
        # Standard conserva o timeout histórico de abertura. Live FFmpegDirect
        # recebe um orçamento TOTAL de 10 s para produzir progresso real do
        # relógio enquanto a IBOProgress cobre a inicialização HLS/demux/AV.
        # Se não produzir, esta fonte falha e o router segue para a próxima
        # fonte do anel; a mesma URL NÃO é reaberta no player padrão.
        first_timeout = min(5.0, effective_start_timeout) if playback_mode == 'ffmpegdirect' else effective_start_timeout
        started = _wait_player_started(
            player, monitor, first_timeout, outcome.get('playable') or '', startup_tick=_startup_tick
        )
        if started and playback_mode == 'ffmpegdirect' and str(kind) == 'live':
            total_ready_budget = min(10.0, effective_start_timeout)
            remaining_ready = max(0.10, total_ready_budget - max(0.0, time.time() - startup_started_at))
            started = _wait_ffmpeg_direct_live_clock(
                player, monitor, remaining_ready, outcome.get('playable') or '',
                min_progress=0.40, startup_tick=_startup_tick
            )
            if started:
                log('FFmpeg Direct: Live confirmado por progresso real do relógio.', 'debug')
            else:
                log('FFmpeg Direct: fonte Live sem progresso real em até 10s; liberando para a próxima fonte.', 'warning')

    aborted = False
    try:
        aborted = monitor.abortRequested()
    except Exception:
        pass

    if not started:
        startup_ui_active = False
        _finish_opening()
        try:
            player.stop()
        except Exception:
            pass
        clear_playback()
        release_playback(outcome.get('relay_session_id') or '')
        if aborted:
            return {'ok': False, 'aborted': True, 'error': 'Execução cancelada pelo Kodi.'}
        if not outcome.get('ok'):
            return outcome
        return {'ok': False, 'error': humanize_content_error('O Kodi não iniciou a reprodução dentro do limite de segurança.', kind=kind, phase='player')}

    # Confirma novamente a identidade *depois* que o Kodi declarou o player
    # iniciado. O serviço persistente roda em outro interpretador e, na 2.0.88,
    # podia observar o pequeno intervalo entre mark_playback() e Player.play()
    # com isPlayingVideo()==False e apagar o fingerprint da primeira abertura.
    # Reafirmar aqui torna a propriedade transacional: intenção antes do play,
    # confirmação depois do start. Não abre/reinicia o stream.
    try:
        confirmed_playable = str(outcome.get('playable') or '')
        if confirmed_playable:
            mark_playback(confirmed_playable, kind, title, meta=playback_meta, relay_session_id=outcome.get('relay_session_id') or '', resume_at=resume_at)
            log('Player BG: identidade da reprodução confirmada após início do VideoPlayer.', 'debug')
    except Exception as exc:
        log('Player BG: falha não crítica ao confirmar identidade da reprodução: %s' % exc, 'debug')

    # Retomada local ao ONEPLAY. ``isPlaying()`` sozinho não significa que o
    # InputStream/Demuxer já tenha timeline: o log real da 2.0.85 mostrou o
    # callback de playback vários segundos antes de ``Creating InputStream``.
    # Só aplicamos o seek depois da timeline existir e confirmamos via getTime().
    resume_confirmed = False
    try:
        resume_value = max(0.0, float(resume_at or 0.0))
    except Exception:
        resume_value = 0.0
    if str(kind) in ('movie', 'series') and resume_value >= 30.0:
        resume_confirmed = bool(_apply_verified_resume(
            player, monitor, resume_value, kind,
            ready_timeout=max(6.0, min(12.0, effective_start_timeout + 2.0)),
            startup_tick=_startup_tick,
        ))

    # Proteção VOD por sessão: se havia um ponto resumível e o Kodi ainda não
    # conseguiu alcançá-lo, não permita que a nova reprodução iniciada em 0s
    # rebaixe o histórico válido. Assim que o relógio chega ao alvo (resume
    # confirmado ou seek/manual posterior), a proteção é liberada e rewinds
    # legítimos voltam a ser persistidos normalmente nesta mesma sessão.
    resume_guard_target = resume_value if (str(kind) in ('movie', 'series') and resume_value >= 30.0) else 0.0
    resume_guard_released = bool(not resume_guard_target or resume_confirmed)
    if resume_guard_target and not resume_guard_released:
        log('Histórico VOD: protegendo ponto salvo %.1fs enquanto a retomada não for alcançada (%s).' % (resume_guard_target, kind), 'debug')

    # V2.1.2 — VOD MP4: handoff dirigido por prontidão real, não por 8 s.
    #
    # O log real mostrou MP4s em que o Kodi aceitava Player.play() rapidamente,
    # mas demorava 12–17 s para concluir seek remoto/avformat_find_stream_info.
    # Nesses casos o limite visual antigo fechava IBOProgress antes do player.
    # Filmes e episódios MP4 agora mantêm a cobertura até a timeline existir ou
    # VideoFullScreen assumir. Live HLS/TS e VOD não-MP4 continuam exatamente no
    # handoff 2.1.1 abaixo.
    vod_mp4 = (
        str(kind) in ('movie', 'series') and
        str(extension or 'mp4').strip().lower().lstrip('.') == 'mp4'
    )

    if vod_mp4:
        vod_ready_state = _wait_vod_mp4_ready(
            player, monitor, outcome.get('playable') or '',
            startup_tick=_startup_tick, safety_timeout=35.0,
        )

        # O primeiro resume é tentado cedo para preservar a abertura rápida nos
        # VODs cuja timeline já está disponível. Em alguns MP4 remotos, porém,
        # o limite inicial termina décimos antes do AV-start/demux ficar pronto.
        # Se a própria espera de prontidão acabou de provar timeline/fullscreen,
        # faça UMA segunda passagem sobre o mesmo ponto salvo. Não reabre URL,
        # não altera Relay e não aumenta o prazo da primeira tentativa.
        if (not resume_confirmed and resume_guard_target >= 30.0
                and vod_ready_state in ('timeline', 'fullscreen')):
            log(
                'Histórico VOD: timeline ficou pronta após o limite inicial; '
                'repetindo retomada protegida em %.1fs (%s).' % (resume_guard_target, kind),
                'debug',
            )
            resume_confirmed = bool(_apply_verified_resume(
                player, monitor, resume_guard_target, kind,
                ready_timeout=2.5, startup_tick=_startup_tick,
            ))
            if resume_confirmed:
                resume_guard_released = True

        # Uma retomada confirmada faz getTime() saltar para a posição salva
        # antes de o Kodi concluir seu AV-start final. Nesse intervalo curto,
        # forçar 12005 disputa com a IBOProgress ainda modal e gera recusas.
        # Aguarde primeiro a promoção automática sem disparar ActivateWindow.
        # Se ela não ocorrer, o fallback abaixo fecha IBOProgress ANTES da
        # entrega explícita, eliminando a corrida sem alterar o caminho normal.
        if resume_confirmed and vod_ready_state == 'timeline' and not _video_fullscreen_active():
            _wait_resumed_vod_auto_fullscreen(
                player, monitor, timeout=1.6, startup_tick=_startup_tick
            )
        elif vod_ready_state == 'timeline' and not _video_fullscreen_active():
            # Caminho sem retomada preservado exatamente: a timeline pronta
            # pode pedir fullscreen enquanto IBOProgress cobre a transição.
            _activate_fullscreen_with_retry(player, monitor, timeout=1.2)
            _startup_tick()

        # Exceção de compatibilidade: se um skin/dispositivo só aceitar 12005
        # depois que a WindowXMLDialog sair, remova a cobertura APENAS quando a
        # mídia já provou prontidão. Para timeout/stopped/replaced preservamos o
        # escape bounded histórico, sem transformar esta camada visual em health.
        if not _video_fullscreen_active():
            _finish_opening()
            _suppress_kodi_busy_dialogs()
            _activate_fullscreen_with_retry(player, monitor, timeout=1.2)

        _startup_tick()
        _finish_opening()
        startup_ui_active = False
    else:
        # Handoff 2.1.1 preservado para Live HLS/TS e qualquer VOD não-MP4.
        # - IBOProgress remains the only visible loading feedback.
        # - Kodi's native Busy is force-closed while startup is in progress.
        # - the instant VideoFullScreen becomes active, _startup_tick() closes
        #   IBOProgress; there is no post-fullscreen delay/tail.
        # Wait boundedly for Kodi's normal automatic promotion first.
        fullscreen_deadline = time.monotonic() + 8.0
        while time.monotonic() < fullscreen_deadline and not monitor.abortRequested():
            _startup_tick()
            if _video_fullscreen_active():
                break
            if monitor.waitForAbort(0.05):
                break

        # Filmes/séries VOD não-MP4 usam o mesmo princípio da correção MP4:
        # se a tentativa inicial perdeu a janela de prontidão por pouco, o
        # handoff bounded acima já deu tempo adicional ao input. Faça uma única
        # segunda tentativa, ainda protegida, antes do fallback visual final.
        if (not resume_confirmed and resume_guard_target >= 30.0):
            try:
                retry_playing = bool(player.isPlaying())
            except Exception:
                retry_playing = False
            if retry_playing:
                log(
                    'Histórico VOD: repetindo retomada protegida após handoff em %.1fs (%s).'
                    % (resume_guard_target, kind), 'debug'
                )
                resume_confirmed = bool(_apply_verified_resume(
                    player, monitor, resume_guard_target, kind,
                    ready_timeout=2.5, startup_tick=_startup_tick,
                ))
                if resume_confirmed:
                    resume_guard_released = True

        # Some skins/devices do not auto-promote while a custom WindowXMLDialog is
        # present. In that exceptional path, close only the ONEPLAY progress and
        # retain the historical bounded fullscreen fallback. No URL/player reopen.
        if not _video_fullscreen_active():
            _finish_opening()
            _suppress_kodi_busy_dialogs()
            _activate_fullscreen_with_retry(player, monitor, timeout=1.2)

        # From here the startup handoff is complete. Never let IBOProgress linger
        # over an already-visible player.
        _startup_tick()
        _finish_opening()
        startup_ui_active = False

    fullscreen_seen = _video_fullscreen_active()
    fullscreen_left_at = None
    backgrounded = False

    last_progress_at = time.time()
    last_position = None
    last_total = 0.0
    history_saved_at = 0.0
    history_meta = dict(playback_meta or {}) if isinstance(playback_meta, dict) else {}
    history_meta.setdefault('kind', str(kind or ''))
    history_meta.setdefault('stream_id', str(stream_id or ''))
    history_meta.setdefault('title', str(title or ''))
    history_meta.setdefault('extension', str(extension or ''))
    history_meta.setdefault('art', str(art or ''))
    history_meta.setdefault('plot', str(plot or ''))
    if year is not None:
        history_meta.setdefault('year', year)
    if season is not None:
        history_meta.setdefault('season', season)
    if episode is not None:
        history_meta.setdefault('episode', episode)
    up_next_shown = False
    up_next_selected = False
    watchdog_seconds = 10 if str(kind) == 'live' else 35
    ffmpeg_live_health = (str(kind) == 'live' and playback_mode == 'ffmpegdirect')
    ffmpeg_health_started_at = None
    ffmpeg_health_position = None
    watchdog_triggered = False
    aborted = False
    try:
        while True:
            try:
                if monitor.abortRequested():
                    aborted = True
                    try:
                        player.stop()
                    except Exception:
                        pass
                    break
            except Exception:
                pass
            try:
                if not player.isPlaying():
                    break
            except Exception:
                break

            # Back no VideoFullScreen não deve matar um stream saudável. Depois
            # que o fullscreen realmente existiu, uma volta estável à interface
            # OnePlay apenas entrega o controle de volta ao catálogo/detalhes. A
            # reprodução segue em segundo plano e a UI oferece VOLTAR AO PLAYER.
            fullscreen_now = _video_fullscreen_active()
            if fullscreen_now:
                fullscreen_seen = True
                fullscreen_left_at = None
            elif fullscreen_seen and _returned_to_addon_ui():
                if callable(return_start):
                    try:
                        return_start()
                    except Exception as exc:
                        log('Player: falha ao abrir handoff de retorno: %s' % exc, 'warning')
                backgrounded = True
                log('Player: saída do VideoFullScreen detectada; restaurando a tela de conteúdo com stream em segundo plano.', 'debug')
                break
            else:
                fullscreen_left_at = None

            # Kodi keeps isPlaying() true while an HLS stream can be permanently
            # stalled. Track actual playback position and recover automatically.
            try:
                pos = float(player.getTime())
            except Exception:
                pos = None
            if pos is not None:
                try:
                    total_now = float(player.getTotalTime() or 0.0)
                except Exception:
                    total_now = 0.0
                if total_now > 0.0:
                    last_total = total_now
                if last_position is None or pos > last_position + 0.20:
                    last_position = pos
                    last_progress_at = time.time()
                elif time.time() - last_progress_at >= watchdog_seconds:
                    watchdog_triggered = True
                    log('Watchdog de reprodução: %s sem progresso por %ss; interrompendo.' % (kind, watchdog_seconds), 'warning')
                    try:
                        player.stop()
                    except Exception:
                        pass
                    break

                if ffmpeg_live_health:
                    now_mono = time.monotonic()
                    ffmpeg_health_started_at, ffmpeg_health_position, low_progress, useful_progress = _ffmpeg_direct_live_window(
                        ffmpeg_health_started_at, ffmpeg_health_position, now_mono, pos,
                        window_seconds=10.0, min_progress=5.0,
                    )
                    if low_progress:
                        watchdog_triggered = True
                        log(
                            'Watchdog FFmpeg Direct: live avançou apenas %.1fs em 10s; interrompendo para testar outra fonte.'
                            % float(useful_progress or 0.0), 'warning'
                        )
                        try:
                            player.stop()
                        except Exception:
                            pass
                        break

                # Filmes/séries persistem progresso a cada 5 s. Se esta sessão
                # nasceu com uma retomada válida ainda não alcançada, preserve o
                # ponto anterior em vez de gravar os poucos segundos do zero.
                # A margem é a mesma ordem da verificação do seek e apenas arma
                # a transição; depois de liberada, inclusive rewinds persistem.
                if str(kind) in ('movie', 'series'):
                    if (not resume_guard_released and resume_guard_target > 0.0
                            and pos >= max(1.0, resume_guard_target - 8.0)):
                        resume_guard_released = True
                        log('Histórico VOD: proteção de retomada liberada em %.1fs (alvo %.1fs, %s).' % (pos, resume_guard_target, kind), 'debug')
                    if time.time() - history_saved_at >= 5.0:
                        if resume_guard_released:
                            record_progress(history_meta, pos, total_now)
                        history_saved_at = time.time()

                # Up Next só aparece perto do fim e uma única vez. O callback é
                # fornecido pelo router/screens, mantendo player.py desacoplado da UI.
                if (str(kind) == 'series' and not up_next_shown and isinstance(up_next, dict)
                        and callable(up_next_prompt) and total_now >= 300.0):
                    remaining = max(0.0, total_now - pos)
                    ratio = (pos / total_now) if total_now > 0.0 else 0.0
                    trigger_window = min(75.0, max(20.0, total_now * 0.05))
                    if remaining <= trigger_window and ratio >= 0.85:
                        up_next_shown = True
                        try:
                            choice = up_next_prompt(dict(up_next), int(round(remaining)))
                        except Exception as exc:
                            choice = False
                            log('Up Next: janela indisponível: %s' % exc, 'warning')
                        if choice in (True, 'play', 'next'):
                            up_next_selected = True
                            mark_watched(history_meta, total_now)
                            try:
                                player.stop()
                            except Exception:
                                pass
                            break

            if monitor.waitForAbort(0.10):
                aborted = True
                try:
                    player.stop()
                except Exception:
                    pass
                break
    finally:
        # Guarda a última posição conhecida antes de remover o marcador. Se o
        # vídeo ficou em background, o service.py continuará a persistência.
        if str(kind) in ('movie', 'series') and not backgrounded and last_position is not None:
            if resume_guard_released:
                record_progress(history_meta, last_position, last_total)
            elif resume_guard_target > 0.0:
                log('Histórico VOD: Stop antes de alcançar %.1fs; ponto anterior preservado (%s).' % (resume_guard_target, kind), 'debug')
        # Enquanto o vídeo continua em segundo plano o marcador precisa
        # sobreviver para Health/serviço reconhecerem a mesma reprodução. O
        # serviço limpa o marcador quando o Kodi efetivamente parar o player.
        if not backgrounded:
            clear_playback()
            # release_playback scrubs the credential-bearing upstream URL now,
            # while retaining only a short non-secret HEAD tombstone for Kodi.
            release_playback(outcome.get('relay_session_id') or '')

    if aborted:
        return {'ok': False, 'aborted': True, 'error': 'Execução cancelada pelo Kodi.'}
    if watchdog_triggered:
        return {'ok': False, 'error': humanize_content_error('O stream ficou sem progresso e foi interrompido para liberar o Kodi.', kind=kind, phase='player')}
    if up_next_selected:
        result = dict(outcome or {})
        result['up_next'] = True
        return result
    if backgrounded:
        result = dict(outcome or {})
        result['backgrounded'] = True
        return result
    return outcome


def resume_background_player_and_wait(opening_stop=None, return_start=None):
    """Retorna ao VideoFullScreen reutilizando o mesmo VideoPlayer.

    A 2.0.91 usa o IBOShell/videowindow como cobertura visual da transição.
    Não abre IBOProgress e não tenta rearmar o fullscreen depois de um Back:
    uma saída do VideoFullScreen é sempre uma intenção de voltar ao ONEPLAY.
    A cauda da tecla é absorvida pelo Shell e pelo guard da janela restaurada.
    """
    if xbmc is None:
        return False
    player = xbmc.Player()
    try:
        if not player.isPlayingVideo():
            clear_playback()
            return False
    except Exception:
        return False

    monitor = xbmc.Monitor()

    def _finish_resume_opening():
        if callable(opening_stop):
            try:
                opening_stop()
            except Exception as exc:
                log('Player: falha ao fechar transição de retorno ao player: %s' % exc, 'warning')

    # Compatibilidade defensiva: versões anteriores podiam deixar uma
    # IBOProgress antecipada. Feche-a antes de qualquer handoff. Na 2.0.91 o
    # caminho normal não cria modal algum aqui.
    _finish_resume_opening()

    # A WindowXMLDialog que originou o comando já terminou doModal() quando o
    # router chega aqui. Dê apenas um settle curto para o GUI thread e espere
    # passivamente qualquer modal residual; nunca faça spam de ActivateWindow.
    try:
        xbmc.sleep(60)
    except Exception:
        pass

    if not _video_fullscreen_active():
        if not _activate_fullscreen_with_retry(player, monitor, timeout=1.2):
            try:
                if not player.isPlayingVideo():
                    clear_playback()
            except Exception:
                pass
            log('Player: Kodi não aceitou o retorno ao VideoFullScreen; mantendo stream em segundo plano.', 'warning')
            return False

    log('Player BG: mesmo player entregue ao VideoFullScreen.', 'debug')
    fullscreen_seen = True

    while True:
        try:
            if monitor.abortRequested():
                try:
                    player.stop()
                except Exception:
                    pass
                clear_playback()
                return False
        except Exception:
            pass

        try:
            if not player.isPlayingVideo():
                clear_playback()
                return True
        except Exception:
            clear_playback()
            return True

        if _video_fullscreen_active():
            fullscreen_seen = True
        elif fullscreen_seen and _returned_to_addon_ui():
            if callable(return_start):
                try:
                    return_start()
                except Exception as exc:
                    log('Player: falha ao armar retorno à interface: %s' % exc, 'warning')
            log('Player: retorno do VideoFullScreen à interface OnePlay; restaurando a mesma tela.', 'debug')
            return True

        try:
            if monitor.waitForAbort(0.10):
                try:
                    player.stop()
                except Exception:
                    pass
                clear_playback()
                return False
        except Exception:
            try:
                xbmc.sleep(100)
            except Exception:
                pass
