# -*- coding: utf-8 -*-
import socket
import time
import urllib.error
import urllib.parse
import urllib.request

from .constants import XTREAM_USER_AGENT
from .http import HttpError, request_json
from .content_errors import content_http_message, content_transport_message
from .storage import cache_get, cache_put
def parse_portal_url(url):
    parsed = urllib.parse.urlparse(str(url or ''))
    if parsed.scheme not in ('http', 'https') or not parsed.netloc:
        raise ValueError('URL Xtream inválida.')
    query = urllib.parse.parse_qs(parsed.query)
    username = (query.get('username') or [''])[0]
    password = (query.get('password') or [''])[0]
    output = (query.get('output') or ['m3u8'])[0]
    path = parsed.path or ''
    prefix = path.rsplit('/get.php', 1)[0] if '/get.php' in path else path.rsplit('/', 1)[0]
    return {
        'base_url': ('%s://%s%s' % (parsed.scheme, parsed.netloc, prefix.rstrip('/'))).rstrip('/'),
        'username': username,
        'password': password,
        'output': output if output in ('m3u8', 'ts') else 'm3u8',
    }


class XtreamAccountError(Exception):
    pass


class XtreamClient(object):
    def __init__(self, base_url, username, password, output='m3u8'):
        self.base_url = str(base_url or '').rstrip('/')
        self.username = str(username or '')
        self.password = str(password or '')
        self.output = output if output in ('m3u8', 'ts') else 'm3u8'
        if not self.base_url or not self.username or not self.password:
            raise ValueError('Credenciais Xtream incompletas.')

    @classmethod
    def from_portal(cls, portal):
        data = parse_portal_url((portal or {}).get('url') or '')
        return cls(data['base_url'], data['username'], data['password'], data['output'])

    def api_url(self, action='', params=None):
        query = {'username': self.username, 'password': self.password}
        if action:
            query['action'] = action
        for key, value in (params or {}).items():
            if value is not None and value != '':
                query[str(key)] = str(value)
        return self.base_url + '/player_api.php?' + urllib.parse.urlencode(query)

    def request(self, action='', params=None, cached=False, ttl=None, timeout=None):
        url = self.api_url(action, params)
        if cached:
            hit = cache_get('xtream_v2', url, ttl)
            if hit is not None:
                return hit
        _s, _h, data = request_json(url, timeout=timeout, headers={'User-Agent': XTREAM_USER_AGENT, 'Accept': 'application/json,text/plain,*/*'})
        if cached:
            cache_put('xtream_v2', url, data)
        return data

    def authenticate(self, timeout=None):
        data = self.request(timeout=timeout)
        if not isinstance(data, dict) or not isinstance(data.get('user_info'), dict):
            raise HttpError('Xtream não retornou user_info.', url=self.api_url())
        status = str(data['user_info'].get('status') or '')
        normalized = status.strip().lower()
        if normalized != 'active':
            labels = {
                'expired': 'Acesso vencido.',
                'disabled': 'Acesso desativado.',
                'banned': 'Acesso bloqueado.',
                'inactive': 'Acesso inativo.',
            }
            raise XtreamAccountError(labels.get(normalized, 'Acesso Xtream não está ativo (%s).' % (status or 'sem status')))
        return data

    def live_categories(self):
        data = self.request('get_live_categories', cached=True)
        return data if isinstance(data, list) else []

    def live_streams(self, category_id=''):
        data = self.request('get_live_streams', {'category_id': category_id} if category_id else None, cached=True)
        return data if isinstance(data, list) else []

    def vod_categories(self):
        data = self.request('get_vod_categories', cached=True)
        return data if isinstance(data, list) else []

    def vod_streams(self, category_id=''):
        data = self.request('get_vod_streams', {'category_id': category_id} if category_id else None, cached=True)
        return data if isinstance(data, list) else []

    def vod_info(self, vod_id):
        data = self.request('get_vod_info', {'vod_id': vod_id}, cached=True)
        return data if isinstance(data, dict) else {}

    def series_categories(self):
        data = self.request('get_series_categories', cached=True)
        return data if isinstance(data, list) else []

    def series(self, category_id=''):
        data = self.request('get_series', {'category_id': category_id} if category_id else None, cached=True)
        return data if isinstance(data, list) else []

    def series_info(self, series_id):
        data = self.request('get_series_info', {'series_id': series_id}, cached=True)
        return data if isinstance(data, dict) else {}

    def _global_catalog_meta_key(self, mode):
        actions = {
            'live': 'get_live_streams',
            'movie': 'get_vod_streams',
            'series': 'get_series',
        }
        return self.api_url(actions.get(str(mode or ''), 'get_vod_streams'))

    def global_catalog_oversized(self, mode):
        if str(mode or '') not in ('live', 'movie', 'series'):
            return False
        data = cache_get('xtream_global_meta_v2', self._global_catalog_meta_key(mode), None)
        return bool(isinstance(data, dict) and data.get('oversized'))

    def mark_global_catalog_oversized(self, mode):
        if str(mode or '') not in ('live', 'movie', 'series'):
            return
        cache_put('xtream_global_meta_v2', self._global_catalog_meta_key(mode), {'oversized': True, 'at': int(time.time())})

    def short_epg(self, stream_id, limit=12):
        data = self.request('get_short_epg', {'stream_id': stream_id, 'limit': limit}, cached=True, ttl=60)
        rows = data.get('epg_listings') if isinstance(data, dict) else []
        return rows if isinstance(rows, list) else []

    def short_epg_cached(self, stream_id, limit=8):
        """Return only an already-cached short EPG snapshot.

        Playback metadata must never delay channel startup. The Live browser
        already refreshes get_short_epg in the background with a 60-second TTL;
        this helper reuses that exact cache entry and never performs network I/O.
        """
        url = self.api_url('get_short_epg', {'stream_id': stream_id, 'limit': limit})
        data = cache_get('xtream_v2', url, 60)
        rows = data.get('epg_listings') if isinstance(data, dict) else []
        return rows if isinstance(rows, list) else []

    def live_url(self, stream_id, extension=None):
        ext = extension or self.output
        if ext not in ('m3u8', 'ts'):
            ext = self.output
        return '%s/live/%s/%s/%s.%s' % (self.base_url, urllib.parse.quote(self.username, safe=''), urllib.parse.quote(self.password, safe=''), urllib.parse.quote(str(stream_id), safe=''), ext)

    def vod_url(self, stream_id, extension='mp4'):
        ext = str(extension or 'mp4').lstrip('.')
        return '%s/movie/%s/%s/%s.%s' % (self.base_url, urllib.parse.quote(self.username, safe=''), urllib.parse.quote(self.password, safe=''), urllib.parse.quote(str(stream_id), safe=''), urllib.parse.quote(ext, safe=''))

    def episode_url(self, stream_id, extension='mp4'):
        ext = str(extension or 'mp4').lstrip('.')
        return '%s/series/%s/%s/%s.%s' % (self.base_url, urllib.parse.quote(self.username, safe=''), urllib.parse.quote(self.password, safe=''), urllib.parse.quote(str(stream_id), safe=''), urllib.parse.quote(ext, safe=''))

    @staticmethod
    def kodi_url(url):
        raw = str(url or '').split('|', 1)[0]
        opts = urllib.parse.urlencode({'User-Agent': XTREAM_USER_AGENT, 'Accept': '*/*', 'Connection': 'keep-alive'})
        return raw + ('|' + opts if raw else '')

    @staticmethod
    def probe(url, timeout=6, kind=''):
        """Confirm that the media endpoint answers with actual media bytes.

        A HTTP 200 alone is not enough: Xtream endpoints sometimes return an
        HTML/JSON error page while keeping status 200.  The preflight remains
        deliberately small so it can fail fast without downloading the media.
        """
        raw = str(url or '').split('|', 1)[0]
        headers = {'User-Agent': XTREAM_USER_AGENT, 'Accept': '*/*', 'Accept-Encoding': 'identity', 'Connection': 'close'}
        path = urllib.parse.urlparse(raw).path.lower()
        media_kind = str(kind or '').lower()
        is_hls = path.endswith('.m3u8')
        is_ts = path.endswith('.ts')
        # VOD/episodes: request only the first 4 KiB.  Many Xtream servers
        # ignore Range, therefore the read below is bounded as well.
        if not is_hls and not is_ts:
            headers['Range'] = 'bytes=0-4095'
        req = urllib.request.Request(raw, headers=headers, method='GET')
        try:
            with urllib.request.urlopen(req, timeout=max(2.0, float(timeout))) as response:
                status = int(getattr(response, 'status', response.getcode()))
                if status < 200 or status >= 400:
                    raise HttpError(content_http_message(status), status=status, url=raw)
                try:
                    sample = response.read(4096 if media_kind in ('movie', 'series') else 1024) or b''
                except (socket.timeout, TimeoutError, OSError) as exc:
                    raise HttpError('Stream sem bytes de mídia: %s' % exc, transport=True, url=raw)
                if not sample:
                    raise HttpError('Stream respondeu sem dados de mídia.', transport=True, url=raw)

                probe = sample[:512].lstrip().lower()
                if (probe.startswith(b'<!doctype html') or probe.startswith(b'<html') or
                        probe.startswith(b'<?xml') or probe.startswith(b'{') or probe.startswith(b'[')):
                    raise HttpError('Servidor respondeu conteúdo inválido em vez de mídia.', status=status, url=raw)
                if is_hls and not (b'#extm3u' in sample[:1024].lower() or sample[:1] == b'G'):
                    raise HttpError('Playlist HLS inválida ou sem segmentos.', status=status, url=raw)
                return status
        except urllib.error.HTTPError as exc:
            retry_after = 0
            try:
                retry_after = int(float((exc.headers or {}).get('Retry-After') or 0))
            except Exception:
                retry_after = 0
            raise HttpError(content_http_message(int(exc.code), retry_after), status=int(exc.code), url=raw, retry_after=retry_after)
        except HttpError:
            raise
        except (urllib.error.URLError, socket.timeout, TimeoutError, OSError) as exc:
            raise HttpError(content_transport_message(exc), transport=True, url=raw)

    def session_dict(self, portal, auth):
        info = auth.get('user_info') or {}
        return {
            'base_url': self.base_url,
            'server_url': self.base_url,
            'username': self.username,
            'password': self.password,
            'output': self.output,
            'max_connections': str(info.get('max_connections') if info.get('max_connections') is not None else ''),
            'exp_date': str(info.get('exp_date') or ''),
            'status': str(info.get('status') or ''),
            'active_cons': str(info.get('active_cons') or ''),
            'portal_id': str((portal or {}).get('id') or ''),
            'portal_name': str((portal or {}).get('name') or (portal or {}).get('playlist_name') or ''),
            'connected_at': int(time.time()),
        }
