# -*- coding: utf-8 -*-
"""Minimal IBOShell bootstrap.

This module intentionally avoids importing screens/auth/player/catalog code. It
exists only to put the already-homologated non-modal ONEPLAY shell on screen
before the heavier application modules are imported on a cold Kodi launch.
"""
import os

from .log import log
from .skin_compat import window_xml_args
from .storage import state_path

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
except Exception:
    xbmc = None
    xbmcaddon = None
    xbmcgui = None

ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path') if xbmcaddon is not None else ''
SKIN = 'Default'
RES = '1080i'
ACTION_BACK = {9, 10, 92}
ACTION_SELECT = 7
_BACKGROUND_RESUME_LOCK_DIR = state_path('player_resume_transition.lock')


def _new_window(cls, xml_name):
    args = window_xml_args(xml_name, ADDON_PATH, SKIN, RES)
    try:
        return cls(*args)
    except Exception as exc:
        if len(args) >= 2 and str(args[1]) != str(ADDON_PATH):
            log('Skin compat: construtor alternativo recusado para %s (%s); usando original.' % (xml_name, exc), 'warning')
            return cls(xml_name, ADDON_PATH, SKIN, RES)
        raise


def _touch_background_resume_transition():
    try:
        os.utime(_BACKGROUND_RESUME_LOCK_DIR, None)
        return True
    except Exception:
        return False


class ShellWindow(xbmcgui.WindowXML if xbmcgui is not None else object):
    """Exact lightweight ownership semantics of the approved screens.ShellWindow."""
    def onAction(self, action):
        try:
            aid = action.getId()
        except Exception:
            aid = 0
        if os.path.isdir(_BACKGROUND_RESUME_LOCK_DIR) and (aid in ACTION_BACK or aid == ACTION_SELECT):
            _touch_background_resume_transition()
            log('Player BG: entrada transitória absorvida pelo Shell durante handoff.', 'debug')
            return
        if aid in ACTION_BACK:
            log('Player BG: Back transitório absorvido pelo Shell interno.', 'debug')
            return
        try:
            super(ShellWindow, self).onAction(action)
        except Exception:
            pass


def open_shell():
    if xbmcgui is None:
        return None
    try:
        win = _new_window(ShellWindow, 'IBOShell.xml')
        win.show()
        if xbmc is not None:
            xbmc.sleep(80)
        return win
    except Exception as exc:
        log('Shell IBO indisponível: %s' % exc, 'warning')
        return None


def close_shell(win):
    if win is None:
        return
    try:
        win.close()
    except Exception:
        pass
