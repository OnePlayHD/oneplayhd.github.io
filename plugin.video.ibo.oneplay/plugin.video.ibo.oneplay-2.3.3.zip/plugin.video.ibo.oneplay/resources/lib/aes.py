# -*- coding: utf-8 -*-
"""Minimal AES-128 ECB decryptor used only for the existing IBO panel envelope.
No external Python package is required on Kodi.
"""
from __future__ import absolute_import
import base64
import json

from .constants import PANEL_AES_KEY1, PANEL_AES_KEY2

SBOX = (
0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16)
INV_SBOX = [0] * 256
for _i, _v in enumerate(SBOX):
    INV_SBOX[_v] = _i
INV_SBOX = tuple(INV_SBOX)
RCON = (0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36)


def _xtime(a):
    return ((a << 1) ^ 0x1b) & 0xff if a & 0x80 else (a << 1) & 0xff


def _mul(a, b):
    out = 0
    while b:
        if b & 1:
            out ^= a
        a = _xtime(a)
        b >>= 1
    return out & 0xff


def _expand_key(key):
    if not isinstance(key, (bytes, bytearray)) or len(key) != 16:
        raise ValueError('AES-128 requer chave de 16 bytes.')
    expanded = list(bytearray(key))
    generated = 16
    rcon_iter = 1
    temp = [0, 0, 0, 0]
    while generated < 176:
        temp[:] = expanded[generated-4:generated]
        if generated % 16 == 0:
            temp = temp[1:] + temp[:1]
            temp = [SBOX[x] for x in temp]
            temp[0] ^= RCON[rcon_iter]
            rcon_iter += 1
        for i in range(4):
            expanded.append(expanded[generated-16] ^ temp[i])
            generated += 1
    return expanded


def _add_round_key(state, expanded, round_no):
    start = round_no * 16
    for i in range(16):
        state[i] ^= expanded[start + i]


def _inv_shift_rows(s):
    # State is column-major: index = row + 4*column.
    s[1],s[5],s[9],s[13] = s[13],s[1],s[5],s[9]
    s[2],s[6],s[10],s[14] = s[10],s[14],s[2],s[6]
    s[3],s[7],s[11],s[15] = s[7],s[11],s[15],s[3]


def _inv_sub_bytes(s):
    for i in range(16):
        s[i] = INV_SBOX[s[i]]


def _inv_mix_columns(s):
    for c in range(4):
        i = c * 4
        a0,a1,a2,a3 = s[i:i+4]
        s[i]   = _mul(a0,14) ^ _mul(a1,11) ^ _mul(a2,13) ^ _mul(a3,9)
        s[i+1] = _mul(a0,9)  ^ _mul(a1,14) ^ _mul(a2,11) ^ _mul(a3,13)
        s[i+2] = _mul(a0,13) ^ _mul(a1,9)  ^ _mul(a2,14) ^ _mul(a3,11)
        s[i+3] = _mul(a0,11) ^ _mul(a1,13) ^ _mul(a2,9)  ^ _mul(a3,14)


def decrypt_block(block, key):
    if len(block) != 16:
        raise ValueError('Bloco AES inválido.')
    expanded = _expand_key(key)
    state = list(bytearray(block))
    _add_round_key(state, expanded, 10)
    for rnd in range(9, 0, -1):
        _inv_shift_rows(state)
        _inv_sub_bytes(state)
        _add_round_key(state, expanded, rnd)
        _inv_mix_columns(state)
    _inv_shift_rows(state)
    _inv_sub_bytes(state)
    _add_round_key(state, expanded, 0)
    return bytes(bytearray(state))


def decrypt_ecb_pkcs7(ciphertext, key):
    if not ciphertext or len(ciphertext) % 16:
        raise ValueError('Ciphertext AES inválido.')
    plain = b''.join(decrypt_block(ciphertext[i:i+16], key) for i in range(0, len(ciphertext), 16))
    pad = plain[-1]
    if pad < 1 or pad > 16 or plain[-pad:] != bytes([pad]) * pad:
        raise ValueError('Padding AES inválido.')
    return plain[:-pad]


def _decode_segment(segment, key):
    raw = base64.b64decode(segment, validate=True)
    return decrypt_ecb_pkcs7(raw, key)


def decode_panel_envelope(value):
    """Reverse includes/functions.php Encryption::run(..., 'IBO_38')."""
    if isinstance(value, (bytes, bytearray)):
        value = value.decode('utf-8-sig')
    if isinstance(value, str):
        outer = json.loads(value)
    elif isinstance(value, dict):
        outer = value
    else:
        raise ValueError('Envelope do painel inválido.')
    encoded = outer.get('data')
    if not isinstance(encoded, str) or not encoded:
        raise ValueError('Campo data ausente no envelope do painel.')
    joined = base64.b64decode(encoded, validate=True).decode('ascii')
    body, sep, length_text = joined.rpartition('!')
    if not sep or not length_text.isdigit():
        raise ValueError('Envelope criptográfico inválido.')
    first_len = int(length_text)
    if first_len <= 0 or first_len >= len(body):
        raise ValueError('Comprimento criptográfico inválido.')
    part1 = body[:first_len]
    part2 = body[first_len:]
    plain = _decode_segment(part1, PANEL_AES_KEY1) + _decode_segment(part2, PANEL_AES_KEY2)
    return json.loads(plain.decode('utf-8'))
