# -*- coding: utf-8 -*-
from .constants import DEFAULT_PANEL_URL
from .state import load_panel, load_prefs, save_prefs

DEFAULTS = {
    'panel_url': DEFAULT_PANEL_URL,
    'request_timeout': 8,
    'failover_attempts': 5,
    'page_size': 60,
    'ffmpeg_direct': 0,
    'live_stream_output_override': 'panel',
    'time_format_override': 'panel',
    'language_code_override': 'panel',
    'up_next_auto': 0,
    'apk_auto_cleanup': 1,
}


def get_value(key, default=None):
    prefs = load_prefs()
    if key in prefs:
        value = prefs.get(key)
        return value
    if key in DEFAULTS:
        return DEFAULTS[key]
    return default


def get_int(key, default=None, low=None, high=None):
    fallback = DEFAULTS.get(key, default if default is not None else 0)
    try:
        value = int(get_value(key, fallback))
    except Exception:
        value = int(fallback or 0)
    if low is not None:
        value = max(int(low), value)
    if high is not None:
        value = min(int(high), value)
    return value


def get_str(key, default=''):
    value = get_value(key, DEFAULTS.get(key, default))
    return str(value if value is not None else default)


def set_value(key, value):
    prefs = load_prefs()
    prefs[str(key)] = value
    save_prefs(prefs)
    return value


def _panel_live_output(panel=None):
    data = panel if isinstance(panel, dict) else load_panel()
    value = str((data or {}).get('live_stream_format') or (data or {}).get('output') or 'm3u8').strip().lower()
    return value if value in ('m3u8', 'ts') else 'm3u8'


def live_stream_locked(panel=None):
    data = panel if isinstance(panel, dict) else load_panel()
    # Contrato ausente = conservadoramente fixo. Painel V2.22+ sempre envia a chave.
    if 'live_stream_lock' not in (data or {}):
        return True
    return str((data or {}).get('live_stream_lock') or 'yes').strip().lower() in ('1','true','yes','on')


def effective_live_output(panel=None):
    panel_value = _panel_live_output(panel)
    if live_stream_locked(panel):
        return panel_value
    override = str(get_value('live_stream_output_override', 'panel') or 'panel').strip().lower()
    return override if override in ('m3u8', 'ts') else panel_value


def effective_time_format(panel=None):
    data = panel if isinstance(panel, dict) else load_panel()
    panel_value = '0' if str((data or {}).get('time_format', '1')).strip().lower() in ('0','12','12h','false','no','off') else '1'
    override = str(get_value('time_format_override', 'panel') or 'panel').strip().lower()
    return override if override in ('0','1') else panel_value
