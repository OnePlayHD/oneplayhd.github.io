# -*- coding: utf-8 -*-
from resources.lib.bootstrap import run_plugin

if __name__ == '__main__':
    run_plugin()
