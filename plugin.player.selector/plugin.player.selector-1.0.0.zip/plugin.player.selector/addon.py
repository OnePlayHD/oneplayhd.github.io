# -*- coding: utf-8 -*-
import sys
import os
import base64
import json
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
icon = addon.getAddonInfo('icon')
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))

# ============================================
# CONFIGURAÇÕES DO PLAYER
# ============================================

PLAYER_OPTIONS = {
    0: "Player Padrão do Kodi",
    1: "MX Player (Android)",
    2: "Web Video Cast (Android)"
}

# Player IDs para Android
PLAYER_IDS = {
    1: "com.mxtech.videoplayer.ad",      # MX Player
    2: "com.instantbits.cast.webvideo"   # Web Video Cast
}

# ============================================
# FUNÇÕES PRINCIPAIS
# ============================================

def get_player_config_path():
    """Retorna o caminho do arquivo playercorefactory.xml"""
    return os.path.join(xbmcvfs.translatePath('special://home/userdata'), 'playercorefactory.xml')

def get_player_xml(player_id):
    """Retorna o XML de configuração do player"""
    return '''<?xml version="1.0" encoding="UTF-8"?>
<playercorefactory>
  <players>
    <player name="ExternalPlayer" type="ExternalPlayer" audio="false" video="true">
      <filename>com.{player_id}</filename>
      <hidexbmc>true</hidexbmc>
      <playcountminimumtime>120</playcountminimumtime>
    </player>
  </players>
  <rules action="prepend">
    <rule video="true" player="ExternalPlayer"/>
  </rules>
</playercorefactory>'''.format(player_id=player_id)

def remove_player_config():
    """Remove o arquivo de configuração do player externo"""
    config_path = get_player_config_path()
    if os.path.exists(config_path):
        try:
            os.remove(config_path)
            return True
        except Exception as e:
            print(f"Erro ao remover config: {e}")
            return False
    return True

def set_player(option):
    """
    Configura o player no Kodi
    option: 0 = Padrão, 1 = MX Player, 2 = Web Video Cast
    """
    config_path = get_player_config_path()
    
    # Se for opção 0, remove a configuração e usa o player padrão
    if option == 0:
        if remove_player_config():
            return True, "restaurado"
        else:
            return False, "Erro ao restaurar player padrão!"
    
    # Para opções 1 e 2, configura player externo
    if option in PLAYER_IDS:
        player_id = PLAYER_IDS[option]
        xml_content = get_player_xml(player_id)
        
        try:
            # Garante que o diretório existe
            userdata_dir = os.path.dirname(config_path)
            if not os.path.exists(userdata_dir):
                os.makedirs(userdata_dir)
            
            # Escreve o arquivo
            with open(config_path, 'w', encoding='utf-8') as f:
                f.write(xml_content)
            
            player_name = PLAYER_OPTIONS.get(option, "Player Externo")
            return True, player_name
            
        except Exception as e:
            print(f"Erro ao configurar player: {e}")
            return False, "Erro ao configurar player!"
    
    return False, "Opção inválida!"

def get_current_player():
    """Verifica qual player está atualmente configurado"""
    config_path = get_player_config_path()
    
    if not os.path.exists(config_path):
        return 0  # Player padrão
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        for option, player_id in PLAYER_IDS.items():
            if player_id in content:
                return option
                
        return 0  # Se não encontrar, assume padrão
    except:
        return 0

def check_player_and_platform():
    """Mostra informações sobre o player atual e plataforma"""
    current = get_current_player()
    current_name = PLAYER_OPTIONS.get(current, "Desconhecido")
    
    is_android = xbmc.getCondVisibility('system.platform.android')
    platform = "Android" if is_android else "Outro"
    
    dialog = xbmcgui.Dialog()
    msg = "[B]Player atual:[/B] {}\n[B]Plataforma:[/B] {}\n\n[B]Nota:[/B] Players externos funcionam apenas no Android.".format(
        current_name, platform
    )
    dialog.ok("[B]Informações do Player[/B]", msg)

def show_reboot_dialog(player_name, action):
    """Mostra diálogo de reinicialização"""
    dialog = xbmcgui.Dialog()
    
    if action == "restaurado":
        msg = (
            "[B]Player padrão restaurado com sucesso![/B]\n\n"
            "[COLOR gold]Para que as alterações tenham efeito,[/COLOR]\n"
            "[COLOR gold]é necessário reiniciar o Kodi.[/COLOR]\n\n"
            "[B]Deseja reiniciar o Kodi agora?[/B]"
        )
    else:
        msg = (
            "[B]{} configurado com sucesso![/B]\n\n"
            "[COLOR gold]Para que as alterações tenham efeito,[/COLOR]\n"
            "[COLOR gold]é necessário reiniciar o Kodi.[/COLOR]\n\n"
            "[B]Deseja reiniciar o Kodi agora?[/B]"
        ).format(player_name)
    
    # Mostra diálogo com opção de reiniciar
    if dialog.yesno("[B]Player Alterado[/B]", msg, yeslabel="Reiniciar", nolabel="Depois"):
        # Reinicia o Kodi
        xbmc.executebuiltin("RestartApp")
        return True
    
    # Se não reiniciar, mostra notificação
    if action == "restaurado":
        xbmc.executebuiltin("Notification({}, [B]Player padrão restaurado! Reinicie o Kodi.[/B], 7000, {})".format(addon_name, icon))
    else:
        xbmc.executebuiltin("Notification({}, [B]{} configurado! Reinicie o Kodi.[/B], 7000, {})".format(addon_name, player_name, icon))
    
    return False

# ============================================
# MENU PRINCIPAL
# ============================================

def show_menu():
    """Mostra o menu de seleção de player"""
    dialog = xbmcgui.Dialog()
    
    # Verifica se é Android
    is_android = xbmc.getCondVisibility('system.platform.android')
    
    # Prepara a lista de opções
    options = list(PLAYER_OPTIONS.values())
    
    # Marca a opção atual
    current = get_current_player()
    for i in range(len(options)):
        if i == current:
            options[i] = "[B][COLOR gold]▶[/COLOR] {}[/B]".format(options[i])
    
    # Adiciona opção de informações
    options.append("[B][COLOR blue]ℹ[/COLOR] Informações do Player[/B]")
    
    # Mostra o diálogo
    index = dialog.select("[B]Selecione o Player[/B]", options)
    
    if index < 0:
        return
    
    # Se escolheu informações
    if index == len(options) - 1:
        check_player_and_platform()
        return
    
    # Verifica se é Android para players externos
    if not is_android and index > 0:
        dialog.ok(
            "[B]Aviso[/B]",
            "[B]Players externos funcionam apenas no Android.[CR]"
            "Seu sistema: {}.[CR][CR]"
            "[COLOR gold]Para usar, instale o Kodi no Android.[/COLOR]".format(
                "Android" if is_android else "Outro"
            )
        )
        return
    
    # Aplica a configuração
    success, result = set_player(index)
    
    if success:
        player_name = PLAYER_OPTIONS.get(index, "Player")
        show_reboot_dialog(player_name, result)
    else:
        xbmc.executebuiltin("Notification({}, [B]{}[/B], 5000, {})".format(addon_name, result, icon))

# ============================================
# FUNÇÃO PRINCIPAL PARA PLUGIN
# ============================================

def run():
    """Função principal do addon"""
    
    # Verifica se tem argumentos
    if len(sys.argv) > 1:
        if sys.argv[1] == 'info':
            check_player_and_platform()
            return
        elif sys.argv[1] == 'reset':
            success, result = set_player(0)
            if success:
                dialog = xbmcgui.Dialog()
                if dialog.yesno(
                    "[B]Player Restaurado[/B]",
                    "[B]Player padrão restaurado com sucesso![/B]\n\n"
                    "[COLOR gold]Deseja reiniciar o Kodi agora?[/COLOR]",
                    yeslabel="Reiniciar",
                    nolabel="Depois"
                ):
                    xbmc.executebuiltin("RestartApp")
            return
    
    # Mostra o menu principal
    show_menu()

# ============================================
# PONTO DE ENTRADA
# ============================================

if __name__ == '__main__':
    run()