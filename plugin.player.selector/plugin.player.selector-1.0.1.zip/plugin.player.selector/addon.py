# -*- coding: utf-8 -*-

import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs


addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
icon = addon.getAddonInfo('icon')
fanart = addon.getAddonInfo('fanart')


# ============================================
# PLAYER FILE XML
# ============================================

PLAYER_XML = '''<playercorefactory>
    <players>
        <player name="MXPlayer" audio="false" type="ExternalPlayer" video="true">
            <filename>{PLAYER_ID}</filename>
            <hidexbmc>true</hidexbmc>
            <playcountminimumtime>120</playcountminimumtime>
        </player>
    </players>

    <rules action="prepend">
        <rule player="MXPlayer" protocols="smb"/>
        <rule dvdimage="true" player="MXPlayer"/>
        <rule player="MXPlayer" protocols="rtmp"/>
        <rule player="MXPlayer" protocols="rtsp"/>
        <rule player="MXPlayer" protocols="sop"/>
        <rule internetstream="true" player="MXPlayer"/>
        <rule player="MXPlayer" video="true"/>
    </rules>
</playercorefactory>'''


# ============================================
# PLAYER ATUAL
#
# 0 = Kodi
# 1 = MX Player
# 2 = Web Video Cast
# ============================================

current_player = 0


# ============================================
# FUNÇÕES
# ============================================

def translate(path):
    return xbmcvfs.translatePath(path)


def get_player_xml(player):
    """
    Gera o XML de acordo com o player escolhido.
    """

    if player == 1:
        player_id = "com.mxtech.videoplayer.ad"

    elif player == 2:
        player_id = "com.instantbits.cast.webvideo"

    else:
        return None

    return PLAYER_XML.replace("{PLAYER_ID}", player_id)


def get_xml_path():
    userdata = translate('special://home/userdata')
    return os.path.join(userdata, "playercorefactory.xml")


def remove_player_file():
    """
    Remove o playercorefactory.xml.
    """

    arquivo = get_xml_path()

    try:
        if os.path.isfile(arquivo):
            os.remove(arquivo)

        return True

    except Exception:
        return False


def write_player_file(player):
    """
    Cria ou substitui o playercorefactory.xml.
    """

    xml = get_player_xml(player)

    if xml is None:
        return False

    arquivo = get_xml_path()

    try:
        with open(arquivo, "w", encoding="utf-8") as f:
            f.write(xml)

        return True

    except Exception as e:
        xbmc.log(
            "Erro ao escrever playercorefactory.xml: {}".format(e),
            xbmc.LOGERROR
        )

        return False


def check_player(player):
    """
    Aplica o player escolhido.
    """

    # Player padrão do Kodi
    if player == 0:
        if remove_player_file():
            return "Player padrão do Kodi restaurado!"

        return "Player padrão do Kodi!"


    # Players externos somente no Android
    if not xbmc.getCondVisibility('system.platform.android'):
        return "Players externos funcionam apenas no Android."


    # MX Player
    if player == 1:

        if write_player_file(player):
            return "MX Player configurado!"

        return "Erro ao configurar MX Player!"


    # Web Video Cast
    if player == 2:

        if write_player_file(player):
            return "Web Video Cast configurado!"

        return "Erro ao configurar Web Video Cast!"


    return "Player inválido!"


# ============================================
# MENU
# ============================================

def show_selection_menu():

    global current_player

    dialog = xbmcgui.Dialog()

    player_options = {
        0: "Player Padrão do Kodi",
        1: "MX Player (Android)",
        2: "Web Video Cast (Android)"
    }

    options = []

    for option, name in player_options.items():

        if option == current_player:

            options.append(
                "[B][COLOR gold]▶[/COLOR] {} "
                "[COLOR gold](ATUAL)[/COLOR][/B]".format(name)
            )

        else:

            if option > 0 and not xbmc.getCondVisibility(
                'system.platform.android'
            ):

                options.append(
                    "[B]{} [COLOR gray]"
                    "(apenas Android)[/COLOR][/B]".format(name)
                )

            else:

                options.append(
                    "[B]{}[/B]".format(name)
                )


    options.append(
        "[B][COLOR blue]ℹ[/COLOR] Informações do Player[/B]"
    )

    options.append(
        "[B][COLOR gray]◄[/COLOR] Sair[/B]"
    )


    index = dialog.select(
        "[B]Selecionar Player[/B]",
        options
    )


    if index < 0:
        return


    # Sair
    if index == len(options) - 1:
        return


    # Informações
    if index == len(options) - 2:
        show_info_dialog()
        return


    # Player escolhido
    option = index

    apply_and_restart(option)


# ============================================
# INFORMAÇÕES
# ============================================

def show_info_dialog():

    player_options = {
        0: "Player Padrão do Kodi",
        1: "MX Player (Android)",
        2: "Web Video Cast (Android)"
    }

    current_name = player_options.get(
        current_player,
        "Desconhecido"
    )

    is_android = xbmc.getCondVisibility(
        'system.platform.android'
    )

    platform = "Android" if is_android else "Outro"

    arquivo = get_xml_path()

    exists = os.path.isfile(arquivo)

    msg = (
        "[B]Player atual:[/B] {}\n"
        "[B]Plataforma:[/B] {}\n"
        "[B]Arquivo config:[/B] {}\n\n"
        "[B]Nota:[/B] Players externos funcionam apenas no Android."
    ).format(
        current_name,
        platform,
        "Existe" if exists else "Não existe"
    )

    dialog = xbmcgui.Dialog()

    dialog.ok(
        "[B]Informações do Player[/B]",
        msg
    )

    show_selection_menu()


# ============================================
# APLICAR PLAYER
# ============================================

def apply_and_restart(option):

    global current_player

    # Player externo somente Android
    if option > 0 and not xbmc.getCondVisibility(
        'system.platform.android'
    ):

        dialog = xbmcgui.Dialog()

        dialog.ok(
            "[B]Aviso[/B]",
            "[B]Players externos funcionam apenas no Android.[/B]"
        )

        show_selection_menu()

        return


    # Atualiza variável
    current_player = option


    # Aplica configuração
    result = check_player(option)


    dialog = xbmcgui.Dialog()


    msg = (
        "[B]{}[/B]\n\n"
        "[COLOR gold]"
        "Para que as alterações tenham efeito,"
        "[/COLOR]\n"
        "[COLOR gold]"
        "é necessário reiniciar o Kodi."
        "[/COLOR]\n\n"
        "[B]Deseja reiniciar o Kodi agora?[/B]"
    ).format(result)


    if dialog.yesno(
        "[B]Player Alterado[/B]",
        msg,
        yeslabel="Reiniciar",
        nolabel="Depois"
    ):

        xbmc.executebuiltin("RestartApp")

    else:

        xbmc.executebuiltin(
            "Notification({}, [B]{} "
            "Reinicie o Kodi.[/B], 7000, {})".format(
                addon_name,
                result,
                icon
            )
        )


# ============================================
# PRINCIPAL
# ============================================

def run():

    global current_player

    # Argumentos
    if len(sys.argv) > 1:

        if sys.argv[1] == 'info':

            show_info_dialog()
            return


        elif sys.argv[1] == 'reset':

            current_player = 0

            result = check_player(0)

            dialog = xbmcgui.Dialog()

            if dialog.yesno(
                "[B]Player Restaurado[/B]",
                "[B]{}[/B]\n\n"
                "[COLOR gold]"
                "Deseja reiniciar o Kodi agora?"
                "[/COLOR]".format(result),
                yeslabel="Reiniciar",
                nolabel="Depois"
            ):

                xbmc.executebuiltin("RestartApp")

            return


    # Abre menu
    show_selection_menu()


# ============================================
# PONTO DE ENTRADA
# ============================================

if __name__ == '__main__':
    run()