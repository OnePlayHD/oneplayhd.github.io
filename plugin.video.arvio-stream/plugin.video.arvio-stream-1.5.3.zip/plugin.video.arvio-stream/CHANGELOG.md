## 1.5.3 - 2026-08-22

- Telegram/Cinemeta: usa o IMDb do item como âncora para resolver aliases localizados (PT-BR/PT) quando o título Cinemeta em inglês não encontra resultado direto.
- Mantidos intactos Xtream, Stremio, transporte Telegram, spool, cache e playback.

# 1.5.2 - Xtream Cinemeta bounded lookup / fim do diálogo preso

- Corrige o caso real em que `get_vod_streams` já trazia 19.844 itens, mas o matcher ainda varria 49 categorias e mantinha `Buscando fontes...` aberto.
- Cinemeta não faz mais crawl integral de categorias quando o endpoint direto já devolve catálogo grande; fallback por categorias ficou incremental, limitado e com saída antecipada.
- Matching Xtream pode resolver aliases localizados ancorados no IMDb via Wikidata, sem alterar o resolvedor legado usado pelo Telegram.
- `get_vod_info` / `get_series_info` usa probe de identidade com orçamento curto e priorização por título, ano e recência.
- Fallback de episódios publicados como VOD usa o catálogo direto e não dispara varredura total.
- Cache por topologia da 1.5.1 preservado; geração do resolver entra na assinatura para invalidar uma vez snapshots 1.5.1. Telegram 1.4.9 permanece byte a byte inalterado.

# 1.5.1 - Cache de fontes por topologia + Xtream sem busca duplicada

- Snapshot Cinemeta agora é vinculado à configuração ativa de Stremio/Xtream/Telegram.
- Adicionar, remover, ativar ou desativar uma fonte invalida imediatamente snapshots antigos.
- Xtream não repete uma varredura completa apenas para tentar títulos localizados.
- Varredura Xtream usada pelo Cinemeta usa timeout por request mais curto e orçamento global conservador; navegação Xtream normal mantém o timeout anterior.
- Telegram 1.4.9 permanece byte a byte inalterado.

## 1.5.0 - 2026-08-22

- Cinemeta → Xtream now builds a category-complete VOD/series catalog instead of treating any non-empty unfiltered Xtream response as complete.
- Xtream matcher normalizes release/year/quality/codec decorations and uses conservative token/year scoring.
- When Xtream summary rows omit IMDb/TMDB IDs, prioritized bounded `get_vod_info` / `get_series_info` probes can resolve the Cinemeta canonical ID.
- Cinemeta movie/series catalog labels display the release year.
- The playing Kodi ListItem is now content-centric: movies show `Title (Year)` and episodes show `Series · SxxEyy`, while provider/quality remains the source-row label.
- Telegram transport, adaptive spool, search, constants and cleanup remain frozen from the approved 1.4.9 implementation.

## 1.4.9 - 2026-08-22

- Telegram playback moved to an independent disk-backed progressive spool.
- Safe single-sender media producer avoids the multi-sender corruption observed in the 1.4.8 real log.
- Bitrate decision can infer MP4 duration from the probe prefix; unknown bitrate forces full safe pre-download instead of DIRECT.
- Adaptive initial lead; producer always continues to 100% while playback runs.
- Android/low-resource search/probe profile and bounded RAM.
- Temporary storage protects at least 1 GiB or 10% of the filesystem.
- STOP/cancel/teardown cancels the producer and removes the temporary file; stale crash leftovers are reclaimed.
- PyCryptodome acceleration now accepts both Crypto and Cryptodome namespaces.

## 1.4.8 - 2026-08-21
- Telegram transport now diagnoses the real AES backend (`cryptg`, `libssl`, optional `PyCryptodome`, or `pyaes`).
- When native cryptg/OpenSSL are unavailable, the installed optional `script.module.pycryptodome` accelerates Telethon AES-IGE instead of pure-Python pyaes.
- Sequential Telegram playback uses a conservative pool of independent MTProto TCP senders (2 normal / up to 4 Premium) with ordered 256 KiB chunks; any sender/private-API failure falls back to the proven 1.4.7 single-client path.
- Playback performs a 1 MiB sustained-throughput diagnostic before starting. Media bitrate is calculated from Telegram size/duration and compared with a 15% safety margin.
- If the Telegram source is slower than the media bitrate, Arvio switches to download-first mode: the probe prefix is reused, the complete file is downloaded to Kodi temp storage with progress/cancel support, size is verified, then `xbmc.Player` opens the local file. This mathematically prevents network starvation when the source cannot sustain real-time playback.
- Temporary Telegram media is deleted after playback/cancel/error; crash leftovers older than 24 hours are reclaimed on the next Telegram playback.
- Fast Telegram sources remain streamed through the loopback Range proxy, preserving seek. Cinemeta source snapshots/STOP behavior remain unchanged.

## 1.4.7 - 2026-08-21
- Telegram proxy: real-device LIMIT_INVALID fixed by keeping MTProto requests at 256 KiB.
- Read-ahead now pipelines 10 x 256 KiB on one Telegram session (bounded ~2.5 MiB ahead).
- LIMIT_INVALID automatically retries the same contiguous block with a smaller request instead of truncating HTTP/MP4.
- Added cumulative proxy throughput diagnostics every ~2 MiB to distinguish Telegram bandwidth from decoder issues.
- Cinemeta source snapshot is pinned before Telegram playback and renewed every 30 s, so Kodi's immediate STOP refresh reuses the source list even after long playback.

## 1.4.6 — 2026-08-21

- Telegram search is strictly gated to channels/groups present in the connected account dialog list.
- Strong Cinemeta title variants are searched concurrently; subscribed-dialog fallback uses server-side text search instead of scanning recent messages.
- Telegram steady-state read-ahead increased conservatively from 4 to 8 x 512 KiB requests on the same client (maximum ~4 MiB requested ahead).
- Cinemeta source snapshots are retained for 3 minutes so Kodi parent-directory refresh after STOP does not repeat provider searches.
- Stream rows explicitly use the normal video-action + xbmc.Player path with no IsPlayable property.

## 1.4.5 — 2026-08-21

Ajuste periciado pelo log real da 1.4.4, focado em STOP/navegação e continuidade do buffer Telegram.

- Kodi/player: linhas de vídeo deixam de usar a propriedade `IsPlayable`; as rotas iniciam a URL final com `xbmc.Player().play(...)` em vez de `xbmcplugin.setResolvedUrl`.
- STOP: como o item efetivamente reproduzido passa a ser a URL HTTP/HLS/DASH final — e não a rota `plugin://...` — o retorno mantém a listagem já carregada e evita disparar novamente a busca Cinemeta de ~38 s.
- Telegram first-byte preservado: primeiro pedido MTProto continua em 256 KiB, mantendo a abertura rápida comprovada em produção.
- Telegram read-ahead: após o primeiro bloco, usa pedidos diretos de 512 KiB e mantém até 4 chunks em voo na mesma `TelegramClient` (máximo aproximado de 2 MiB adiantados), sem criar quatro sessões/conexões independentes.
- Kodi FileCache: o proxy passa a alimentar continuamente o cache nativo do Kodi; o addon não altera `advancedsettings.xml` nem força configuração global.
- Cleanup Telethon: desconexão real é aguardada antes de fechar o loop one-shot, reduzindo `Unhandled error while receiving data / Event loop is closed` após cancelamento/navegação.
- Preservados integralmente Cinemeta, Xtream, Stremio/FrostStream, Range/seek, QR/2FA, storage, cache, redaction e o tratamento de `CancelledError` da 1.4.4.

## 1.4.4 — 2026-08-21

Correção cirúrgica guiada pelo log real posterior à 1.4.3. A reprodução Telegram/first-byte/Range foi comprovada em produção e preservada; o ajuste é somente no cancelamento assíncrono ao reabrir o Cinemeta.

- Telegram/Cinemeta: `asyncio.CancelledError` deixa de atravessar o worker como `BaseException` e passa a ser convertido em cancelamento operacional benigno.
- Busca Telegram em lote: se uma consulta é cancelada durante navegação/encerramento, resultados parciais já obtidos são preservados em vez de perder toda a coleta.
- Agregador Cinemeta: Futures canceladas/expiradas são consumidas e registradas, nunca propagadas como `PythonToCppException`.
- Cleanup asyncio: tarefas pendentes são canceladas/aguardadas com tratamento de `BaseException`; o loop usa handler local silencioso para impedir o erro secundário `TypeError: 'NoneType' object is not callable` durante teardown do interpretador Kodi.
- Confirmado por log real: primeiro bloco Telegram de 256 KiB entregue, MP4/H.264 reconhecido pelo FFmpeg e seek executado; esse caminho da 1.4.3 não foi alterado.
- Diagnóstico de provedores preservado: `Xtream=0/0` e `Stremio stream=0/1` são tratados como estado de configuração, não como falha de matching.

## 1.4.3 — 2026-08-21

Correção cirúrgica do primeiro byte do proxy Telegram, guiada por log real do Kodi 21.3.

- Telegram: separa a janela lógica do proxy do tamanho de requisição MTProto; `iter_download` passa a pedir blocos alinhados de 256 KiB (máximo 512 KiB), permitindo streaming progressivo imediato em vez de aguardar a montagem de 2 MiB.
- Telegram: o proxy serializa sessões de download concorrentes e transmite contexto `dc_id`/tamanho/mensagem ao Telethon quando disponível.
- Player: o proxy local Telegram pula o probe HTTP genérico HLS/DASH, evitando uma sessão de Telegram extra imediatamente antes do play.
- Diagnóstico: Cinemeta passa a registrar quantos provedores Stremio/Xtream/Telegram estão realmente prontos/habilitados antes da agregação.
- Baseline preservada: runtime Telegram transitório da 1.4.2, Cinemeta, Xtream progressivo, Stremio/FrostStream, Range/seek, storage atômico e encerramento determinístico permanecem cumulativos.

# Changelog

## 1.4.2 — 2026-08-21

Correção periciada a partir de dois logs reais da 1.4.1, focada nos três fluxos dependentes: Cinemeta → Xtream, Cinemeta → Telegram e Telegram → reprodução.

- Telegram/Kodi: removido o runtime `asyncio`/Telethon residente do pluginsource. Cada operação cria cliente e loop transitórios na própria thread de execução, desconecta e fecha o loop antes de retornar; nenhuma Future/TelegramClient atravessa invocações do Kodi.
- Telegram: cliente transitório usa `receive_updates=False`, `auto_reconnect=False`, timeout de conexão limitado e retry conservador; chamada feita de dentro de outro loop usa worker one-shot não-daemon e obrigatoriamente unido antes do retorno.
- Telegram proxy: Range/seek continua local, mas cada requisição HTTP possui sua própria sessão transitória; proxy/pareamento são encerrados com `shutdown` + `join` e não deixam workers de rede sobreviventes.
- Telegram QR/pareamento: workers de espera passam a ser canceláveis e unidos ao encerrar a rota.
- Cinemeta agregador: removido o descarte prematuro de fontes lentas do teto anterior de 25 s; Stremio, Xtream e Telegram têm execução isolada, limites internos e resultados que concluam durante o fechamento controlado também são preservados.
- Cinemeta → Telegram: título do catálogo é preservado como alias quando o meta troca o nome; busca usa título, aliases, ano, SxxExx e fallback localizado apenas quando necessário, sem iniciar o proxy durante a listagem.
- Cinemeta → Xtream: identidade IMDb/TMDB continua prioritária; painéis que exigem `category_id` usam varredura progressiva por tempo/cache, sem limite permanente de 48 grupos; IDs ausentes no resumo podem ser confirmados de forma limitada em `get_vod_info/get_series_info`.
- Diagnóstico: logs passam a informar contagem e tempo por provedor (`Cinemeta -> Stremio/Xtream/Telegram`) sem expor credenciais.
- Preservados integralmente os contratos Stremio/FrostStream, player HLS/DASH, headers, legendas, storage atômico, cache e licença Apache-2.0.

## 1.4.1 — 2026-08-21

Correção periciada a partir do primeiro log real da 1.4.0, focada no fluxo Telegram → proxy local → VideoPlayer.

- Corrigida a causa do timeout de reprodução: o loop `asyncio` do Telethon passa a ser criado dentro da própria thread que o executa, evitando afinidade cruzada no Python embutido do Kodi.
- Cada `TelegramClient` fica vinculado explicitamente ao loop que o criou; cliente de loop anterior é descartado e reconstruído pela StringSession persistida.
- `receive_updates=False`: o addon não precisa do update loop do Telethon para busca/download, removendo a tarefa que no log gerava `Future ... attached to a different loop`.
- Recuperação de runtime passa a criar uma coroutine nova em cada tentativa; elimina `cannot reuse already awaited coroutine` e o warning de coroutine não aguardada.
- Runtime Telegram é encerrado ao fim de cada invocação do plugin sem apagar a StringSession, impedindo sobreposição entre invocações Kodi.
- Proxy HTTP usa threads daemon e conexão `close`, reduzindo handlers presos/WinError 10053 após o Kodi abortar probes ou seeks.
- Mantidos Range/seek, QR/2FA, Cinemeta, Xtream, FrostStream, HLS/DASH, cache/storage e todos os contratos da 1.4.0.

## 1.4.0 — 2026-08-21

Perícia cumulativa fluxo por fluxo com foco nos dois defeitos observados em produção e nas dependências entre módulos.

- Cinemeta → Xtream: busca global com fallback por categorias quando `get_vod_streams`/`get_series` exige `category_id`; varredura limitada a 4 workers e cache reaproveitado.
- Identidade de conteúdo: IMDb/TMDB têm precedência sobre título; títulos alternativos e normalização sem acentos entram como fallback, reduzindo falhas com nomes localizados.
- Séries Xtream: resolução do episódio real via `get_series_info`, mantendo parser tolerante; fallback controlado para painéis que expõem SxxExx em VOD.
- Navegação Xtream: “Todos os grupos” também usa fallback por categorias para Live, VOD e Séries, preservando a navegação direta.
- Telegram/Kodi: `TelegramClient` é criado e restaurado somente no loop `asyncio` dedicado; o menu não abre conexão de rede, evitando `There is no current event loop in thread 'Dummy-*'`.
- Telegram: pesquisa híbrida (busca global + fallback por chats quando necessário); timeouts cancelam a coroutine pendente; proxy Range/seek e descritores persistentes permanecem.
- HTTP/player: resposta HTML com HTTP 200 é normalizada como erro de JSON; IMDb é canonizado; URLs de legendas duplicadas são removidas antes do player.
- Pairing: TTL do código de pareamento agora é efetivamente aplicado e `Content-Length` inválido é rejeitado de forma controlada.
- FrostStream: contrato real v2.2.5 auditado como provedor `meta`/`stream` sem catálogos; addons stream-only deixam de gerar busca inútil e passam a informar corretamente que serão usados automaticamente pelo Cinemeta.
- Baseline preservada: Cinemeta 1.3.0, HLS/DASH, headers, storage atômico, cache persistente Xtream, redaction de logs e licença Apache-2.0 permanecem cumulativos.

## 1.3.0 — 2026-08-21

Integração periciada do fluxo Cinemeta corrigido sobre a infraestrutura conservadora 1.2.0.

- Cinemeta: catálogo/meta dedicado como fonte de descoberta, sem tratá-lo como provedor de stream; instalação automática apenas quando ausente e respeito ao estado desativado.
- Protocolo Stremio: `search`, `skip`, `genre` e demais `extraArgs` passam a usar o segmento de rota definido pelo protocolo, preservando query de configuração do manifest separadamente.
- Cinemeta: navegação de filmes/séries, Popular, Destaques, Lançamentos, busca, paginação com gênero/ano preservados e séries baseadas nos IDs reais de `meta.videos`.
- Agregação: fontes Stremio, Xtream e Telegram são consultadas isoladamente e em paralelo, com deduplicação por provedor e orçamento global.
- Xtream + Cinemeta: séries agora resolvem o episódio exato antes de gerar a fonte; não são mais apresentadas entradas de série sem URL reproduzível.
- Telegram + Cinemeta: a listagem carrega apenas descritores persistentes; o proxy local continua sendo iniciado somente no clique de reprodução.
- Baseline preservada: HLS/DASH resiliente, headers, cache Xtream, gravação atômica, Range/seek Telegram, redaction de logs, licença Apache-2.0 e demais correções da 1.2.0 permanecem intactas.

## 1.2.0 — 2026-08-21

Alinhamento conservador com os contratos maduros do projeto ARVIO de referência.

- Stremio: identidade canônica IMDb/TMDB separada do ID de origem, deduplicação por provedor, resolução paralela limitada a 4 workers, orçamento global, headers em três formatos, `videoSize`/filename e legendas externas carregadas somente no play.
- Player: detecção de HLS sem extensão por HEAD/redirect/Content-Type com probe Range curto como fallback; suporte DASH/MPD via `inputstream.adaptive`; headers preservados.
- Xtream: parser tolerante a árvores de episódios em dict/list e campos `id`/`stream_id`/`episode_id`, cache persistente pequeno para navegação e invalidação ao alterar contas.
- Telegram: Range em janelas de 2 MB, contador de requisições HTTP e grace period curto antes de encerrar o proxy, preservando o ciclo de vida seguro da 1.1.0.
- Segurança/manutenção: logs com redaction adicional de credenciais/tokens; cache persistente Xtream com fail-open; escaping seguro de segmentos de credenciais; URLs Kodi `url|headers` normalizadas antes do probe; licença/atribuição alinhadas ao ARVIO Apache-2.0.

## 1.1.0 — 2026-08-21

Versão auditada e estabilizada de forma conservadora sobre a base 1.0.0.

- QR: ciclo de janela corrigido, fechamento seguro e layout responsivo; caminho pure-PNG vendorizado mantido com fallback textual.
- Storage: gravação atômica e erro de persistência visível/logado.
- Player: headers propagados e fallback HLS quando `inputstream.adaptive` não existir.
- Stremio: manifests configurados preservados, pesquisa multi-catálogo, IDs intactos, episódios via `meta.videos`, agregação multi-addon, subtitles e proxy headers.
- Xtream: contas desabilitadas fora da operação, formato Live baseado no servidor, metadata normalizada e User-Agent no playback.
- Telegram: restauração de sessão, 2FA, descriptors de peer persistentes no link de playback, proxy reconstruído no clique, janela de startup e HTTP Range/seek corrigidos.
- Pairing: códigos não emitidos rejeitados e payload limitado.
- Kodi: menus dinâmicos sem cache em disco por padrão e logging modular padronizado.
