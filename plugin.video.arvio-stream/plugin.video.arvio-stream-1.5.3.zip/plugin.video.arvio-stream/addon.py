# -*- coding: utf-8 -*-
"""Arvio Stream - Kodi addon entry point."""
from __future__ import annotations

import os
import sys

ADDON_PATH = os.path.dirname(os.path.abspath(__file__))
LIB_PATH = os.path.join(ADDON_PATH, "resources", "lib")
THIRDPARTY_PATH = os.path.join(LIB_PATH, "thirdparty")

for _path in (THIRDPARTY_PATH, LIB_PATH):
    if _path not in sys.path:
        sys.path.insert(0, _path)


def run():
    from arvio import router
    try:
        router.dispatch()
    finally:
        # Kodi executes plugin routes repeatedly in separate invocations.
        # Telegram operations are transient. As a final safety net, do not leave the
        # loopback proxy thread alive after a route exits; the playback route
        # itself blocks until playback/seek activity has ended.
        try:
            from arvio import telegram_client
            telegram_client.shutdown_runtime(stop_http=True)
        except Exception:
            pass


if __name__ == "__main__":
    run()