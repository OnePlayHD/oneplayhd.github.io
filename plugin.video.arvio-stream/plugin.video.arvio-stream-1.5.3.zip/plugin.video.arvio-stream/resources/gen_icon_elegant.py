# -*- coding: utf-8 -*-
"""Generates an elegant icon for Arvio Stream (requires Pillow)."""
import math
import os

from PIL import Image, ImageDraw, ImageFilter, ImageFont

RES = os.path.dirname(os.path.abspath(__file__))
SIZE = 512
CX = 256
CY = 186
RED_TOP = (255, 46, 55)
RED_BOTTOM = (172, 8, 16)
INK_TOP = (26, 30, 44)
INK_BOTTOM = (8, 10, 15)

FONT_BOLD = r"C:\Windows\Fonts\segoeuib.ttf"
FONT_LIGHT = r"C:\Windows\Fonts\segoeuil.ttf"


def lerp4(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(4))


def text_letterspaced(draw, center_x, y, text, font, fill, spacing=0):
    """Draw text centered on center_x with manual letter spacing."""
    widths = [draw.textlength(ch, font=font) for ch in text]
    total = sum(widths) + spacing * (len(text) - 1)
    x = center_x - total / 2
    for ch, w in zip(text, widths):
        draw.text((x, y), ch, font=font, fill=fill)
        x += w + spacing


def draw_background(base):
    """Rounded dark card with a vertical ink gradient."""
    draw = ImageDraw.Draw(base)
    draw.rounded_rectangle([0, 0, SIZE - 1, SIZE - 1], radius=108,
                           fill=(18, 21, 30, 255))
    grad = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grad)
    for y in range(SIZE):
        gd.line([(0, y), (SIZE, y)], fill=lerp4(INK_TOP + (255,), INK_BOTTOM + (255,),
                                                y / (SIZE - 1)))
    return Image.alpha_composite(base, grad)


def draw_glow(base):
    """Soft red halo behind the logo mark."""
    glow = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    for i in range(170, 0, -1):
        gd.ellipse([CX - i, CY - i, CX + i, CY + i],
                   fill=(229, 9, 20, max(0, 26 - int(26 * (170 - i) / 170))))
    glow = glow.filter(ImageFilter.GaussianBlur(42))
    return Image.alpha_composite(base, glow)


def draw_ring(base):
    """Orbit ring: silver top half, subtle red bottom half."""
    draw = ImageDraw.Draw(base)
    r = 118
    for angle in range(0, 360, 2):
        a0 = math.radians(angle)
        a1 = math.radians(angle + 2)
        x0 = CX + r * math.cos(a0)
        y0 = CY + r * math.sin(a0)
        x1 = CX + r * math.cos(a1)
        y1 = CY + r * math.sin(a1)
        t = angle / 360.0
        if angle < 180:
            c = lerp4((255, 255, 255, 120), (205, 216, 233, 70), t * 2)
        else:
            c = lerp4((222, 28, 41, 110), (255, 70, 78, 60), (t - 0.5) * 2)
        draw.line([(x0, y0), (x1, y1)], fill=c, width=7)
    return base


def draw_triangle(base):
    """Red play triangle with a smooth vertical gradient."""
    tri = [(CX - 44, CY - 54), (CX - 44, CY + 54), (CX + 54, CY)]
    mask = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    ImageDraw.Draw(mask).polygon(tri, fill=(255, 255, 255, 255))
    grad = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grad)
    for y in range(CY - 58, CY + 58):
        t = (y - (CY - 58)) / 116.0
        gd.line([(0, y), (SIZE - 1, y)],
                fill=lerp4(RED_TOP + (255,), RED_BOTTOM + (255,), t))
    out = Image.composite(grad, base, mask.split()[3])
    # sheen on top half of the triangle
    draw = ImageDraw.Draw(out, "RGBA")
    draw.polygon([(CX - 38, CY - 48), (CX - 38, CY - 2), (CX + 34, CY - 2)],
                 fill=(255, 235, 235, 26))
    return out


def draw_accent_dots(base):
    """Small streaming pulse dots right of the triangle."""
    draw = ImageDraw.Draw(base)
    for i, (offset, length) in enumerate(((46, 16), (54, 27), (62, 38))):
        y = CY + offset - 46
        draw.line([(CX, y), (CX + length, y)],
                  fill=(255, 255, 255, 150 - i * 30), width=5)
    return base


def draw_wordmark(base):
    draw = ImageDraw.Draw(base)
    f_big = ImageFont.truetype(FONT_BOLD, 44)
    f_small = ImageFont.truetype(FONT_LIGHT, 25)
    text_letterspaced(draw, CX, 354, "ARVIO", f_big,
                      (239, 241, 246, 255), spacing=17)
    text_letterspaced(draw, CX, 420, "STREAM", f_small,
                      (168, 177, 195, 255), spacing=13)
    # red accent underline
    draw.line([(CX - 44, 464), (CX + 44, 464)], fill=(229, 9, 20, 235), width=3)
    return base


def draw_vignette(base):
    """Edge darkening only (center stays clear)."""
    mask = Image.new("L", (SIZE, SIZE), 0)
    ImageDraw.Draw(mask).ellipse([116, 116, 396, 396], fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(70))
    # composite keeps image1 (dark) where mask > 128; invert so the bright
    # center region (mask=255) shows base and only the far edges darken.
    mask = mask.point(lambda p: 255 - p)
    dark = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 90))
    return Image.composite(dark, base, mask)


def main():
    base = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    base = draw_background(base)
    base = draw_glow(base)
    base = draw_ring(base)
    base = draw_triangle(base)
    base = draw_accent_dots(base)
    base = draw_vignette(base)
    base = draw_wordmark(base)

    base.save(os.path.join(RES, "icon.png"))
    print("icon.png regenerated", os.path.getsize(os.path.join(RES, "icon.png")),
          "bytes")


if __name__ == "__main__":
    main()